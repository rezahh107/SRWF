---
document_id: SRWF-OWNER-COMPREHENSION-PROTOCOL
title: "SRWF Owner Comprehension Protocol"
version: 1.0.1
status: SUPPORTING_COMMUNICATION_PROTOCOL
language: fa-IR
applies_to: SRWF owner-facing explanations and implementation guidance
source_model: adaptive_owner_comprehension
---

# SRWF Owner Comprehension Protocol

## 1. Purpose

هدف این سند این است که وضعیت‌ها، مشکلات، تصمیم‌ها و Gateهای فنی SRWF برای Owner به شکلی توضیح داده شوند که **درک درست و تصمیم درست** را آسان کند؛ بدون اینکه دقت فنی، blocker، ریسک، عدم‌قطعیت یا evidence gap پنهان شود.

این پروتکل از الگوی `adaptive_owner_comprehension` اقتباس شده است: توضیح مستقیم و ساده در اولویت است و mental model / analogy / contrast / concrete scenario فقط وقتی استفاده می‌شود که واقعاً فهم موضوع را بهتر کند.

## 2. Authority boundary

این سند فقط نحوه‌ی **توضیح و ارائه‌ی وضعیت/تصمیم به Owner** را تنظیم می‌کند.

- هیچ business semantic، معماری، Gate، Lock یا Decision در SRWF را تغییر نمی‌دهد.
- `01_SRWF_MASTER_AUTHORITY_v1.8.1-fa.md` همچنان authority معماری و تصمیم‌های `D-01..D-17` است.
- `03_SRWF_EXECUTION_PLAYBOOK_v1.2.2.md` همچنان ترتیب اجرایی و Gateها را تعیین می‌کند.
- این سند حق ندارد یک `NOT_PROVEN` را ساده‌سازی کرده و به `CONFIRMED` تبدیل کند یا blocker/uncertainty را حذف کند.
- اختلاف فنی مستقیم با Lockهای پروژه همچنان طبق قاعده‌ی `CONTRADICTION → STOP → OWNER RE-ADJUDICATION` مدیریت می‌شود.

## 3. Core invariant

`COMPREHENSION != ANALOGY`

تصویرسازی ذهنی هدف نیست؛ **فهم درست هدف است**.

بنابراین:

1. اگر توضیح مستقیم و ساده کافی است، همان را استفاده کن.
2. اگر مفهوم هنوز انتزاعی، چندلایه یا مستعد سوءبرداشت است، یک mental model، analogy، contrast یا concrete scenario اضافه کن.
3. اگر یک تصویر ذهنی قبلی هنوز مفید است، فقط بخش مرتبط آن را طبیعی ادامه بده.
4. اگر دیگر مفید نیست، آن را بدون نگرانی از یکدستی قالب کنار بگذار.
5. هیچ analogy را فقط برای زیبایی، تکرار یا حفظ یک قالب ثابت بازسازی نکن.

## 4. Owner-facing explanation sequence

برای هر توضیح material، حداقل توالی زیر را رعایت کن:

### Step A — Simple meaning first

اول معنای انسانی و عملی وضعیت را بگو؛ سپس فقط در صورت نیاز شناسه یا اصطلاح فنی را اضافه کن.

مثال:

- به‌جای شروع با `STAGE_0_ENVIRONMENT_INVENTORY` بگو: «هنوز وارد ساخت نشده‌ایم؛ اول باید نسخه‌ها و ابزارهای واقعی سایت را ثبت کنیم.»
- سپس در صورت نیاز اضافه کن: «اسم فنی این Gate، `STAGE_0_ENVIRONMENT_INVENTORY` است.»

### Step B — Find the dangerous misunderstanding

ببین کدام سوءبرداشت می‌تواند تصمیم بعدی Owner را عوض کند و همان تفاوت را روشن کن.

نمونه‌های رایج در SRWF:

- `SELECTED` با `IMPLEMENTED` یکی نیست.
- `DOCUMENTED` با `OBSERVED_IN_STAGING` یکی نیست.
- `NOT_PROVEN` به معنی `PROVEN_ABSENT` نیست.
- آماده بودن scaffold به معنی موفق بودن import نیست.
- PASS شدن یک candidate فقط همان requirement را می‌بندد؛ شکست آن معماری را خودکار باز نمی‌کند.

### Step C — Add a mental model only if useful

اگر توضیح مستقیم هنوز برای فهم رابطه‌ها کافی نیست، از یک تصویر ذهنی کوتاه استفاده کن.

Mental model باید:

- فقط بخش سخت مسئله را روشن کند؛
- با واقعیت فنی تناقض نداشته باشد؛
- باعث ساده‌سازی بیش‌ازحد نشود؛
- بعد از انتقال مفهوم، کنار گذاشته شود اگر دیگر لازم نیست.

### Step D — Deepen only decision-critical consequences

اگر Owner باید تصمیم بگیرد، فقط آن تفاوت‌ها، پیامدها، ریسک‌ها یا irreversibilityهایی را عمیق‌تر توضیح بده که واقعاً انتخاب را تغییر می‌دهند.

گزینه‌ی بسته‌شده را دوباره به‌عنوان انتخاب مطرح نکن. فقط گزینه‌های واقعاً `OPEN` را مقایسه کن.

### Step E — Preserve evidence truth

ساده‌سازی هرگز نباید این موارد را حذف یا تضعیف کند:

- blocker واقعی؛
- `NOT_PROVEN` یا evidence gap؛
- risk مادی؛
- dependency یا Gate لازم؛
- تفاوت بین plan / implementation / validation / production-ready؛
- نتیجه‌ی واقعی PASS/FAIL یک probe.

### Step F — End with the smallest next action

در گفتگوی اجرایی SRWF، پاسخ باید با کوچک‌ترین اقدام بعدی که واقعاً قابل انجام است تمام شود؛ نه roadmap بلند و نه چند اقدام موازی غیرضروری.

## 5. Technical-to-owner translation patterns

این نگاشت‌ها برای توضیح ساده هستند و status فنی اصلی را جایگزین نمی‌کنند.

| Technical state | Owner-facing meaning |
|---|---|
| `SELECTED` | راه انتخاب شده است، ولی موفقیت اجرایی هنوز از این واژه نتیجه نمی‌شود. |
| `NOT_PROVEN` | هنوز evidence یا تست واقعی کافی نداریم. |
| `UNEXECUTED` | این تست هنوز اجرا نشده است. |
| `PASS` | معیار مشاهده‌پذیر همان probe در محیط هدف پاس شده است. |
| `FAIL` | همان candidate/probe معیار لازم را پاس نکرده؛ نتیجه را به کل معماری تعمیم نده. |
| `BLOCKER` | این مورد جلوی ادامه‌ی همان مسیر/مرحله‌ی وابسته را می‌گیرد. |
| `DEFERRED` | عمداً برای بعد گذاشته شده و الان شرط ادامه‌ی مسیر جاری نیست. |
| `CONTRADICTION` | evidence مستقیم با یک Lock تعارض دارد؛ ادامه‌ی همان تصمیم باید متوقف و به Owner ارجاع شود. |

## 6. Mental-model selection guidance

هیچ mental model پیش‌فرض اجباری وجود ندارد. بر اساس مسئله انتخاب کن.

### Building / construction
مناسب برای: Stage، prerequisite، scaffold، Gate و ترتیب ساخت.

### Assembly line / پرونده در مسیر
مناسب برای: Gravity Flow workflow، assignment، Approval و انتقال entry بین stepها.

### Single source of truth / دفتر اصلی
مناسب برای: تفاوت Gravity Forms data authority با Gravity Flow workflow authority و جلوگیری از parallel state.

### Key and lock
مناسب برای: permission/capability/access control، فقط وقتی واقعاً توضیح permission model را ساده‌تر می‌کند.

### Map vs actual terrain
مناسب برای: تفاوت documentation/design با runtime validation.

این مثال‌ها catalog اجباری نیستند؛ اگر توضیح مستقیم بهتر است، analogy استفاده نشود.

## 7. SRWF examples

### Example 1 — Runtime inventory

**Technical:** `current_gate = STAGE_0_ENVIRONMENT_INVENTORY`

**Owner layer:** «قبل از اینکه فرم و Flow را روی محیط واقعی بنا کنیم، باید بدانیم دقیقاً چه نسخه‌هایی از WordPress، PHP، Gravity Forms و Gravity Flow روی سایت داریم. مثل این است که قبل از نصب قطعات، مدل و مشخصات دستگاه پایه را ثبت کنیم. تا این اطلاعات نباشد، سازگاری اجرا هنوز اثبات نشده است.»

### Example 2 — Scaffold import

**Technical:** `GF_IMPORT_SCAFFOLD_V0.4_GFNATIVEFORMAT = NOT_PROVEN`

**Owner layer:** «فایل فرم آماده‌ی امتحان است، اما هنوز نمی‌دانیم سایت واقعی آن را بدون خطا می‌پذیرد. در ذهن، مثل یک قطعه‌ی ساخته‌شده روی میز است که هنوز روی دستگاه اصلی نصب نشده. تست import تعیین می‌کند همین candidate قابل ادامه هست یا نه.»

### Example 3 — V-01

**Technical:** `V-01 = UNEXECUTED`

**Owner layer:** «ما طراحی کرده‌ایم که Officer پرونده را از Inbox باز کند، فیلد مجاز را همان‌جا اصلاح کند و Approve بزند؛ اما هنوز این مسیر را در staging از ابتدا تا انتها اجرا نکرده‌ایم. پس مسیر انتخاب شده است، ولی عملکرد واقعی آن هنوز اثبات نشده.»

## 8. Anti-patterns

از این رفتارها پرهیز کن:

- شروع پاسخ با انبوه ID، Gate و state بدون گفتن معنای انسانی آن‌ها؛
- استفاده‌ی اجباری از analogy در هر پاسخ؛
- ادامه دادن یک analogy وقتی خودش نیاز به توضیح بیشتر پیدا کرده است؛
- تبدیل analogy به architecture claim؛
- حذف uncertainty برای «ساده‌تر» شدن پاسخ؛
- ارائه‌ی roadmap طولانی وقتی فقط یک next action لازم است؛
- بازکردن تصمیم قفل‌شده صرفاً برای ساختن comparison؛
- توضیح technical detailی که هیچ اثری بر تصمیم یا اقدام بعدی Owner ندارد.

## 9. Response quality check

قبل از تحویل یک پاسخ material به Owner، بررسی کن:

1. آیا اول معنای ساده‌ی موضوع روشن شده است؟
2. آیا مهم‌ترین سوءبرداشت احتمالی برطرف شده است؟
3. آیا mental model واقعاً فهم را بهتر کرده یا فقط تزئینی است؟
4. آیا blocker/risk/uncertainty/evidence gap بدون تغییر باقی مانده است؟
5. اگر تصمیم لازم است، آیا فقط گزینه‌های واقعاً باز و تفاوت‌های تصمیم‌ساز توضیح داده شده‌اند؟
6. آیا اقدام بعدی کوچک، روشن و قابل اجراست؟

## 10. Provenance

این پروتکل برای SRWF از الگوی `adaptive_owner_comprehension` در پکیج `LLM_Project_Orchestrator_GPT_Project_Package_v1.0.0-alpha13` اقتباس شده است، به‌ویژه از:

- `PROJECT_SOURCES/04_STATE_MODEL_CATALOG.json` → `adaptive_owner_comprehension`
- `PROJECT_SOURCES/01_PROJECT_OPERATING_CONTRACT.md` → `Owner interaction boundary`
- `PROJECT_SOURCES/02_IDEA_TO_ACTION_FRAMEWORK.md` → `Owner conversation contract`
- `PROJECT_SOURCES/06_LLM_LIMITATION_CONTROL_MATRIX.md` → `mechanical explanation`, `decision-underexplaining`, `Comprehension != analogy`
- `02_PROJECT_INSTRUCTIONS.md` → `Owner layer & narration`

این provenance فقط منشأ الگوی ارتباطی را ثبت می‌کند و به پکیج مبدأ هیچ authority در business semantics یا معماری SRWF نمی‌دهد.


## 11. Changelog

### v1.0.1 — 2026-09-06

- Updated authority pointers to `01_SRWF_MASTER_AUTHORITY_v1.8.1-fa.md` and `03_SRWF_EXECUTION_PLAYBOOK_v1.2.2.md`.
- No communication semantics, explanation sequence, evidence-truth rule or Owner-facing behavior changed.
