---
document_id: SRWF-MASTER
title: "سند مادر معماری سامانه ثبت‌نام دانش‌آموز و گردش‌کار بررسی"
version: 1.9.0
status: NATIVE_FIRST_KNOWLEDGE_BASELINE
decision_state: NATIVE_FIRST_D01_D16_CLOSED_D17_POC_GATED_SFC_CLOSED_SCANNER_DEFERRED
language: fa-IR
created_at: 2026-08-20
updated_at: 2026-09-07
evidence_cutoff: 2026-08-24
implementation_status: AUTHORIZED_NOT_STARTED
---

# سند مادر معماری سامانه ثبت‌نام دانش‌آموز و گردش‌کار بررسی

## کنترل سند

| قلم | مقدار |
|---|---|
| شناسه | `SRWF-MASTER` |
| نسخه | `1.9.0` |
| وضعیت | `NATIVE_FIRST_D17_POC_GATE_SFC_CLOSED_SCANNER_DEFERRED` — parent architecture حفظ شده؛ Semantic Field Contract با تصمیم‌های Owner بسته شده، Scanner از release جاری deferred است و runtime validationهای بعدی هنوز اثبات نشده‌اند |
| حکم معماری | `NATIVE_FIRST`؛ D-01..D-17 حفظ؛ مالی نسخه جاری در Gravity Forms/Gravity Flow و چندچک با `GP Nested Forms` به‌عنوان host منتخبِ POC باقی می‌مانند؛ `PersianGravity Structured Scanner` capability عمومیِ non-persistent است ولی مسیر اسکن SRWF در release جاری `DEFERRED` است؛ POS و استعلام آنلاین صیاد نیز deferred باقی می‌مانند |
| تاریخ برش شواهد | ۲۳ اوت ۲۰۲۶ (موج دوم بازرسی مستندات رسمی Native Configuration) |
| وضعیت اجرا | `AUTHORIZED_NOT_STARTED`؛ Stage 0، قرارداد معنایی و prototypeهای critical مجازند؛ این سند اثبات اجرا نیست |
| فناوری مادر | WordPress + Gravity Forms + Gravity Flow |
| مالکیت داده | Gravity Forms |
| مالکیت workflow | Gravity Flow |
| مخاطب | مالک، مجری WordPress/PHP، بازبین معماری، تست‌کننده و مدل‌های زبانی بعدی |

### قرارداد نسخه‌گذاری این سند

این سند از `Semantic Versioning` برای خود قرارداد معماری استفاده می‌کند:

- `MAJOR`: تغییر ناسازگار در مرز مالکیت، workflow، machine Value، مدل مجوز، یا قرارداد downstream؛
- `MINOR`: افزودن requirement یا تصمیم تأییدشده‌ای که قراردادهای قبلی را نمی‌شکند؛
- `PATCH`: اصلاح نگارشی، citation، روشن‌سازی یا ثبت نتیجهٔ آزمایشی که حکم معماری را عوض نمی‌کند.

هیچ متن تاریخی یا پیشنهاد مدل زبانی، صرف حضور در نسخهٔ قبلی، تصمیم جاری محسوب نمی‌شود. فقط مواردی که در این نسخه با `OWNER_LOCKED` یا `SELECTED` مشخص شده‌اند مبنا هستند. هر تغییر مادی باید در `Decision Ledger` و `Changelog` ثبت و توسط مالک تأیید شود.

### واژگان هنجاری و وضعیت شواهد

- `MUST / باید`: شرط اجباری؛ نقض آن release را متوقف می‌کند.
- `SHOULD / بهتر است`: پیش‌فرض قوی؛ انحراف باید دلیل ثبت‌شده داشته باشد.
- `MAY / می‌تواند`: اختیاری و غیرمسدودکننده.
- `OWNER_LOCKED`: تصمیم صریح مالک و بالاتر از ترجیح فنی.
- `CONFIRMED`: با منبع رسمی، source یا commit جاری تأیید شده است.
- `DERIVED`: نتیجهٔ منطقی از چند واقعیت تأییدشده است.
- `SELECTED`: تصمیم معماری این baseline؛ هنوز معادل اجرای موفق نیست.
- `PROPOSED`: طراحی پیشنهادی که پیش از اجرا باید review شود.
- `NOT_PROVEN`: شواهد یا تست کافی در محیط واقعی وجود ندارد.
- `CONTRADICTED`: شواهد جاری ادعا را رد می‌کند.
- `DEFERRED`: عمداً به مرحلهٔ بعد منتقل شده چون معماری امروز را تغییر نمی‌دهد.
- `SURFACE_BLOCKED`: فقط همان سطح فنی راه امن اثبات‌شده ندارد؛ کار مستقل ادامه می‌یابد، اما آن سطح implement/release نمی‌شود.
- `NON_ENFORCING_GUIDANCE`: راهنمای متنی برای انسان/مدل؛ به‌خودی‌خود runtime یا CI enforcement نیست.

### داشبورد اجرایی Gateها

این جدول نمای روزمرهٔ سند است؛ جزئیات و authority همچنان در بخش‌های اصلی باقی می‌ماند و این جدول قراردادها را تکرار یا جایگزین نمی‌کند.

| Gate/سطح | وضعیت در `1.8.1` | شرط عبور |
|---|---|---|
| Parent architecture | `SELECTED/PRESERVED` | فقط contradiction فنی مستقیم می‌تواند بازش کند |
| رابط عملیاتی Officer | `SELECTED` | Gravity Flow بومی (Inbox/Entry Details)؛ GravityView فقط ارائهٔ اختیاری |
| Officer list layout | `SELECTED` | ستون‌ها/فیلتر/مرتب‌سازی/جست‌وجوی بومی Inbox؛ بدون لیست سفارشی |
| وضعیت بررسی | `SELECTED` | فقط فیلد `review_status` + دلیل؛ Entry Notes الزام پروژه نیست |
| رفتار پس از ویرایش | `SELECTED` | رفتار بومی Gravity Flow؛ بدون redirect/Lightbox سفارشی |
| Elementor | `OUT_OF_SCOPE` | خارج از دامنهٔ عملیاتی جاری |
| GravityRevisions audit | `SELECTED/NOT_PROVEN IN TARGET` | فقط ویرایش انسانی مهم؛ Admin-only؛ گیت `V-04` |
| Commercial dependency freeze | `BLOCKED BY POC` | هیچ خریدی پیش از ثبت نیاز و پیروزی POC انجام نشود |
| Semantic Field Contract | `OWNER APPROVED / CLOSED` | bindingهای لازم پیش از scaffold بسته‌اند؛ authoritative scaffold با synthetic data مجاز است |
| Implementation Mapping | `AFTER SCAFFOLD` | Form/Field/Input/Step/View IDهای واقعی بعد از scaffold bind و freeze شوند |
| V-01/V-05 Native Desk/Live Refresh | `NOT_PROVEN` | صندوق واحد Gravity Flow Inbox بومی + Live Refresh بومی؛ بدون polling سفارشی (D-02/D-07) |
| V-01 Needs Review (بومی) | `NOT_PROVEN` | فیلد Entry + دلیل؛ ویرایش/Approve بومی Gravity Flow؛ بدون POST/concurrency سفارشی |
| V-03 School selector | `NOT_PROVEN` | ساده‌ترین راه بومی/نگهداری‌شده؛ تنها معیار = جست‌وجوی responsive فارسی موبایل؛ اگر پاس شد توقف (D-09) |
| عکس دانش‌آموز | `OUT_OF_CURRENT_SCOPE` | فقط دریافت فایل؛ پردازش خارج از دامنهٔ جاری |
| V-06 Counter import (WP All Import) | `NOT_PROVEN` | WP All Import مرجع sync شمارنده بر کلید کد ملی؛ فقط شمارنده؛ بدون هدایت Flow؛ نهایی‌سازی با bulk بومی (D-15/D-16) |
| Duplicate blocking | `NOT APPLICABLE` | مسدودسازی تکراری وجود ندارد؛ کد ملی تکراری مجاز |
| Entry presentation | `SELECTED` | Entry Details بومی Gravity Flow؛ GravityView فقط ارائهٔ اختیاری فقط‌خواندنی |
| V-04 Human-edit audit | `NOT_PROVEN` | فقط ویرایش انسانی Officer/Admin با GravityRevisions؛ بدون parity API/سیستمی؛ Admin-only (D-13) |
| Iranian data quality | `SELECTED/NOT_PROVEN` | کد ملی/موبایل/جلالی با راه‌حل‌های سادهٔ ایرانیِ نگهداری‌شده |
| Current-release finance | `OWNER_LOCKED / SEMANTIC_CLOSED` | واحد canonical/display = ریال؛ همهٔ فیلدهای مالی optional و non-public؛ فقط سطح عملیاتی Registration Officer؛ `net_payable_amount = tuition - discount` و `discount > tuition` = validation error/no save |
| Multi-cheque composition | `OWNER_LOCKED / POC_NOT_PROVEN` | cardinality = `1..N`؛ host منتخب = `GP Nested Forms`؛ هر چک یک child Entry مستقل؛ entitlement و runtime composition باید اثبات شوند |
| Structured Scanner | `DEFERRED FOR CURRENT RELEASE / CAPABILITY RETAINED` | capability عمومی `PersianGravity` حفظ می‌شود، اما در release جاری هیچ دادهٔ مالی/چک را populate نمی‌کند؛ هفت output صیاد به‌صورت Hidden future-reserved باقی می‌مانند |
| Sayad v01 profile | `CONTRACT_CLOSED / CROSS_BANK_NOT_PROVEN` | هفت output ثابتِ v01 برای POC؛ validation قوی‌تر فقط بعد از evidence چند بانک/نسخه |
| POS / online Sayad | `DEFERRED` | نسخه جاری نباید به PC-POS یا استعلام آنلاین صیاد وابسته شود؛ بازشدن فقط با requirement+interface+probe مشخص |
| Document rendering | `POC_GATED / NOT_PROVEN` | candidate اول = `Gravity PDF Free` + لایهٔ چاپ SRWF؛ بدون extension/template پولی؛ PASS معیارهای §15.5 پیش از انتخاب renderer نهایی |
| External automation layer | `DEFERRED/REQUIREMENT-TRIGGERED` | فقط requirement واقعی cross-plugin/external؛ Gravity Flow همچنان تنها workflow authority |
| Privacy/retention | `OWNER DECISION REQUIRED` | پیش از ورود دادهٔ واقعی production/UAT بسته شود |
| Compatibility inventory | `STAGE 0 REQUIRED` | ترکیب واقعی WP/PHP/database/GF/Flow/GV/theme/cache ثبت و تست شود |
| Implementation | `AUTHORIZED IN CONTROLLED STAGES` | Stage 0 و scaffold پس از Semantic Contract؛ هر surface فقط پس از Gate وابسته |

---

## 0. معماری Native-First جاری (نسخهٔ ۱٫۹٫۰)

این سند معماری **Native-First** جاری را مستقیماً بیان می‌کند. نسخهٔ ۱٫۹٫۰ تصمیم‌های Owner در ۲۰۲۶-۰۹-۰۷ را sync می‌کند بدون تغییر parent architecture یا D-01..D-17: Semantic Field Contract بسته شده؛ فیلدهای مالی release جاری optional، non-public و Registration-Officer-only هستند؛ انتخاب‌های code-backed با label/name انسانی توسط Officer ویرایش می‌شوند و سیستم code/value canonical متناظر را می‌نویسد؛ و مسیر Structured Scanner برای SRWF release جاری deferred است، در حالی‌که capability عمومی PersianGravity و هفت فیلد Hidden آینده حفظ می‌شوند. `GP Nested Forms` host منتخبِ POC برای child Entryهای چک باقی می‌ماند؛ POS/PC-POS و استعلام آنلاین صیاد نیز deferred هستند. راهبرد حاکم: `NATIVE_FIRST` + `EVIDENCE_BASED` + `MINIMAL_CUSTOMIZATION` + `BUILDER_DECISION_SUPPORT`. هیچ engine/framework/لایهٔ سطح‌بالای جدیدی ساخته نمی‌شود.

**قاعدهٔ حاکمیت:** هر بخش «فعال» این سند مستقیماً تصمیم جاری را بیان می‌کند. هیچ بخش فعالی مکانیزم قدیمی را نگه نمی‌دارد تا سپس با یادداشت «superseded» اصلاح شود؛ محتوای تاریخی فقط در بخش‌های صریحاً تاریخی نگه‌داشته می‌شود. نقش محصولات ثابت است: Gravity Forms مرجع دادهٔ canonical؛ Gravity Flow مرجع workflow و **رابط عملیاتی اصلی**؛ GravityView فقط `OPTIONAL_PRESENTATION_ONLY_SURFACE` (هرگز مرجع workflow/approval/queue).

### قرارداد طبقه‌بندی بخش‌ها (۱٫۶٫۱)

هر بخش این سند دقیقاً یکی از این برچسب‌ها را دارد:

| برچسب | معنا |
|---|---|
| `ACTIVE_NORMATIVE` | الزام جاری؛ باید مستقیماً تصمیم فعلی را بگوید |
| `ACTIVE_INFORMATIVE` | توضیح/زمینهٔ جاری بدون الزام جدید |
| `HISTORICAL` | فقط سابقه؛ الزام جاری نیست |
| `REJECTED_ALTERNATIVE` | گزینهٔ بررسی‌شده و ردشده |
| `DEFERRED` | معتبر ولی خارج از دامنهٔ فعلی |

بخش‌های `HISTORICAL` / `REJECTED_ALTERNATIVE` (از جمله §9، §25، §35، §37) مجازند مکانیزم‌های قدیمی را نام ببرند؛ بخش‌های فعال مجاز نیستند.

### ماتریس تصمیم‌های قفل‌شده

| تصمیم | حکم قفل‌شده | بخش‌های متأثر |
|---|---|---|
| `D-01` | Needs Review فقط یک فیلد Entry معمولی + فیلد دلیل است؛ نه state/queue/POST سفارشی و نه تکیه بر Entry Notes | §13 |
| `D-02` | یک صندوق عملیاتی واحد = Gravity Flow Inbox بومی؛ بدون queue جداگانهٔ GravityView | §12.3 |
| `D-03` | یک مسئول ثبت‌نام؛ حذف ماتریس چند-Officer/بازتخصیص/رقابت قفل؛ حداقل امنیت بومی | §16.5 |
| `D-04` | ویرایش Officer = ابتدا Gravity Flow بومی با کوچک‌ترین whitelist فیلد؛ بدون سیستم ویرایش سفارشی و بدون GFAPI mutation پایه | §12، §13، §16 |
| `D-05` | Approval رسمی منحصراً Gravity Flow Approval بومی | §14، §13.5 |
| `D-06` | ویرایش‌های روتین/Needs-Review هیچ notification تولید نمی‌کنند | §12.5 |
| `D-07` | Live Refresh بومی Gravity Flow کافی است؛ بدون polling/freshness سفارشی؛ صفحات عملیاتی بد-cache نشوند | §12.5، §12.6 |
| `D-08` | بدون concurrency/locking سفارشی؛ probeهای locking پایه نیستند | §16.4 |
| `D-09` | انتخابگر مدرسه: تنها AC مادی = تایپ نام فارسی و انتخاب سریع روی موبایل؛ بدون chaining استان→شهر و بدون comparator سه‌گانه؛ از ساده‌ترین راه بومی/نگهداری‌شده شروع، اگر تست responsive پاس شد همان‌جا توقف | §11.3 |
| `D-10` | حذف کامل مسدودسازی تکراری؛ کد ملی تکراری مجاز و همهٔ Entryها حفظ | §14.3، §17 |
| `D-11` | موبایل/جلالی/کد ملی با راه‌حل‌های سادهٔ ایرانیِ نگهداری‌شده؛ حذف comparator تلفن/E.164/مسیرهای چندگانهٔ جلالی/kernel سفارشی | §11.5، §11.6، §11.8 |
| `D-12` | پردازش عکس خارج از دامنهٔ جاری (مالک جدا مدیریت می‌کند)؛ فقط الزام سادهٔ فیلد عکس | §11.7 |
| `D-13` | ممیزی فقط انسانی (ویرایش Officer/Admin) با GravityRevisions؛ بدون parity ممیزی API/import/سیستمی و بدون bridge سفارشی | §23، §16 |
| `D-14` | بدون مسیر مستقیم GFAPI update در حال حاضر؛ دانش عمومی GFAPI در corpus می‌ماند | §13، §18 |
| `D-15` | WP All Import مرجع sync شمارنده؛ کلید کسب‌وکار = کد ملی (تطبیق دقیق)؛ همان کد ملی → همان شمارنده؛ انتشار در import بعدی نه در لحظهٔ submit | §17، §18 |
| `D-16` | WP All Import شمارنده را می‌نویسد، نه پیشروی Flow؛ در صورت کفایت از bulk action بومی Flow استفاده شود؛ بدون completion سفارشیِ importer-محور | §18.6 |
| `D-17` | هدف چاپ/dossier نهایی معتبر است؛ candidate اولِ POC = `Gravity PDF Free` + لایهٔ چاپ SRWF. هیچ template/extension پولی در baseline چاپ مجاز نیست؛ PDF engine سفارشی ساخته نمی‌شود؛ renderer نهایی فقط پس از PASS POC فارسی/RTL/ZWNJ/اعداد/A4/search-copy و UX بدون دانلود دستی انتخاب می‌شود. Browser Print مسیر production موازی نیست. | §15، §25 (BP-10)، ADR-043 |

جزئیات کامل نگاشت تصمیم→بازنشانی و probeهای بازنشسته در بستهٔ سازه‌پذیری `SRWF_CONSTRUCTABILITY_KNOWLEDGE_BUNDLE_v0.6.3` (`validation/reprojection_report_v1_6_0.json` و `validation/current_verification_queue.json`) ثبت شده است.

### مجموعهٔ راستی‌آزمایی جاری

| کد | راستی‌آزمایی | probe |
|---|---|---|
| `V-01` | برش عملیاتی بومی Gravity Flow (Inbox → Entry Details → ویرایش فیلد مجاز → Approve) | `PRB-NF-V01` |
| `V-02` | تست دود حداقل دسترسی (عموم رد، Officer عملیاتی، Admin ادمین) | `PRB-NF-V02` |
| `V-03` | جست‌وجوی responsive فارسی نام مدرسه (فناوری‌خنثی تا اولین PASS) | `PRB-NF-V03-SCHOOL-SEARCH` |
| `V-04` | تاریخچهٔ ویرایش انسانی (ثبت/مشاهده/مقایسه/بازگردانی برای Admin) | `PRB-NF-V04-HUMAN-REVISION` |
| `V-05` | Live Refresh بومی / بدون cache بد | `PRB-NF-V05` |
| `V-06` | sync شمارندهٔ WP All Import بر کلید کد ملی | `PRB-NF-V06` |

**صداقت اجرا:** این سند و بسته اثبات اجرا در محیط واقعی نیستند. `execution_record_count = 0`، هیچ ادعای `OBSERVED_IN_STAGING` وجود ندارد، `V-01..V-06` همگی `UNEXECUTED` هستند و `BLK-ENV-001` فعال است. کامل‌بودن دانش، اثبات زمان اجرا نیست و وضعیت Builder همچنان `NOT_BUILDER_READY` است.


## 1. تصمیم اجرایی

### حکم

معماری منتخب `NATIVE_FIRST` است (D-01..D-17): ابتدا قابلیت بومی محصولات منتخب، و کد/افزونهٔ اضافی فقط برای gap اثبات‌شده.

1. **Gravity Forms** فرم، Entry، File Upload، Administrative Fields و validation پایه را مالک است.
2. **Gravity Flow** تنها engine معتبر workflow، assignment، Officer Approval و Accountant Approval است.
3. **WordPress** authentication، capability، nonce، runtime و lifecycle افزونه را مالک است.
4. **GravityView** فقط یک سطح ارائهٔ **اختیاری و فقط‌خواندنی** است. رابط عملیاتی مسئول ثبت‌نام، Inbox و Entry Details بومی Gravity Flow است؛ GravityView هرگز مرجع workflow، صف، تخصیص، Approval، Needs Review یا ویرایش عملیاتی نمی‌شود.
5. **GravityRevisions** روش منتخب تاریخچهٔ ویرایش‌های انسانی مهم است و دسترسی آن فقط Admin است (اثبات در `V-04`). هیچ parity ممیزی برای نوشتن‌های API/import/سیستمی الزام این پروژه نیست.
6. **Elementor** خارج از دامنهٔ عملیاتی جاری است؛ نه authorization است، نه Entry owner، نه workflow authority.
7. **کد اختصاصی** فقط در integration layer پروژه و با scope بسته و فقط برای gap اثبات‌شدهٔ قابلیت بومی مجاز است. هیچ handler سفارشی Needs Review و هیچ ماژول School/Photo/Audit/Counter اختصاصی الزام نیست.
8. **خرید افزونهٔ پولی** فقط پس از POCای مجاز است که necessity و برتری آن را نسبت به مسیر موجود ثبت کند.
9. **وضعیت بررسی** فقط در فیلد `review_status` و دلیل آن نگه‌داری می‌شود. Entry Notes الزام این پروژه نیست و Gravity Flow وضعیت رسمی workflow را نگه می‌دارد.
10. **صندوق عملیاتی، Inbox بومی Gravity Flow است** با جست‌وجو/فیلتر/مرتب‌سازی/بازچینش ستون بومی. هیچ Desk، لیست یا جدول سفارشی ساخته نمی‌شود و تمام Approval/Deleteهای GravityView برای Officer ممنوع‌اند.
11. **renderer نهایی هنوز `NOT_PROVEN` است، اما candidate اول قفل شده است.** `Gravity PDF Free` فقط موتور candidate است؛ لایهٔ چاپ SRWF مالک قالب/field mapping/صفحه‌بندی A4/permission/filename/print action است. هیچ template/extension پولی برای چاپ baseline مجاز نیست و هیچ PDF engine سفارشی پیش از شکست POC ساخته نمی‌شود.
12. **ابزارهای ایرانی و Gravity Perks/official add-onها** صرف وجود capability وارد runtime نمی‌شوند. هرکدام باید قرارداد canonical storage، server validation و پوشش write pathهای واقعی را پاس کنند.
13. **Counter فقط در Matrix/سامانهٔ ثبت بیرونی تولید می‌شود.** WordPress هیچ counterای تولید یا تخصیص نمی‌دهد و فقط مقدار خارجی را با National ID canonical به Entry eligible موجود import می‌کند. WP All Import کاندید update است، نه انتخاب قطعی؛ matching، ambiguity rejection، Flow preservation و whitelist باید در BP-5 اثبات شوند.
14. **Uncanny Automator** فقط لایهٔ مشروط cross-plugin/external automation است. مالکیت assignment، Needs Review، Approval، current step و workflow status برای آن ممنوع است.

### چرا این انتخاب برنده است؟

`Native-only` چند نیاز خاص را ندارد؛ custom-first نیز قابلیت‌های بالغ محصولات منتخب را دوباره می‌سازد. مسیر منتخب ابتدا از GF/Flow/GravityView و افزونهٔ تخصصیِ اثبات‌شده استفاده می‌کند و فقط gap باقیمانده را با کد کم‌دامنه می‌بندد. معیار متمایزکننده همچنان **صحت workflow و data contract** است و سپس کمترین هزینهٔ نگهداری کل.

### حدود قطعیت و مجوز اجرا

این نسخه ورود کنترل‌شده به اجرا را مجاز می‌کند؛ اما «اجرا» staged است. Stage 0، قرارداد معنایی، scaffold و prototypeهای critical مجازند و هیچ surface بدون Gate خودش production-ready محسوب نمی‌شود. موارد زیر compatibility/selection proof هستند، نه تصمیم دوبارهٔ parent architecture:

- صندوق عملیاتی واحد = Gravity Flow Inbox بومی با Live Refresh بومی (D-02/D-07)؛ Browser Notification فقط convenience؛
- ویرایش فیلدهای مجاز Officer و مقدار Needs Review از مسیر بومی Gravity Flow، بدون تکمیل step و بدون POST سفارشی (D-01/D-04)؛
- school selector روی موبایل با کل payload واقعی؛
- (خارج از دامنه) پردازش/بهینه‌سازی عکس؛
- import شمارنده با WP All Import بر کلید کد ملی و نهایی‌سازی با bulk بومی Flow؛ هیچ counter generation در WordPress و هیچ هدایت Flow توسط importer (D-15/D-16).
- (حذف‌شده) مسدودسازی/lookup تکراری وجود ندارد.
- ارائهٔ عملیاتی = Entry Details بومی Gravity Flow؛ GravityView/Elementor فقط ارائهٔ اختیاری فقط‌خواندنی و معوق.
- تاریخچهٔ actor/time/field/old/new فقط برای ویرایش‌های انسانی با GravityRevisions؛ بدون parity سیستمی/API (D-13).
- صندوق بومی Gravity Flow با جست‌وجو/فیلتر/مرتب‌سازی بومی؛ (D-02)
- (حذف‌شده) سیاست Entry Notes، redirect پس از ویرایش و Lightbox.
- کد ملی/موبایل/جلالی با راه‌حل‌های سادهٔ ایرانیِ نگهداری‌شده؛ بدون kernel/adapter سفارشی (D-11)؛
- D-17 اکنون `POC_GATED` است: ابتدا `Gravity PDF Free` با synthetic data؛ فقط PASS می‌تواند آن را renderer نهایی کند. Browser Print به‌عنوان مسیر production موازی نگه‌داری نمی‌شود.

این موارد `REQUIRES_BOUNDED_PROTOTYPE` در سطح component/target هستند، نه مانع آغاز کل implementation و نه دلیلی برای بازکردن تصمیم‌های `METHOD_SELECTED`. شکست prototype فقط همان surface را `SURFACE_BLOCKED` می‌کند؛ مسیرهای مستقل ادامه می‌یابند.

### مرز آمادگی برای اجرا

این نسخه «آمادهٔ شروع اجرای کنترل‌شده» است، نه مجوز پیاده‌سازی یک‌باره یا ورود دادهٔ واقعی. تفکیک مجوز به‌صورت زیر الزام‌آور است:

| اکنون مجاز است | تا عبور Gate مربوط ممنوع است |
|---|---|
| Stage 0 و ثبت environment/version inventory | نصب یا ارتقای production بر پایهٔ نسخهٔ فرضی |
| تکمیل و امضای Semantic Field Contract | ساخت fieldها با label/ID موقت به‌عنوان contract |
| ساخت scaffold Form/Flow/View پس از Gate 1A | feature logic پیش از bind شدن Implementation Mapping |
| اجرای Critical Decision Pack با دادهٔ مصنوعی | خرید dependency پولی پیش از پیروزی POC خودش |
| ساخت integration layer حداقلی پس از Binding Sheet | workflow/status/persistence موازی یا mutation از GET/template |
| اجرای BPهای just-in-time پیش از surface مصرف‌کننده | ورود PII واقعی پیش از privacy/retention sign-off |

حداقل artifactهای خروجی پیش از اولین release عبارت‌اند از: `Semantic Field Contract`، `Implementation Mapping`، `Environment Manifest`، گزارش POCهای critical، `Release Manifest`، `Rollback Runbook` و evidence اجرای Definition of Done. نبود هر artifact، همان Gate را باز نگه می‌دارد و با متن توصیفی جایگزین نمی‌شود.

---

## 2. مسئله، هدف و دامنه

### 2.1 مسئله

سامانه باید یک ثبت‌نام عمومی کم‌اصطکاک را به یک بررسی رسمی دو مرحله‌ای متصل کند، به Officer یک Desk ساده و قابل چاپ بدهد و پس از ثبت نهایی در سامانهٔ خارجی، شمارنده را به Entry صحیح بازگرداند. کاربران عمومی مهارت رایانه‌ای پایینی دارند و Officer باید بدون ورود به شلوغی wp-admin کار کند.

### 2.2 هدف

خروجی نسخهٔ اول:

- فرم عمومی جدید، single-page و mobile-first؛
- Officer Approval و Accountant Approval رسمی در Gravity Flow؛
- Needs Review به‌عنوان overlay همان Officer step؛
- رابط عملیاتی front-end بومی Gravity Flow بر پایهٔ Inbox + Entry Details؛ GravityView فقط ارائهٔ اختیاری فقط‌خواندنی؛ چاپ A4 تابع D-17 و PASS شدن POC renderer است؛
- تاریخچهٔ کامل ویرایش‌ها برای Admin: actor، زمان، فیلد و مقدار قبل/بعد؛
- مرز صریح downstream و importer محدود شمارنده؛
- حداقل custom/plugin footprint که correctness را کامل کند.

### 2.3 خارج از دامنه

- جایگزینی Gravity Forms یا Gravity Flow؛
- مهاجرت Entryهای فرم قدیمی یا حفظ Field IDهای آن؛
- بازطراحی Matrix2 Core یا سیاست allocation/ranking؛
- SPA، workflow engine دوم، WebSocket، message queue یا real-time service؛
- archive دائمی/مستقل PDF و document repository جدا؛ Gravity PDF فقط derived document از همان Entry است؛
- CPT/ACF/JetEngine موازی فقط برای رساندن Entry به Elementor؛
- داشبورد analytics، SLA، escalation یا search subsystem سفارشی؛ native search/filter فقط در صورت پیروزی BP-1؛
- semantics نهایی فیلدهای جانبی مانند postal/foreign-national مگر آنکه مستقیماً workflow را تغییر دهند.
- اتوماسیون cross-plugin/app بدون requirement واقعی؛ AI Agent/Page Builder و recipeهای کسب‌وکاری Automator خارج از دامنه‌اند.

---

## 3. اصول تصمیم و سبک نگهداری

این baseline با اولویت‌های جاری مالک هم‌راستاست: دستور صریح و constraint واقعی، سپس correctness و صداقت، سپس usability، سپس simplicity/maintainability. پیچیدگی فقط وقتی مجاز است که failure مشخصی را جلوگیری کند. منبع این preference model، commit جاری `0c6a0691…` در [Personal Preference Decision Model](https://github.com/rezahh107/Personal-Preference-Decision-Model/commit/0c6a069113a545fdaca89465d80044443cd61853) است؛ خود repository نیز تأکید می‌کند که prompt/document visibility معادل runtime enforcement نیست.

### 3.1 سلسله‌مراتب authority و applicability ترجیحات

ریپوی ترجیحات، راهنمای تصمیم است و authority قرارداد پروژه نیست. ترتیب حل تعارض در این سند چنین است:

1. دستور صریح و جاری مالک؛
2. قراردادهای اجباری همین پروژه و constraintهای واقعی platform/runtime؛
3. Core Preference جاری و واقعاً applicable؛
4. Domain Rule / Decision Rule جاری و applicable؛
5. Default Convention مشروط؛
6. historical lesson، tentative knowledge یا الگوی مشابه، فقط پس از gate انتقال و بدون غلبه بر سطوح بالاتر.

تشابه واژگانی به‌تنهایی applicability نمی‌سازد. `TENTATIVE`، `SUPERSEDED`، projection غیرcanonical و lesson بدون `STRUCTURAL_SIMILARITY_CHECK = MATCH` حق تغییر تصمیم ندارند. در نتیجه هیچ ترجیح شخصی نمی‌تواند `OWNER_LOCKED`، Field Contract یا Hard Gate این پروژه را بی‌صدا دور بزند.

### 3.2 نگاشت کمینهٔ preferenceهای canonicalِ مؤثر

این جدول فقط recordهای task-relevant را نگاشت می‌کند؛ projection تازه یا authority مستقل تولید نمی‌کند.

| recordهای canonical | trigger/applicability در این پروژه | اثر واقعی بر سند | guard |
|---|---|---|---|
| `CP-01`، `DR-01`، `DEF-QUAL-01` | ادعای capability، compatibility، success یا correctness | evidence state، Hard Gate، ممنوعیت overclaim و الزام proof | claim دقیق‌تر از evidence ممنوع |
| `CP-03`، `DR-04`، `AL-03` | افزودن plugin، service، class، table یا workflow state | Minimality Challenge و `WHAT_NOT_TO_BUILD` | فقط failure مشخص، complexity را توجیه می‌کند |
| `CP-05`، `DR-02`، `DR-03`، `CP-10` | مقایسهٔ گزینه‌ها، freeze تصمیم و handoff | candidate comparison، Decision Ledger، versioning، rollback و changelog | تصمیم تاریخی صرفاً به‌علت سابقه authority نیست |
| `CP-06` و `workflow.md` | ابهام واقعاً blocking یا next step | سؤال فقط در سطح مسدود، ادامهٔ surfaceهای مستقل، و دقیقاً یک اقدام بعدی | سؤال فنی قابل‌حل به مالک پاس داده نمی‌شود |
| `CP-08` و `communication.md` | عمق پاسخ و زبان تحویل | فارسی، evidence-backed و متناسب با پیچیدگی واقعی | جزئیات تزئینی نباید تصمیم را دوباره باز کند |
| `domains/research-validation.md` و `DEF-ENG-01` | claimهای current/technical | منبع رسمی و primary/current evidence مقدم است | حافظه یا مقالهٔ ثانویه جای source جاری نیست |
| `DEF-ENG-02` | انتخاب native/plugin/custom | هیچ خانواده‌ای مزیت پیشینی ندارد؛ lowest total burden برنده است | plugin count یا custom-code avoidance معیار مستقل نیست |
| `DEF-WP-01` | baseline WordPress/PHP | API عمومی، WPCS، lifecycle سازگار و staging regression | core edit و API منسوخ ممنوع |
| `EL-001` و `AL-06` | ادعای enforcement | جداسازی `NON_ENFORCING_GUIDANCE` از runtime/CI controls | حضور prose، YAML یا source معادل اجرا نیست |
| `MG-01` و `AL-04` | governance consequential یا drift | versioned evidence، reopen trigger و کنترل متناسب | governance نباید بدون failure واقعی به critical path تبدیل شود |
| `EL-002` | فقط وقتی governance خودِ delivery را مسدود کرده باشد | فعلاً `STRUCTURAL_SIMILARITY_CHECK = UNRESOLVED` و بدون اثر کنترلی؛ در آینده فقط bounded noncanonical bridge قابل بررسی است | Field Contract و gateهای اجباری قابل bypass نیستند |

قواعد عملی پروژه:

1. correctness یک Hard Gate است؛ plugin/native/custom بودن به‌خودی‌خود امتیاز نیست.
2. پس از برابری در correctness، گزینهٔ ساده‌تر، شفاف‌تر و قابل‌تست‌تر برنده است.
3. کد باید برای نگهداری توسط مدل‌های زبانی و یک مالک غیرتوسعه‌دهنده قابل فهم باشد: نام‌های روشن، moduleهای کم‌عمق، بدون framework و abstraction نمایشی.
4. «یک فایل عظیم» و «micro-classهای فراوان» هر دو رد می‌شوند؛ مسئولیت‌های مادی جدا، ولی call graph کوتاه می‌ماند.
5. هر ادعای اجرا، version، compatibility یا success باید قابل مشاهده و قابل بازتولید باشد.
6. مرحله‌ها مخلوط نمی‌شوند: Semantic Contract پیش از scaffold؛ ID Binding پس از scaffold؛ critical prototype پیش از dependency freeze؛ staging پیش از production.
7. rollback، audit و restart instruction بخشی از تحویل‌اند.
8. Handoff متنی `NON_ENFORCING_GUIDANCE` است. فقط invariantهای قابل‌اندازه‌گیری مانند ID mapping، version manifest، test result و ممنوعیت core edit می‌توانند بعداً توسط CI/static checks enforce شوند؛ هیچ اسکریپتی نباید وانمود کند فهم انسان یا مدل زبانی را اثبات کرده است.

---

## 4. شواهد و provenance بازرسی

### 4.1 محصولات رسمی

| موضوع | وضعیت جاری بازرسی‌شده | نتیجهٔ معماری |
|---|---|---|
| Gravity Forms | `3.0.3`، منتشرشده در ۲۰ اوت ۲۰۲۶؛ major 3.0 می‌تواند breaking change داشته باشد و vendor برای upgrade major تست sandbox می‌خواهد. [Changelog رسمی](https://docs.gravityforms.com/gravityforms-change-log/) | target باید روی 3.0.x واقعی تست شود؛ حافظهٔ مبتنی بر 2.x کافی نیست. |
| Gravity Flow | `3.1.0`، منتشرشده در ۱ ژوئیه ۲۰۲۶. [Changelog رسمی](https://docs.gravityflow.io/changelog/) | API/hookها روی نسخهٔ نصب‌شده inventory و regression test شوند. |
| Elementor | Editor `4.0` در ۱۵ آوریل ۲۰۲۶ live شد و عناصر V4 می‌توانند کنار Widgetهای 3.x استفاده شوند. [راهنمای رسمی](https://elementor.com/help/get-started-with-the-elementor-editor-v4/) | استفادهٔ GravityView widget در سایت V4 `LIKELY` است؛ Atomic V4-native بودن آن `NOT_PROVEN` و خارج از POC پایه است. |
| GravityView | changelog رسمی `3.3.2` در ۲۰ اوت ۲۰۲۶ را ثبت می‌کند؛ از جمله رفع Edit Entry برای فرم‌هایی که Hidden Field کنترل‌کنندهٔ Conditional Logic یا dynamic choices دارند. GravityView 3 پنج widget بومی page-builder و Layout Builder دارد. [Changelog](https://www.gravitykit.com/products/gravityview/changelog/) | این fix برای BP-3 مرتبط است، اما compatibility کامل selector را اثبات نمی‌کند؛ نسخهٔ نصب‌شدهٔ target فقط در Stage 0 manifest authority اجرایی می‌گیرد. |
| GravityRevisions | نسخه `1.8.0` در ۴ ژوئن ۲۰۲۶ منتشر و صفحهٔ محصول ۵ ژوئن به‌روزرسانی شده است. Changelog `1.3.0` API revision را Added می‌داند، ولی docs جاری API logging را رد می‌کنند. [Changelog](https://www.gravitykit.com/products/gravityrevisions/changelog/)؛ [Restore](https://www.gravitykit.com/docs/gravityrevisions/gravity-foms-revert-changes-to-entry/) | روش منتخب human audit؛ API conflict محافظه‌کارانه `NOT_PROVEN` و per-path bridge مشروط است. |
| GravityImport | `2.12.0` در ۳۰ ژوئیه ۲۰۲۶ در changelog vendor ثبت شده است. [Changelog](https://www.gravitykit.com/products/gravityimport/changelog/) | current بودن، مشکل delete/replace Entry را برای این use case حل نمی‌کند. |
| Gravity PDF | docs جاری در ۲۸ ژوئیه ۲۰۲۶ به‌روزرسانی شده و A4/custom paper، RTL، custom font و background را مستند می‌کند. [Setup](https://docs.gravitypdf.com/users/setup-pdf) | Core کاندید owner-approved برای BP-10؛ local derived document، نه data SSOT. |
| WP All Import + GF Add-On | import/mapping/scheduling GF Entry و same-import selective update مستند است؛ exact arbitrary-existing matching contract روشن نیست. [GF Import](https://www.wpallimport.com/documentation/how-to-import-gravity-forms-entries/) | Counter comparator، نه selected engine. |
| Uncanny Automator | public listing بیش از ۴۰٬۰۰۰ نصب فعال و integration جاری GF دارای Create/Submit/Update/Delete است. [WordPress.org](https://wordpress.org/plugins/uncanny-automator/) | mature but broad؛ deferred external/cross-plugin layer، نه Flow جایگزین. |
| Parsi Date | Persianization عمومی/فعال WordPress و claim سازگاری GF؛ source/docs contract دقیق GF3 storage/picker را نشان ندادند. [WordPress.org](https://wordpress.org/plugins/wp-parsidate/) | mature platform، ولی راه‌حل Jalali پروژه `NOT_PROVEN`. |
| WordPress | راهنمای رسمی plugin، capability، nonce، validation/escaping و hooks بازرسی شد. [Plugin Handbook](https://developer.wordpress.org/plugins/) | هر minimal bridge باید بر API عمومی WordPress و WPCS تکیه کند. |

### 4.2 capabilityهای رسمی تعیین‌کننده

- Gravity Flow Inbox برای taskهای assigned، `Live Data Refresh`، `Browser Notifications`، fullscreen، search، column filtering و multi-column sort دارد؛ Quick Actions، required editable-field validation را bypass می‌کنند. [Inbox](https://docs.gravityflow.io/the-inbox-page/)
- Entry Detail front-end از block/shortcode قابل دسترسی است و نمایش آن به user/role، step، setting و filter وابسته است؛ Approval/User Input می‌توانند editable field تعیین کنند. [Entry Details](https://docs.gravityflow.io/the-entry-details-page/)
- Approval Step، `Require Confirmation`، editable fields و workflow note دارد و اولین assignee موفق که validation را رد کند step را جلو می‌برد. [Approval Step](https://docs.gravityflow.io/approval-step-type/)
- Gravity Flow برای افزودن control به Approval detail، تعریف assignee status سفارشی، تغییر evaluation status و کنترل validation hookهای رسمی دارد: [`gravityflow_above_approval_buttons`](https://docs.gravityflow.io/gravityflow_above_approval_buttons/)، [`gravityflow_approval_assignee_status_types`](https://docs.gravityflow.io/gravityflow_approval_assignee_status_types/)، [`gravityflow_step_status_evaluation_approval`](https://docs.gravityflow.io/gravityflow_step_status_evaluation_approval/) و [`gravityflow_validation_approval`](https://docs.gravityflow.io/gravityflow_validation_approval/). وجود این extension pointها `CONFIRMED` است؛ ترتیب دقیق save و failure semantics پروژه هنوز `NOT_PROVEN` است.
- REST API V2 می‌تواند current interactive step را process کند، اما طبق مستندات جاری فقط `Approval` و `User Input` را پشتیبانی می‌کند و capability پیش‌فرض `gravityflow_admin_actions` می‌خواهد. [Process Current Step](https://docs.gravityflow.io/process-the-current-step-with-rest-api-v2/)
- Gravity Forms Administrative visibility و Choice Value مستقل از label را پشتیبانی می‌کند. [Common Field Settings](https://docs.gravityforms.com/common-field-settings/) و [Field Object](https://docs.gravityforms.com/field-object/)
- `GFAPI::update_entry()` و `GFAPI::update_entry_field()` نتیجهٔ Boolean یا `WP_Error` می‌دهند و باید بررسی شوند. [Updating Entries](https://docs.gravityforms.com/updating-entries-with-the-gfapi/)
- WordPress استفاده از capability check، nonce، validation/sanitization و escaping متناسب با context را لازم می‌داند. [Capabilities](https://developer.wordpress.org/plugins/security/checking-user-capabilities/)، [Nonces](https://developer.wordpress.org/plugins/security/nonces/)، [PHP Coding Standards](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/php/)
- `wp_get_image_editor()` abstraction رسمی پردازش تصویر وردپرس است. [Code Reference](https://developer.wordpress.org/reference/functions/wp_get_image_editor/)
- GravityView می‌تواند inbox سفارشی workflow بسازد و با Advanced Filter فقط Entryهای assigned به Current User را نشان دهد؛ Editهای GravityView به‌طور پیش‌فرض مستقل از Gravity Flow هستند. [Gravity Flow integration](https://docs.gravityflow.io/gravityview-integration/)
- GravityView 3 در Elementor/Divi/Beaver پنج widget هسته‌ای `View`, `Entry`, `Entry Field`, `View Details`, `Entry Link` دارد. [Page Builder Support](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/page-builder-support/)
- مستند block متناظر برای Entry و Entry Field، `Entry ID` مشخص می‌خواهد؛ وراثت خودکار Current Entry در widgetهای مستقل Elementor فعلاً `NOT_PROVEN` است. [Embedding Entries and Fields](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/embedding-views-entries-and-fields-using-blocks/)
- GravityView Layout Builder و Custom Content/DIY مسیرهای native برای layout سفارشی هستند؛ Advanced Elementor Widget یک View موجود را visually style می‌کند و با widgetهای پنج‌گانه یکی نیست. [Layout Builder](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/the-layout-builder-when-and-how-to-use-it/)، [Custom Content](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/using-the-custom-content-field/)، [Advanced Elementor Widget](https://www.gravitykit.com/docs/gravityview-pro/advanced-elementor-widget/getting-started-with-advanced-elementor-widget/)
- GravityView از نسخهٔ 2.6 Entry Locking دارد و از 2.7 setting مستقل آن را ارائه می‌کند؛ lock به WordPress Heartbeat متکی است و معمولاً حدود ۱۵ ثانیه چرخه دارد. [Entry Locking](https://www.gravitykit.com/docs/gravityview/edit-entry/entry-locking/)
- GravityView Entry Notes در front-end می‌تواند مشاهده/افزوده/حذف و ایمیل شود و capabilityهای مستقل دارد؛ از `3.3.0` می‌تواند count، Yes/No یا متن سفارشی را به‌جای محتوای Notes نشان دهد. [Entry Notes](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/the-entry-notes-field/) و [Changelog](https://www.gravitykit.com/products/gravityview/changelog/)
- Redirect After Editing می‌تواند کاربر را روی Edit نگه دارد، به Single Entry، Multiple Entries یا URL دارای merge tag بفرستد. [Redirect After Editing](https://www.gravitykit.com/docs/gravityview/edit-entry/view-settings-redirect-after-editing/)
- Frontend Bulk Actions فقط برای `Table layout` مستند شده و شامل Export و Download Attachments است؛ Approval/Disapproval آن، state داخلی GravityView را تغییر می‌دهد و معادل Flow Approval نیست. Form دارای Conditional Logic، Bulk Edit را طبق هشدار رسمی `3.1.0` غیرقابل‌اجرا می‌کند. [Bulk Actions](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/frontend-bulk-actions/) و [Changelog](https://www.gravitykit.com/products/gravityview/changelog/)
- DataTables در mode `AJAX` فقط صفحهٔ جاری را برای CSV/Excel/PDF/Print export می‌کند؛ preload همهٔ نتایج را export می‌کند ولی بار اولیهٔ بزرگ‌تری دارد. [DataTables processing](https://www.gravitykit.com/docs/gravityview-pro/datatables/client-side-processing/)
- Single/Edit Entry می‌تواند در Lightbox باز شود، ولی capability داشتن modal، suitability آن برای paper view، print، deep-link و accessibility این پروژه را اثبات نمی‌کند. [Lightbox](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/opening-and-editing-entry-details-in-a-lightbox-modal-popup/)
- Capability list granular است، اما `gravityview_edit_entries` هنوز کنترل عمومی edit را پیاده نمی‌کند و GravityView به‌طور پیش‌فرض می‌تواند creator را قادر به ویرایش Entry خودش کند؛ پس role/capability به‌تنهایی assignee authorization را اثبات نمی‌کند. [Capabilities](https://www.gravitykit.com/docs/gravityview/roles-and-capabilities/gravityview-capabilities/)
- Enhanced Security، secret مربوط به embed را الزام می‌کند و حدس View ID را دشوار می‌سازد؛ این secret جای per-entry capability/assignee/current-step authorization را نمی‌گیرد. [Enhanced Security](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/enable-enhanced-security-the-secret-attribute-for-shortcodes/)
- GravityRevisions تغییرات Entry در GF/GV را مستند می‌کند. درباره API تعارض رسمی وجود دارد: changelog `1.3.0` support را اعلام، ولی Restore docs جاری آن را رد می‌کند؛ production تا runtime proof به API auto-revision تکیه نمی‌کند. [Changelog](https://www.gravitykit.com/products/gravityrevisions/changelog/)؛ [Restore](https://www.gravitykit.com/docs/gravityrevisions/gravity-foms-revert-changes-to-entry/)
- Chained Selects روابط معتبر را از CSV تعریف می‌کند و education یک use case رسمی است؛ dynamic filters نیز وجود دارند، ولی search-as-you-type در chain فعلی مستند نشد. [When and Why](https://docs.gravityforms.com/when-and-why-to-use-chained-selects/)
- WP All Import می‌تواند GF Entryها را map/schedule کند و در rerun همان Import «Choose which data to update» دارد؛ این claim به‌تنهایی match کردن arbitrary existing Entry را اثبات نمی‌کند. [Import](https://www.wpallimport.com/documentation/how-to-import-gravity-forms-entries/)؛ [Migration](https://www.wpallimport.com/documentation/how-to-migrate-gravity-forms-entries/)
- Gravity PDF paper/orientation/font/RTL/background/header/footer و custom template را مستند می‌کند؛ mPDF از Browser CSS کامل و Flex/Grid parity پشتیبانی نمی‌کند. [Setup](https://docs.gravitypdf.com/users/setup-pdf)؛ [HTML/CSS](https://docs.gravitypdf.com/developers/pdf-features/supported-html-and-css)
- Uncanny Automator GF actions و field/status update triggers را مستند می‌کند، اما integration مستقلی با Gravity Flow و semantics کامل validation/Flow initialization در catalog جاری یافت نشد. [GF Integration](https://automatorplugin.com/integration/gravity-forms/)
- Gravity Flow Incoming/Outgoing Webhook می‌تواند workflow را در step منتظر external input نگه دارد یا request/response mapping انجام دهد؛ برای process integration پیش از Automator بررسی می‌شود. [Incoming](https://docs.gravityflow.io/incoming-webhook-workflow-step/)؛ [Outgoing](https://docs.gravityflow.io/outgoing-webhook-step-type/)

### 4.3 مخازن

| Repository | branch/commit بازرسی‌شده | یافتهٔ مادی |
|---|---|---|
| Matrix2 | `main` @ [`24a13e928808715953b3c1260b6ac7271c7dfe31`](https://github.com/rezahh107/Matrix2/commit/24a13e928808715953b3c1260b6ac7271c7dfe31)، ۲۰ اوت ۲۰۲۶ | defect قبلی اصلاح شده: `Gender.FEMALE = 0`، `Gender.MALE = 1`؛ policy نیز female=0/male=1 دارد و تست drift اضافه شده است. `CONFIRMED` |
| PersianGravity | `main` @ [`83f2cbfb5425984ac6545a6075497606efd81508`](https://github.com/rezahh107/PersianGravity/commit/83f2cbfb5425984ac6545a6075497606efd81508)، ۵ مه ۲۰۲۶ | national-ID و Jalali code وجود دارد؛ ولی metadata آن `Tested up to 6.6` است، repository هم legacy و refactor را کنار هم دارد، و legacy Jalali خود را experimental می‌نامد و در Elementor return می‌کند. suitability روی WP/GF جاری `NOT_PROVEN` است. |
| Personal Preference Decision Model — canonical current | `main` @ [`0c6a069113a545fdaca89465d80044443cd61853`](https://github.com/rezahh107/Personal-Preference-Decision-Model/commit/0c6a069113a545fdaca89465d80044443cd61853)، re-check در ۲۱ اوت ۲۰۲۶ | preferenceهای task-relevant از `knowledge/current` و governance مرتبط به‌صورت انتخابی خوانده شدند؛ correctness hard gate، minimum sufficient complexity، primary/current evidence، versioned handoff و تفکیک prose/enforcement بر این سند اثر دارند. |
| Personal Preference Decision Model — projection freshness | [`repository.manifest.yaml`](https://github.com/rezahh107/Personal-Preference-Decision-Model/blob/0c6a069113a545fdaca89465d80044443cd61853/repository.manifest.yaml) projectionها را `NON_CANONICAL` و مشتق از `6a3e46713a4c39d953c4ae358ef96741337b3e73` اعلام می‌کند، درحالی‌که HEAD جاری `0c6a0691…` است. | `PROJECTION_FRESHNESS = STALE_AFTER_ACCEPTED_SEMANTIC_CHANGE`؛ این سند projectionها را semantic authority نگرفته و canonical recordهای جاری را مستقیم بازرسی کرده است. |

طبق [`AGENT_ENTRYPOINT.md`](https://github.com/rezahh107/Personal-Preference-Decision-Model/blob/0c6a069113a545fdaca89465d80044443cd61853/AGENT_ENTRYPOINT.md)، projection که پس از accepted semantic change refresh نشده باشد نباید current routing view فرض شود. این drift نقص parent architecture حاضر نیست؛ فقط provenance و روش retrieval را محدود می‌کند.

### 4.4 شواهد در دسترس نبودند

موارد زیر در این بازرسی ارائه نشدند و جزئیات وابسته به آن‌ها `NOT_PROVEN` است:

- `Crosswalk.xlsx`؛
- SchoolReport و فهرست نهایی normalize‌شدهٔ مدارس؛
- Gravity Forms JSON قدیمی؛
- reference image/paper form؛
- inventory واقعی site: نسخهٔ WordPress/PHP/MySQL، theme، Elementor، cache/CDN و pluginهای نصب‌شده؛
- Form/Field/Step IDهای فرم جدید؛
- نمونهٔ واقعی Excel شمارنده؛
- source ZIP/runtime behavior همیار Gravity و exact licensed add-on versions؛
- UI واقعی WP All Import Gravity Forms Add-On برای Match Existing و test license؛
- فونت فارسی نهایی، PDF paper reference و printer profile؛
- requirement واقعی cross-plugin/external که Automator را توجیه کند؛
- server limits و حافظهٔ پردازش تصویر.

نبود این موارد parent architecture را متوقف نمی‌کند، اما Field Contract، CSS چاپ، انتخاب school widget، photo strategy و importer را تا gate مربوط باز نگه می‌دارد.

---

## 5. تصمیم‌های مادر تثبیت‌شده

1. `OWNER_LOCKED`: WordPress + Gravity Forms + Gravity Flow parent architecture است.
2. Gravity Forms مالک data/entry؛ Gravity Flow مالک state/progression/formal approval؛ WordPress مالک identity/capability/runtime است.
3. Matrix2 downstream است و workflow state را تفسیر نمی‌کند.
4. فرم جدید ساخته می‌شود؛ فرم قدیمی فقط reference است؛ migration و حفظ Field ID قدیمی ممنوع است.
5. Crosswalk authority source است، نه runtime dependency؛ production هیچ Excel crosswalk را در request باز نمی‌کند.
6. implementation در دو Gate انجام می‌شود: Semantic Field Contract پیش از scaffold؛ Implementation Mapping شامل IDهای واقعی پس از scaffold و پیش از feature code freeze. این تفکیک circular dependency ایجاد Field ID را حذف می‌کند.
7. Needs Review step/branch/workflow دوم نیست و Officer step را ترک نمی‌کند.
8. Officer Approval و Accountant Approval هر دو formal Gravity Flow Approval هستند.
9. `POC_GATED / NOT_PROVEN`: هدف چاپ/dossier معتبر است؛ candidate اول D-17 = `Gravity PDF Free` + لایهٔ چاپ SRWF. Browser Print مسیر production موازی نیست و renderer نهایی فقط پس از PASS POC §15.5 انتخاب می‌شود.
10. فقط Entryهای عبورکرده از هر دو approval برای downstream مجازند.
11. `OWNER_LOCKED`: Officer نام/گزینهٔ قابل‌فهم مدرسه، گروه/مسیر تحصیلی و وضعیت تحصیلی را از control بومی ویرایش می‌کند؛ سیستم code/value canonical متناظر را در پشت‌صحنه به‌روزرسانی می‌کند. raw technical code مستقیماً به Officer نمایش داده یا برای ویرایش مستقیم باز نمی‌شود.
12. `OWNER_LOCKED`: مقدار `school_code=0` workflow یا ثبت نهایی را متوقف نمی‌کند و Admin می‌تواند بعداً کد را اصلاح کند.
13. `OWNER_LOCKED`: DOB فقط باید یک تاریخ جلالی واقعی و معتبر باشد؛ age range و grade-age rule در نسخهٔ اول وجود ندارد.
14. `OWNER_LOCKED`: عکس معمول گوشی پذیرفته و ذخیره می‌شود. پردازش/بهینه‌سازی عکس خارج از دامنهٔ جاری است و هدف اندازهٔ خروجی الزام این نسخه نیست. (تاریخی: بازهٔ ۱۵ تا ۶۰ کیلوبایت هدف پیشین بود، نه hard validation، و افت کیفیت نباید برای رسیدن دقیق به آن تحمیل شود.
15. `OWNER_LOCKED`: کد ملی کلید کسب‌وکار و کلید تطبیق شمارنده است. **مسدودسازی تکراری کاملاً حذف شده** و کد ملی تکراری مجاز است. همهٔ Entryهای دارای یک کد ملی همان `registration_counter` را می‌گیرند؛ یکسان‌سازی در زمان import و با تطبیق دقیق کد ملی انجام می‌شود، نه در لحظهٔ submit. subsystem لینک/auto-linking ساخته نمی‌شود.
16. `OWNER_LOCKED`: تاریخچهٔ کامل تغییرات فقط برای Admin قابل مشاهده است و در رابط Officer پنهان می‌ماند.
17. `OWNER_LOCKED`: هیچ افزونهٔ پولی پیش از POC اثبات‌کنندهٔ نیاز خریداری نمی‌شود.
18. `OWNER_LOCKED`: رابط عملیاتی اصلی، Gravity Flow بومی (Inbox و Entry Details) است. GravityView فقط `OPTIONAL_PRESENTATION_ONLY_SURFACE` است و هرگز مرجع workflow/queue نیست؛ Gravity Flow تنها authority گردش‌کار می‌ماند.
19. `OWNER_LOCKED`: baseline نمایش عملیاتی، Entry Details بومی Gravity Flow است (چیدمان یک/دو ستونی، نمایش/عدم‌نمایش فیلدها و Timeline). GravityView/Elementor فقط ارائهٔ اختیاری فقط‌خواندنی و معوق‌اند.
20. `OWNER_LOCKED`: وضعیت بررسی فقط در فیلد `review_status` و دلیل آن نگه‌داری می‌شود. Entry Notes الزام این پروژه نیست و هیچ نقشی در Needs Review، queue یا workflow ندارد؛ در صورت نیاز به یادداشت رسمی، از Workflow Note بومی گام Approval استفاده می‌شود.
21. `SELECTED`: Officer می‌تواند Note را ببیند و اضافه کند؛ حذف یا email کردن Note برای Officer در baseline ممنوع است.
22. `OWNER_LOCKED`: ویرایش و Approval از مسیر بومی Gravity Flow انجام می‌شود؛ رفتار پس از ویرایش همان رفتار بومی Gravity Flow است و مسیر بازگشت سفارشی ساخته نمی‌شود.
23. `OWNER_LOCKED`: Entry Details بومی Gravity Flow مسیر اصلی بررسی/ویرایش است؛ Lightbox/Full Single Entry فقط در صورت استفاده از ارائهٔ اختیاری GravityView مطرح‌اند.
24. `OWNER_LOCKED`: صندوق عملیاتی واحد = Gravity Flow Inbox بومی با جست‌وجو/فیلتر/مرتب‌سازی/بازچینش ستون بومی. bulk approve/reject بومی Inbox در صورت نیاز مسیر نهایی‌سازی است (D-16). GravityView Bulk Approval/Delete استفاده نمی‌شود.
25. `SELECTED`: Gravity Flow تنها business workflow engine است؛ Automator/Importer/PDF/Elementor حق مالکیت state، assignment یا Approval ندارند.
26. `OWNER_LOCKED`: Needs Review فقط یک فیلد Entry معمولی + فیلد دلیل است. POST اعتبارسنجی‌شدهٔ سفارشی حذف شد؛ ویرایش فیلدهای مجاز از مسیر بومی Gravity Flow (whitelist گام) انجام می‌شود و هیچ status/step/transition سفارشی ایجاد نمی‌شود.
27. `OWNER_LOCKED`: `school_code`=Value و `school_name`=Label، `0`=Other. تنها معیار مادی، جست‌وجوی responsive فارسی روی موبایل است. از ساده‌ترین راه بومی/نگهداری‌شده (Drop Down + Enhanced UI) شروع می‌شود و اگر تست موبایل پاس شد همان‌جا توقف؛ comparator سه‌گانه و chaining استان→شهر حذف شد.
28. `OWNER_LOCKED`: ممیزی فقط برای ویرایش‌های انسانی Officer/Admin با GravityRevisions است. parity ممیزی API/import/سیستمی و bridge سفارشی حذف شد. Timeline، Revisions و Notes سه artifact مستقل می‌مانند.
29. `OWNER_LOCKED`: کد ملی/موبایل/جلالی با راه‌حل‌های سادهٔ ایرانیِ نگهداری‌شده مدیریت می‌شوند. kernel قطعی سفارشی و adapterهای چندگانه حذف شدند؛ external identity service/framework عمومی همچنان ممنوع است.
30. `OWNER_LOCKED`: شمارهٔ موبایل با راه‌حل سادهٔ ایرانیِ نگهداری‌شده اعتبارسنجی/ذخیره می‌شود. DOB جلالی با راه‌حل سادهٔ نگهداری‌شده مدیریت می‌شود.
31. `OWNER_LOCKED`: شمارنده بیرون تولید می‌شود و **WP All Import مرجع sync شمارنده** بر کلید کد ملی است؛ فقط فیلد شمارنده را می‌نویسد و پیشروی Flow را هدایت نمی‌کند. نهایی‌سازی در صورت نیاز با bulk action بومی Flow انجام می‌شود.

---

## 6. مرز مسئولیت سیستم

```mermaid
flowchart TD
    U["دانش‌آموز"] --> GF["Gravity Forms<br/>Form + Entry + Files"]
    GF --> FLOW["Gravity Flow<br/>Assignment + Approval State"]
    WP["WordPress<br/>Auth + Capability + Runtime"] --> DESK["Gravity Flow<br/>Inbox + Entry Details (رابط عملیاتی)"]
    FLOW --> DESK
    GF --> DESK
    DESK --> REV["GravityRevisions<br/>Admin-only Change History"]
    GV["GravityView<br/>ارائهٔ اختیاری فقط‌خواندنی"] -.-> DESK
    GF --> GV
    FLOW --> EXT["Matrix/سامانه ثبت بیرونی<br/>Counter Authority"]
    EXT --> BR["WP All Import<br/>Counter Sync Authority"]
    BR --> GF
    AUTO["Uncanny Automator<br/>Deferred External Integration"] -.-> GF
    BR --> FLOW
    GF --> M2["Matrix2<br/>Approved dataset only"]
```

| مالک | مسئولیت دقیق | مسئولیت ممنوع |
|---|---|---|
| Gravity Forms | form schema، Entry، upload، Administrative Fields، validation hooks، export base | workflow authority یا Needs Review state machine مستقل |
| Gravity Flow | current step، assignment، Officer/Accountant Approval، timeline، Inbox، progression | school contract، national-ID algorithm یا external registration |
| WordPress | login/session، roles/capabilities، nonce، request lifecycle، image abstraction | business workflow |
| GravityView (اختیاری، فقط ارائه) | فقط نمایش فقط‌خواندنی اختیاری (Table/List/Layout Builder، Single Entry فقط‌فیلد) | Desk عملیاتی، workflow state/approval/queue، ویرایش پایه یا authorization در UI |
| GravityRevisions | ثبت و مقایسهٔ revisionهای انسانی، restore allowlist برای Admin | فرض پوشش خودکار GFAPI، نمایش history به Officer، restore دادهٔ workflow/system یا workflow state |
| Elementor (خارج از دامنه) | — | authorization، Entry context authority، edit lifecycle یا duplicate data |
| Gravity PDF مشروط | render سند مشتق از saved GF Entry | مالکیت داده، screen renderer یا workflow state |
| Minimal Project Layer | فقط چسب کم‌دامنه در نقاطی که قابلیت بومی واقعاً کم دارد؛ بدون endpoint سفارشی Needs Review، بدون kernel/adapter اعتبارسنجی سفارشی، بدون قاعدهٔ duplicate و بدون audit bridge | Desk/template سفارشی، database مستقل، workflow/audit engine یا concurrency سفارشی |
| WP All Import مشروط | update محدود و auditشدهٔ فیلدهای Counter پس از match اثبات‌شده | Create registration، broad update، delete missing، Flow progression یا validation authority |
| Uncanny Automator deferred | external/cross-plugin event و bounded whitelisted action | business workflow، assignment/approval/current step، deletion یا direct SQL GF writes |
| افزونهٔ ثالث اختیاری | فقط یک gap تخصصی که در prototype برنده شده | authority روی approval/state یا خرید پیش از evidence |
| Matrix/سامانهٔ ثبت خارجی | انجام ثبت نهایی و تولید authoritative counter | تفسیر GF/Flow step یا write مستقیم در جدول‌های WordPress |
| Matrix2 | دریافت dataset از پیش approved و اجرای منطق downstream موجود | پرسش «Officer/Accountant approved؟» |

---

## 7. قراردادهای دادهٔ قطعی

### 7.1 Machine Values

| مفهوم | Label | Value | authority/status |
|---|---|---:|---|
| Gender | female | `0` | `OWNER_LOCKED` + Matrix2 `CONFIRMED` |
| Gender | male | `1` | `OWNER_LOCKED` + Matrix2 `CONFIRMED` |
| Center | main/no special selection | `0` | `OWNER_LOCKED` |
| Center | Golestan | `1` | `OWNER_LOCKED` |
| Center | Sadra | `2` | `OWNER_LOCKED` |
| Finance | Normal | `0` | `OWNER_LOCKED` + Matrix2 policy `CONFIRMED` |
| Finance | Foundation | `1` | `OWNER_LOCKED` + Matrix2 policy `CONFIRMED` |
| Finance | Hekmat | `3` | `OWNER_LOCKED` + Matrix2 policy `CONFIRMED` |
| School | Other/not in list | `0` | `OWNER_LOCKED` |

Label فارسی contract فنی نیست. Choice Value باید مستقل، پایدار و در Field Contract ثبت شود.

### 7.2 قواعد مهم

- `school_code=0` بلافاصله هنگام انتخاب Other ذخیره می‌شود؛ null، random و legacy placeholder ممنوع است. این مقدار workflow یا ثبت نهایی را block نمی‌کند.
- Officer نام/گزینهٔ انسانی مدرسه را ویرایش می‌کند؛ raw `school_code` مستقیماً editable نیست. تغییر انتخاب معتبر توسط Officer باید system-mediated به Value/code canonical متناظر تبدیل و ذخیره شود؛ Admin همچنان می‌تواند اصلاح اداری مستقیم انجام دهد.
- National ID پس از تبدیل ارقام فارسی/عربی به ASCII دقیقاً ۱۰ رقم و checksum معتبر دارد و ASCII ذخیره می‌شود.
- محدودکردن ورودی به «فقط رقم انگلیسی» معادل normalization نیست. تمام write pathهای مجاز باید Persian/Arabic digits را طبق قرارداد یکسان normalize کنند یا صریحاً و با UX پذیرفته‌شده رد کنند؛ رفتار نهایی در BP-9 freeze می‌شود.
- هیچ مسدودسازی تکراری‌ای وجود ندارد؛ ارسال عمومی با کد ملی تکراری مجاز است و همهٔ Entryها حفظ می‌شوند. یکسان‌سازی شمارنده در زمان import انجام می‌شود.
- DOB به صورت canonical `YYYY/MM/DD` در تقویم Jalali ذخیره/نمایش می‌شود و فقط صحت واقعی تاریخ بررسی می‌شود؛ محدودیت سنی یا تطبیق سن با پایه اعمال نمی‌شود. canonical DOB در native Gravity Forms Date field قرار نمی‌گیرد، زیرا آن field مقدار را با semantics میلادی `Y-m-d` ذخیره می‌کند؛ سه input کنترل‌شده یا Text/Hidden contract استفاده می‌شود.
- تبدیل Jalali↔Gregorian یک derived representation است و تا تصمیم صریح مالک حق تغییر قرارداد canonical بالا را ندارد. اگر BP-9 نیاز downstream به Gregorian `Y-m-d` را اثبات کرد، Field Contract باید source value، derived value، timezone-free semantics و migration impact را جدا ثبت کند.
- شمارهٔ همراه با راه‌حل سادهٔ ایرانیِ نگهداری‌شده اعتبارسنجی و ذخیره می‌شود؛ ارقام فارسی/عربی و صفر ابتدایی پذیرفته و normalize می‌شوند. قرارداد canonical سفارشی E.164 حذف شده است.
- نام انسانی با Unicode NFC و trim مرزی ذخیره می‌شود؛ حذف نیم‌فاصله، اعراب، punctuation یا تبدیل تهاجمی `ی/ي` و `ک/ك` در source value ممنوع است. search/comparison key می‌تواند جداگانه و derived normalize شود و source name را بازنویسی نمی‌کند.
- ورودی عکس باید برای کاربر عادی باشد؛ JPG/JPEG متعارف گوشی پذیرفته می‌شود و پردازش تصویر خارج از دامنهٔ جاری است. (تاریخی: server/client component منتخب آن را بهینه می‌کند. بازهٔ ۱۵–۶۰KB هدف عملیاتی است، نه شرط رد ارسال.
- Crosswalk تعیین‌کنندهٔ level→grade/group و group×educational status است؛ UI و server هر دو آن را اعمال می‌کنند.

### 7.3 conflict protocol

اگر Crosswalk نهایی و contract جاری Matrix2 تناقض مادی داشتند:

1. مقدار دقیق Crosswalk؛
2. مقدار دقیق Matrix2 و path/commit؛
3. اثر functional؛
4. کوچک‌ترین تصمیم مالک؛

ثبت می‌شود. فقط surface متاثر متوقف و باقی کار ادامه می‌یابد. normalization خاموش و انتخاب silent ممنوع است.

---

## 8. مدل workflow و state

```mermaid
stateDiagram-v2
    [*] --> OfficerPending: Public Submit
    state OfficerPending {
        [*] --> New
        New --> NeedsReview: "Overlay metadata only"
        NeedsReview --> NeedsReview: "Edit reasons/data"
        NeedsReview --> New: "No explicit transition"
    }
    OfficerPending --> AccountantPending: Formal Officer Approval
    AccountantPending --> ExternalPending: Formal Accountant Approval
    ExternalPending --> CounterImported: External registration + import
    CounterImported --> Completed: Verified Flow completion
    Completed --> [*]
```

> خط `New → NeedsReview` در نمودار فقط تغییر metadata داخل state مرکب `OfficerPending` است؛ Gravity Flow step، assignee و formal status همچنان Pending می‌مانند. هیچ workflow transition، branch یا step جدیدی رخ نمی‌دهد.

### invariants قابل اجرا

| invariant | حامل واقعی enforcement |
|---|---|
| Entry فقط در Officer current step می‌تواند Needs Review شود | server-side current-step + assignee check در Gravity Flow API/object |
| Officer Approval رسمی است | native Gravity Flow Approval processing |
| Needs Review مانع Accounting است | همان Pending Officer step؛ نه یک Boolean سفارشی |
| invalid education combination ذخیره نمی‌شود | Gravity Forms server validation بر مبنای snapshot تأییدشده Crosswalk |
| direct URL مجوز نمی‌سازد | WordPress capability + Gravity Flow assignee check در هر request |
| success واقعی است | نتیجهٔ GFAPI/Gravity Flow و post-condition server، سپس PRG response |
| چاپ unsaved data ندارد | server-rendered saved model + dirty-state print disable |
| Matrix2 فقط approved dataset می‌گیرد | upstream eligibility filter/export boundary |

### Derived Operational Status برای UI

Officer نباید چند state داخلی را تفسیر کند. UI یک status مشتق و غیرذخیره‌شده نمایش می‌دهد:

| UI status | derivation authoritative |
|---|---|
| `NEW` | Officer step pending و `review_status != needs_review` |
| `NEEDS_REVIEW` | Officer step pending و `review_status = needs_review` |
| `ACCOUNTING` | Accountant Approval step pending |
| `EXTERNAL_PENDING` | هر دو Approval پاس و Counter هنوز خالی |
| `COMPLETED` | counter imported و final completion تأییدشده |

این status فقط projection نمایشی است؛ ذخیره، import، edit، شرط authority یا trigger workflow بر اساس آن ممنوع است. در تعارض، Gravity Flow + Entry fields اصلی برنده‌اند.

---

## 9. گزینه‌های معماری و Hard Gates

### 9.1 خانواده‌ها

| خانواده | تعریف |
|---|---|
| A — Native-first | GF/Flow config + snippetهای بسیار محدود |
| B — Targeted-plugin | GF/Flow + GravityView/Revisions و add-onهای تخصصی بدون کد glue لازم |
| C — Companion-plugin | GF/Flow + یک plugin اختصاصی برای Desk/edit/audit و همه gapهای پروژه |
| D — Plugin-first bounded hybrid | GF/Flow + GravityView؛ component تخصصی فقط پس از POC؛ کد محدود فقط برای gap باقیمانده |
| E — Custom desk application | REST/SPA یا workflow/UI سفارشی مستقل؛ alternative omission check |

### 9.2 Hard-Gate Matrix

| Gate خلاصه | A | B | C | D | E |
|---|---:|---:|---:|---:|---:|
| Gravity Flow authority حفظ می‌شود | PASS | متغیر | PASS | PASS | FAIL |
| Needs Review همان step می‌ماند | NOT_PROVEN | متغیر | PASS | PASS | NOT_PROVEN |
| formal approvals و validation حفظ می‌شوند | NOT_PROVEN | متغیر | PASS* | PASS* | FAIL/NOT_PROVEN |
| direct access server-authorized است | NOT_PROVEN | PASS* با GravityView/filter | PASS* | PASS* | NOT_PROVEN |
| conditional duplicate rule دقیق است | FAIL بدون custom gap | FAIL بدون custom gap | PASS* | PASS* | PASS* |
| A4 saved-state print دقیق است | FAIL بدون custom template | PASS* با GravityView/CSS | PASS* | PASS* | PASS* |
| بدون plugin-core/DB internal manipulation | PASS | متغیر | PASS | PASS | NOT_PROVEN |
| حداقل total maintenance | NOT_PROVEN | PASS* فقط با POC | FAIL به‌علت بازسازی capability بالغ | PASS | FAIL |
| نتیجهٔ کلی | حذف به‌عنوان معماری کامل | plugin-only حذف | finalist | **selected** | حذف |

`PASS*` یعنی design از gate عبور می‌کند ولی proof محیط واقعی در برنامهٔ تست الزامی است.

هر variantی که GravityView Approval، Entry Tags یا status اختصاصی را جای formal Flow state می‌گذارد `FAIL` است. GravityView در این معماری display/edit/access adapter است، نه workflow engine. استفادهٔ محدود از add-on برای school، image یا revision با حفظ authorityهای اصلی، خانوادهٔ D است.

### 9.3 معیار متمایزکننده

بین B/C/D، نخستین معیار **صحت authority و authorization** و معیار بعدی **total architectural complexity** است. D از GravityView برای display/edit/locking و از Flow برای assignment/approval استفاده می‌کند، بدون آنکه UI اختصاصی یا نسخهٔ دوم داده بسازد. C بازنویسی capability بالغ است؛ B فقط وقتی کامل است که Needs Review، audit API-write و importer بدون glue اختصاصی واقعاً اثبات شوند.

---

## 10. معماری منتخب و اجزا

| Component | مسئولیت | failure در صورت حذف | runtime-critical |
|---|---|---|---:|
| Gravity Forms | form/entry/file/field validation | data contract و persistence از بین می‌رود | بله |
| Gravity Flow | assignment، approvals، current step، Inbox | workflow authority از بین می‌رود | بله |
| WordPress | auth/capability/nonce/runtime | request معتبر و identity از بین می‌رود | بله |
| Gravity Flow Inbox + Entry Details | صندوق عملیاتی واحد، جزئیات Entry، ویرایش فیلدهای مجاز و Approval رسمی | رابط عملیاتی مسئول ثبت‌نام از بین می‌رود | بله |
| GravityView (اختیاری) | فقط ارائهٔ فقط‌خواندنی اختیاری؛ بدون authority بر workflow/queue/approval | چیزی از مسیر عملیاتی از بین نمی‌رود | خیر |
| GravityRevisions | تاریخچه/مقایسه/بازگردانی ویرایش‌های انسانی مهم (فقط Admin) | الزام ممیزی انسانی بی‌پاسخ می‌ماند | بله (V-04) |
| Project integration layer | حداقلی: پیکربندی/شناسه‌ها و چسب کوچک فقط برای gap واقعی بومی | فقط همان gap کوچک باقی می‌ماند | حداقلی |
| انتخابگر مدرسه (بومی/نگهداری‌شده) | جست‌وجوی نام مدرسه روی موبایل؛ ساده‌ترین راه که V-03 را پاس کند | جست‌وجوی مدرسه روی موبایل fail می‌شود | بله (V-03) |
| فیلد آپلود عکس (بومی) | فقط دریافت و نگه‌داری فایل؛ پردازش/بهینه‌سازی خارج از دامنهٔ جاری | فایل عکس دریافت نمی‌شود | بله |
| Gravity Perks Nested Forms | host منتخب برای `1..N` Cheque child Entry در فرم مالی؛ مالک رابطهٔ parent/child، نه workflow | چندچکِ structured در current-release composition بی‌پاسخ می‌ماند | مشروط؛ `SELECTED/POC_NOT_PROVEN` |
| PersianGravity Structured Scanner | scan/parse عمومی profile-based و population اتمیک به ordinary GF fields؛ بدون persistence مستقل | ورود با اسکن QR چک در current release فراهم نمی‌شود؛ ورود دستی باقی می‌ماند | بله برای scan path؛ `POC_NOT_PROVEN` |
| renderer سند نهایی | `POC_GATED / NOT_PROVEN`؛ candidate اول = Gravity PDF Free + SRWF print layer | تا PASS شدن POC، renderer production نهایی انتخاب نشده است | مشروط به D-17 POC |
| WP All Import | مرجع sync شمارنده بر کلید کد ملی؛ فقط فیلد شمارنده | یکسان‌سازی شمارنده انجام نمی‌شود | بله (V-06) |
| Uncanny Automator | cross-plugin/external orchestration خارج از Flow state | integration آینده ممکن است کد/ابزار جدا بخواهد | deferred/مشروط |
| Elementor | خارج از دامنهٔ عملیاتی جاری | چیزی از مسیر عملیاتی از بین نمی‌رود | خیر |
| Matrix2 mapping | consumption از approved output | downstream allocation داده نمی‌گیرد | downstream |

### ساختار منطقی project integration layer

این structure قرارداد مسئولیت است، نه production code نهایی:

Structured Scanner در این bridge پیاده نمی‌شود؛ مالک کد generic آن repository `PersianGravity` است و bridge SRWF نباید parser/profile یا رابطهٔ Nested Forms را دوباره بسازد.


```text
student-registration-workflow-bridge/
├── student-registration-workflow-bridge.php   # bootstrap + dependency checks
├── src/
│   ├── Configuration.php                      # Form/Field/Step IDs from approved contract
│   ├── Authorization.php                      # capability + assignee + current-step checks
│   ├── Public_Validation.php                   # crosswalk + اعتبارسنجی سادهٔ ورودی (بدون قاعدهٔ duplicate)
│   ├── (حذف‌شده) Needs_Review.php             # لازم نیست: فیلد Entry + دلیل، ویرایش بومی Gravity Flow
│   ├── (حذف‌شده) Revision_Audit_Bridge.php    # لازم نیست: فقط ممیزی ویرایش انسانی با GravityRevisions
│   ├── (خارج از دامنه) Photo_Optimizer.php    # پردازش عکس خارج از دامنهٔ جاری
│   └── (حذف‌شده) Counter_Importer.php         # لازم نیست: WP All Import مرجع sync شمارنده است
├── assets/
│   ├── css/native-ui-overrides.css            # فقط gap کوچک و مستند روی سطوح بومی
│   └── js/officer-actions.js                  # dirty-state/double-click only
├── tests/
└── docs/
    ├── FIELD_CONTRACT.md
    ├── TEST_MATRIX.md
    └── CHANGELOG.md
```

قواعد structure:

- namespace یا prefix یکتا؛ WPCS؛ یک responsibility مادی در هر class؛
- بدون DI container، repository pattern، event bus یا framework داخلی؛
- Composer در development برای test/lint مجاز است؛ runtime dependency فقط با دلیل مشخص؛
- `Counter_Importer` در request عمومی load نمی‌شود؛
- IDها در یک config تأییدشده متمرکزند؛ label به‌عنوان lookup ممنوع است؛
- activation side effect حداقلی؛ custom table وجود ندارد.

ساختار بالا **حد بالای مسئولیت‌های محتمل** است، نه فهرست اجباری فایل‌ها. در معماری جاری بیشتر این ماژول‌ها لازم نیستند. (تاریخی: `Needs_Review` پس از Binding Sheet و Gate BP-2 پیاده می‌شود؛ adapter قطعی BP-9 نیز در همین لایه قرار می‌گیرد. سایر moduleها فقط پس از fail شدن راه supported/plugin یا اثبات gap ساخته می‌شوند و ماژول‌های بی‌نیاز حذف می‌شوند. Importer باید از نظر رفتاری `Reader → Validator → Planner → Committer` را جدا نگه دارد، اما تعداد class/file پیشاپیش قفل نمی‌شود.

### قرارداد مهندسی PHP/WordPress

- minimum PHP/WordPress version از environment inventory و matrix رسمی GF/Flow تعیین می‌شود، نه از سلیقهٔ نویسنده؛
- public globals، option names، hooks و asset handles همگی prefix یکتا دارند؛ namespace به‌تنهایی globals را محافظت نمی‌کند؛
- hook registration در bootstrap صریح و قابل جست‌وجو است؛ dynamic magic و service locator ممنوع؛
- input ابتدا type/shape check، سپس normalize، سپس business validate می‌شود؛ sanitization جای validation نیست؛
- output در آخرین context ممکن escape می‌شود؛ دادهٔ escape‌شده در Entry ذخیره نمی‌شود؛
- exception/WP_Error به result object روشن تبدیل و هر return از GFAPI/Flow بررسی می‌شود؛
- user-facing stringها translatable و Persian copy در یک محل نگهداری می‌شوند؛ machine Value ترجمه نمی‌شود؛
- dependency absence یا config drift باید `fail closed` با Admin notice باشد؛ action button در حالت misconfigured پنهان/غیرفعال و write ممنوع؛
- static analysis/lint باید حداقل PHPCS با WordPress Coding Standards را اجرا کند؛ unit test برای pure validators و integration test واقعی برای GF/Flow لازم است؛
- هیچ estimate خط کد، جای complexity review را نمی‌گیرد. معیار، تعداد مسئولیت‌ها و failure pathهاست.

---

## 11. معماری فرم عمومی موبایل

### 11.1 shell و layout

- single-page، عمدتاً one-column، کنترل‌های بزرگ و متن کم؛
- بدون Elementor مگر site از قبل آن را برای تمام صفحات تحمیل کند؛ حتی در آن حالت فرم در ساده‌ترین shell ممکن embed می‌شود؛
- Save & Continue، self-edit link و wizard بعد از Submit فعال نمی‌شوند؛
- CSS/JS فقط روی page/form مربوط enqueue می‌شود.

### 11.2 dependencyهای آموزشی

Crosswalk قبل از build به یک snapshot کنترل‌شده برای choice/config تبدیل می‌شود؛ production فایل Excel را نمی‌خواند. Front-end فقط گزینه‌های معتبر را نشان می‌دهد و server همان matrix را دوباره validate می‌کند. اگر یک status تنها انتخاب معتبر است، server آن را authoritative set می‌کند و سؤال اضافی از دانش‌آموز حذف می‌شود.

Invalid combination حتی با دستکاری POST یا JavaScript disabled باید reject شود. Error message باید به زبان کاربر بگوید انتخاب مقطع/گروه را اصلاح کند و machine details را نمایش ندهد.

انتخابگر مدرسه با **ساده‌ترین راه بومی/نگهداری‌شده** (Drop Down + Enhanced UI بومی) پیاده می‌شود و تنها معیار پذیرش، جست‌وجوی responsive فارسی روی موبایل است. comparator سه‌گانه (Chained Selects / Populate Anything / Advanced Select) و chaining استان→شهر و AJAX سفارشی حذف شدند. اگر لازم شد فقط یک راه بومی/نگهداری‌شدهٔ ساده‌تر بعدی سنجیده می‌شود. [Drop Down](https://docs.gravityforms.com/drop-down-field/)

### 11.3 school selector

Baseline data: حدود ۹۵۰ مدرسه، تغییر کم، choices static؛ `label` = نام مدرسه، `value` = کد پایدار؛ search بر اساس نام؛ `Other` همیشه آخر لیست. Data model بسته است.

تنها معیار پذیرش مادی این است که کاربر بتواند **نام فارسی مدرسه را تایپ کند و روی موبایل سریع و مطمئن انتخاب کند**. chaining استان→شهر، مقایسهٔ سه‌گانهٔ Chained Selects/Populate Anything/Advanced Select و AJAX سفارشی حذف شده‌اند.

مسیر: از **ساده‌ترین راه‌حل بومی/نگهداری‌شده** شروع کن — فیلد Drop Down با `Enhanced UI` بومی Gravity Forms (جست‌وجوی درون‌فهرستی). اگر تست responsive روی Android رده‌پایین/میانی و iPhone پاس شد، **همان‌جا توقف کن** و گزینهٔ دیگری ارزیابی نشو. فقط اگر این راه تست جست‌وجوی موبایل را رد کرد، یک راه بومی/نگهداری‌شدهٔ ساده‌تر بعدی سنجیده می‌شود. ویرایش بعدیِ فهرست مدارس = فقط Admin. [Drop Down](https://docs.gravityforms.com/drop-down-field/)

### 11.4 Other school

وقتی `school_code=0` انتخاب شد:

- typed school name required؛
- دقیقاً یک report card: JPG/JPEG/PDF، حدود ۵ MB max؛
- server هم value صفر، نام و upload را validate می‌کند؛
- صفر مانع registration نیست؛ Admin می‌تواند بعداً کد واقعی را جایگزین کند.
- Officer نام/انتخاب انسانی مدرسه را اصلاح می‌کند؛ raw `school_code` مستقیماً editable نیست، ولی سیستم در صورت تغییر انتخاب معتبر code canonical متناظر را خودکار به‌روزرسانی می‌کند.

### 11.5 National ID

کد ملی با یک **راه‌حل سادهٔ ایرانیِ نگهداری‌شده** (اعتبارسنجی ساختار/checksum ایرانی) مدیریت می‌شود.

Pipeline کمینه: تبدیل ارقام فارسی/عربی به ASCII، trim، طول دقیق ۱۰، اعتبارسنجی checksum کد ملی ایران با حفظ leading zero و ذخیرهٔ ASCII.

**مسدودسازی تکراری وجود ندارد (D-10):** `No Duplicates` خاموش است و کد ملی تکراری کاملاً مجاز است؛ هیچ lookup مسدودکنندهٔ لحظهٔ submit اجرا نمی‌شود. یکسان‌سازی شمارنده برای کد ملی‌های تکراری در زمان import و توسط WP All Import انجام می‌شود (بخش ۱۷ و ۱۸، D-15).

### 11.6 تاریخ تولد Jalali

تاریخ تولد جلالی با یک **راه‌حل سادهٔ نگهداری‌شدهٔ فارسی‌سازی وردپرس/Gravity** (مثل `Parsi Date`) یا سه control سادهٔ year/month/day که مقدار canonical `YYYY/MM/DD` تولید کند، مدیریت می‌شود، به‌همراه اعتبارسنجی جلالی سمت سرور. مسیرهای چندگانه/comparator و kernel جلالی سفارشی حذف شده‌اند. picker فقط UI است و قرارداد ذخیره‌سازی را تغییر نمی‌دهد. [Parsi Date](https://wordpress.org/plugins/wp-parsidate/)

### 11.7 عکس دانش‌آموز

پردازش عکس **خارج از دامنهٔ جاری** است و مالک آن را جداگانه مدیریت می‌کند. معماری پردازش تصویر (بهینه‌سازی/rotate/resize/compress سفارشی با `wp_get_image_editor()`) از این نسخه حذف شده است.

باقی‌ماندهٔ الزام: یک فیلد آپلود عکس ساده و **الزامی** با اعتبارسنجی پایهٔ MIME/نوع فایل. بدون هدف اندازهٔ خروجی و بدون مسیر پردازش سفارشی در این دامنه.

### 11.8 شمارهٔ همراه

شمارهٔ همراه با یک **راه‌حل سادهٔ ایرانیِ نگهداری‌شده** (اعتبارسنجی ساختار موبایل ایران) با پذیرش ارقام فارسی/عربی و صفر ابتدایی مدیریت می‌شود. import شمارنده این فیلد را نمی‌نویسد.

## 12. Desk مسئول ثبت‌نام

### 12.1 access model

- dedicated low-privilege WordPress user؛
- capabilityهای حداقلی GravityView/Gravity Flow و فقط موارد لازم برای view/edit/action؛
- هیچ `gravityflow_workflow_detail_admin_actions` برای Officer؛
- no one-click email token؛ email در v1 خاموش؛
- direct Entry URL در هر بار بازکردن و هر POST دوباره server-authorized می‌شود.

پنهان‌کردن menu یا button امنیت نیست. authorization باید current authenticated user را با assignee واقعی current Officer step تطبیق دهد.

### 12.2 پوسته

`ACTIVE_NORMATIVE`

پوستهٔ عملیاتی مسئول ثبت‌نام **بومی Gravity Flow** است:

- صفحهٔ Inbox (داشبورد یا بلاک/شورت‌کد Inbox) به‌عنوان تنها صندوق کاری؛
- صفحهٔ Entry Details بومی برای مشاهده، ویرایش فیلدهای مجاز و Approval رسمی.

هیچ Desk سفارشی، صفحهٔ لیست سفارشی یا لایهٔ ارائهٔ اجباری دیگری ساخته نمی‌شود. اگر بعداً ارائهٔ فقط‌خواندنی زیباتری لازم شد، GravityView می‌تواند به‌عنوان سطح **اختیاری** اضافه شود بدون آنکه مرجع workflow/queue/approval شود.

ساخت Student CPT یا mirror دادهٔ ACF/JetEngine برای ارائه ممنوع است، چون source of truth دوم و مسئلهٔ sync می‌سازد.

### 12.3 صندوق عملیاتی واحد

یک **صندوق عملیاتی واحد** وجود دارد: **Gravity Flow Inbox بومی**. queue جداگانهٔ GravityView و مدل «دو queue» حذف شده است. تفکیک «جدید» در برابر «نیازمند بررسی» با فیلترها/ستون‌های بومی همان Inbox و فیلد `review_status` نمایش داده می‌شود.

Inbox بومی به‌صورت مستند این‌ها را می‌دهد: جست‌وجوی سراسری، فیلتر/مرتب‌سازی ستونی، بازچینش ستون (ماندگار per-user)، صفحه‌بندی ۲۰تایی و Live Data Refresh. اگر صندوق روی صفحهٔ front-end قرار گیرد، تنظیمات بلاک/شورت‌کد دقیقاً تعیین می‌کنند کدام ستون‌ها نمایش داده شوند (شناسهٔ Entry، ارسال‌کننده، گام، آخرین به‌روزرسانی، ستون اقدام تأیید، تاریخ سررسید و رنگ برجسته‌سازی گام) و ستون مقادیر فیلد فقط وقتی ممکن است که فهرست به یک فرم محدود شود. مرجع server-side همچنان current Flow step و assignee است. [Inbox](https://docs.gravityflow.io/the-inbox-page/)

### 12.4 row contract

هر row فقط این‌ها را دارد:

- نام دانش‌آموز؛
- national ID؛
- grade/group summary؛
- submit time؛
- status/reasons.

برای کار روزمرهٔ تک‌Entry از Entry Details استفاده می‌شود، چون مستندات رسمی می‌گوید Quick Actions اعتبارسنجی فیلدهای الزامی قابل‌ویرایش را bypass می‌کند. استفاده از اقدام گروهی بومی برای نهایی‌سازی دسته‌ای مجاز است (D-16) به‌شرط آنکه فیلد الزامی قابل‌ویرایشی در آن گام وجود نداشته باشد. Officer Reject action نیز نمایش داده نمی‌شود. analytics و search/filter سفارشی در v1 وجود ندارد؛ فقط native Search Bar/DataTables capability در BP-1 با کمینهٔ فیلدهای لازم مقایسه می‌شود.

### 12.5 freshness و notification

**Live Data Refresh بومی Gravity Flow کافی است**؛ ورودی‌های تازه بدون reload دستی در Inbox ظاهر می‌شوند. هیچ polling/WebSocket/queue/worker/Cron یا زیرسیستم freshness سفارشی ساخته نمی‌شود. Browser Notification فقط convenience است.

ویرایش‌های روتین و تغییرهای Needs-Review **هیچ notification تولید نمی‌کنند**؛ زیرسیستم notification سفارشی وجود ندارد. [Inbox / Live Refresh](https://docs.gravityflow.io/the-inbox-page/)

### 12.6 cache boundary

صفحات و endpointهای زیر از full-page/CDN HTML cache مستثنا می‌شوند:

- Public Registration و confirmationهای stateful؛
- Officer Desk/Multiple Entry؛
- Single Entry و Edit Entry؛
- Gravity Flow Inbox/Entry Detail/User Input؛
- URLها و endpointهای authenticated/action/download که vendor نیاز دارد.

defer/delay/minify/combine JavaScript و cache fragment فقط اگر regression test GF/Flow/GV، nonce، conditional logic، upload و edit را پاس کند مجاز است. کل سایت از cache خارج نمی‌شود. `Fresh Forms` یا Cache Buster فقط وقتی نصب می‌شود که cache/CDN هدف exclusion مطمئن را ندهد؛ این ابزارها به‌صورت خودکار پوشش Gravity Flow/GravityView را تضمین نمی‌کنند.

### 12.7 انتخاب layout لیست و عملیات گروهی

سه مسیر باید روی dataset و browser هدف با معیار یکسان مقایسه شوند:

| مسیر | مزیت | محدودیت/Guardrail | وضعیت |
|---|---|---|---|
| Table + Bulk Actions | انتخاب ردیف، Export CSV/TSV و ZIP مدارک، background processing | Bulk Actions رسماً فقط Table است؛ Delete/Resend/Bulk Approval برای Officer خاموش | `CANDIDATE` |
| DataTables AJAX | sorting/filtering/paging تعاملی و بارگذاری مناسب‌تر برای list بزرگ | export فقط current page؛ coexistence با Bulk Actions `NOT_PROVEN` | `CANDIDATE` |
| Search-first Table/View | کمترین بار اولیه و ساده‌ترین UX برای lookup نام/کدملی | عملیات گروهی و مرور آزاد کمتر | `BASELINE` |

قابلیت‌های بومی Inbox (جست‌وجو، فیلتر، مرتب‌سازی، بازچینش ستون، اقدام گروهی) مسیر اصلی‌اند و لیست/جدول سفارشی افزوده نمی‌شود. (تاریخی: Table+Bulk یا DataTables فقط اگر BP-1 یک failure عملی یا requirement material مانند ZIP انتخابی را اثبات کند فعال می‌شود. چون فرم هدف Conditional Logic دارد، Frontend Bulk Edit در v1 `NOT_PLANNED` است. Actions مربوط به Approve/Disapprove/Reset Approval و Delete برای Officer فعال نمی‌شوند. Export/Download Attachments فقط پس از role/capability، PII، filename، size limit و selection-scope test مجازند.


### 12.7 قرارداد مالی نسخهٔ جاری

`ACTIVE_NORMATIVE / OWNER_LOCKED`

نسخهٔ جاری بدون POS باید کامل قابل‌استفاده باشد. دادهٔ مالی canonical در همان Gravity Forms Entry باقی می‌ماند و Officer آن را فقط روی سطح بومی Gravity Flow و در whitelist گام مربوط می‌بیند/ویرایش می‌کند.

حداقل semantic set نسخهٔ جاری:

- `tuition_amount` — مبلغ شهریه، ورودی Officer؛
- `discount_amount` — مبلغ تخفیف، ورودی Officer؛
- `discount_title` — عنوان متنی تخفیف، ورودی Officer؛
- `net_payable_amount` — مقدار مشتق‌شده با قرارداد `tuition_amount - discount_amount`؛ مقدار persisted نباید با این رابطه متناقض باشد.

Semantic Field Contract این بخش `OWNER APPROVED / CLOSED` است: واحد canonical و display مبالغ = **ریال**؛ `tuition_amount`، `discount_amount`، `discount_title` و فیلدهای مالی/چک release جاری همگی optional و non-public هستند و فقط در سطح عملیاتی Registration Officer نمایش داده می‌شوند؛ `discount_amount` می‌تواند default=`0` داشته باشد؛ `net_payable_amount = tuition_amount - discount_amount` derived و بدون override مستقیم Officer است؛ اگر `discount_amount > tuition_amount` باشد validation باید خطا بدهد و save انجام نشود. `POS/PC-POS`، receipt automation و استعلام آنلاین صیاد `DEFERRED` هستند.

پروندهٔ چاپی باید همین snapshot ذخیره‌شدهٔ مالی و داده‌های چک را مصرف کند؛ renderer طبق D-17 جداگانه POC می‌شود.

### 12.8 قرارداد چندچک

`ACTIVE_NORMATIVE / OWNER_LOCKED / POC_NOT_PROVEN`

- یک dossier می‌تواند `1..N` چک داشته باشد.
- host منتخب فعلی برای repeatable cheque data = **Gravity Perks Nested Forms**.
- هر چک یک **Gravity Forms child Entry مستقل** در یک `Cheque Form` اختصاصی است؛ canonical cheque data داخل GF می‌ماند.
- رابطهٔ parent/child را extension نگهداری‌شده مالک است؛ SRWF و PersianGravity نباید relationship table/state/parent-link موازی بسازند.
- `Gravity Flow Parent-Child Forms` فقط fallback candidate است و فقط بعد از FAIL یک POC bounded روی Nested Forms بررسی می‌شود؛ custom `Parent Entry ID`/link برای production انتخاب نشده است.
- selection به‌تنهایی مجوز خرید نیست. اگر entitlement فعلی Nested Forms وجود نداشته باشد، source-code Scanner مستقل ادامه می‌یابد ولی خرید dependency فقط طبق Gate procurement/POC مجاز است.

POC host باید با synthetic data ثابت کند: child form روی surface لازم render می‌شود؛ edit دستی فیلدهای مجاز ممکن است؛ submit child persist می‌شود و رابطهٔ درست parent حفظ می‌شود؛ reload مقادیر را نگه می‌دارد؛ و finance/print composition دادهٔ childها را از دست نمی‌دهد. Scanner init/population معیار release جاری نیست و فقط اگر Owner در فاز بعدی scan path را reopen کرد به POC مستقل برمی‌گردد.

### 12.9 Structured Scanner و Sayad v01

`DEFERRED FOR SRWF CURRENT RELEASE / GENERIC CAPABILITY RETAINED`

`Structured Scanner` یک capability عمومی در `PersianGravity` است، نه feature مخصوص SRWF و نه data store. Owner در ۲۰۲۶-۰۹-۰۷ مسیر scan-assisted مالی/چک را از release جاری خارج کرد؛ در release جاری Scanner هیچ فیلد مالی/چک را populate نمی‌کند. قرارداد فنی زیر برای فاز بعدی محفوظ می‌ماند:

- controller **non-persistent** و host-agnostic است؛ capture/parse می‌کند و فقط ordinary Gravity Forms fields را populate می‌کند؛
- raw QR payload canonical نیست و persist نمی‌شود؛
- Profile مالک `parser schema + output keys + validation contract` است؛ هر instance در Form Builder خروجی‌ها را به fieldهای عادی همان فرم map می‌کند؛
- Scanner هیچ SRWF Form/Field ID، Nested Forms persistence، workflow state یا parent/child logic را hard-code نمی‌کند؛
- بعد از population، فیلدهای مجاز همچنان با مسیر عادی GF/Flow قابل اصلاح دستی‌اند.

قرارداد محافظه‌کارانهٔ `Sayad v01` برای POC هفت output مرتب دارد:

1. `qr_version`
2. `owner_type`
3. `owner_identifier`
4. `iban`
5. `bank_branch`
6. `cheque_serial`
7. `sayad_id`

Population باید **atomic** باشد: اگر parse/profile validation fail شد، هیچ target field نباید نیمه‌کاره تغییر کند. یک sample واقعی فقط این ساختار هفت‌گانه را پشتیبانی می‌کند؛ ثبات بین بانک‌ها/نسخه‌ها `NOT_PROVEN` است، بنابراین طول/فرمت‌های اضافی یا validation بانکیِ قوی‌تر بدون evidence جدید قفل نمی‌شوند.

برای release جاری هر هفت output (`qr_version`, `owner_type`, `owner_identifier`, `iban`, `bank_branch`, `cheque_serial`, `sayad_id`) به‌صورت فیلدهای Hidden و future-reserved در Cheque Form نگه داشته می‌شوند و Scanner آن‌ها را populate نمی‌کند. فعال‌سازی و persistence عملیاتی آن‌ها فقط با Owner reopen در فاز بعدی و privacy/retention مناسب مجاز است.

---

## 13. قرارداد Needs Review

«Needs Review» یک **حالت/queue/POST سفارشی نیست**. صرفاً یک **فیلد Entry معمولی** به‌همراه یک **فیلد دلیل** است. POST اعتبارسنجی‌شدهٔ سفارشی، State Inspector، قرارداد idempotency سفارشی، و تکیه بر Entry Notes برای وضعیت بررسی حذف شده‌اند.

### 13.1 مدل داده (ساده‌شده)

دو فیلد اداری در همان Gravity Form کافی است:

| هدف | نوع GF | مقدار |
|---|---|---|
| `review_status` | Drop Down/Radio، Administrative | `none` یا `needs_review` |
| `review_reason` | Single Line/Paragraph یا Checkboxes، Administrative | دلیل کوتاه بررسی |

بدون فیلدهای idempotency/operation-id/payload-hash/actor سفارشی. ثبت note رسمی در صورت نیاز از **Workflow Note بومی** گام Approval استفاده می‌کند (پیش‌فرض `Not Required`).

### 13.2 عملیات و حل

Officer فیلدهای مجاز و `review_status` را از طریق **ویرایش بومی Gravity Flow** روی همان گام Approval ذخیره می‌کند (فیلدهای قابل‌ویرایش با whitelist گام تعیین می‌شوند، `D-04`). ویرایش، Entry را روی همان گام و همان assignee نگه می‌دارد و پیشروی ایجاد نمی‌کند. برای حل، Officer همان Entry را باز می‌کند، اصلاح می‌کند و **Approve رسمی بومی** را می‌زند (`D-05`). action سفارشی «Clear Needs Review» وجود ندارد.

## 14. Approval و failure-safety

### 14.1 Approval path

- native Gravity Flow Approval Step؛
- فقط editable fields تعریف‌شده در step؛
- `Require Confirmation` فعال؛
- Reject برای Officer hide/disable؛ Admin از facilities معمول خارج Desk می‌تواند Reject کند؛
- Quick Actions خاموش؛
- پس از confirm، native server processing و post-condition current step=Accountant Pending.

### 14.2 saved/unsaved coherence

Graphic form فقط saved Entry را نشان می‌دهد. edit panel draft را جدا نشان می‌دهد. unsaved values در paper view mirror نمی‌شوند. `beforeunload` فقط وقتی dirty است. Print هنگام dirty disabled و دلیل کوتاه نمایش داده می‌شود.

### 14.3 duplicate-submit protection

مسدودسازی تکراری وجود ندارد؛ کد ملی تکراری مجاز و همهٔ Entryها حفظ می‌شوند. محافظت در برابر ارسال دوگانه به رفتار بومی متکی است: پس از پیشروی، Approval دوم به‌صورت بومی با «این مورد دیگر در اختیار شما نیست» رد می‌شود. WordPress nonce صرفاً CSRF را کاهش می‌دهد و جایگزین authentication/authorization نیست.

### 14.4 success/failure contract

Success Approval فقط وقتی نشان داده می‌شود که server تأیید کند formal action انجام شده و Entry به Accountant step رسیده است. صفحهٔ success نام، national ID و «ارسال شد به حسابداری» را نشان می‌دهد و فقط دکمهٔ بزرگ Back دارد؛ auto-next ممنوع.

در failure:

- Entry قابل retry می‌ماند؛
- draft ورودی تا حد ممکن حفظ می‌شود؛
- message ساده و request correlation ID غیرحساس دارد؛
- national ID/photo path در log عمومی نوشته نمی‌شود؛
- success optimistic JavaScript ممنوع است.

---

## 15. Entry Detail، template، print و document

### 15.1 template ownership

`ACTIVE_NORMATIVE`

مالک render صفحهٔ عملیاتی، **Entry Details بومی Gravity Flow** است: انتخاب فیلدهای نمایشی و قابل‌ویرایش، چیدمان یک/دو ستونی، نمایش/عدم‌نمایش Timeline و متن/مقصد Back Link همگی تنظیمات بومی‌اند.

هیچ template اجباری دیگری تعریف نمی‌شود. اگر ارائهٔ فقط‌خواندنیِ غنی‌تر لازم شد، GravityView به‌عنوان سطح **اختیاری** قابل افزودن است و هیچ authority ای بر workflow، assignment، approval یا queue پیدا نمی‌کند.

### 15.1.1 نمایش وضعیت برای دانش‌آموز/ارسال‌کننده

`ACTIVE_INFORMATIVE`

تنظیمات بومی Workflow Start/Complete تعیین می‌کنند ارسال‌کننده هنگام مشاهدهٔ Entry در صفحهٔ Status چه ببیند: «پیام در انتظار»، «پیام تکمیل» و «فیلدهای نمایشی پیش‌فرض». شرط منطقی Start در سطح کل گردش‌کار عمل می‌کند و اگر برقرار نباشد هیچ گامی اجرا نمی‌شود. توجه: اگر کاربر مجوز دیدن همهٔ Entryها را داشته باشد، محدودسازی فیلدهای نمایشی اعمال نمی‌شود.

### 15.2 screen layout

`ACTIVE_NORMATIVE`

- چیدمان بومی Entry Details گراویتی‌فلو مبناست: انتخاب فیلدهای نمایشی، فیلدهای قابل‌ویرایش و چیدمان یک/دو ستونی در بلاک/شورت‌کد؛
- RTL و خوانایی فارسی الزامی است؛
- عکس دانش‌آموز فقط اگر render ساده و مطمئن باشد نمایش داده می‌شود؛
- هیچ background image با overlayهای absolute در صفحهٔ عملیاتی استفاده نمی‌شود.

اگر ارائهٔ فقط‌خواندنی غنی‌تری لازم شد، GravityView Single Entry یک گزینهٔ **اختیاری/معوق** است و مرجع عملیاتی نمی‌شود.

### 15.3 Browser Print contract

`ACTIVE_NORMATIVE`

Browser Print در نسخهٔ ۱٫۷٫۰ **مسیر production موازی یا fallback دائمی نیست**. می‌تواند فقط برای مقایسه/تشخیص در POC استفاده شود، اما اگر `Gravity PDF Free` FAIL شود، پروژه دو renderer هم‌زمان نگه نمی‌دارد؛ D-17 باز می‌ماند و candidate بعدی باید جداگانه re-adjudicate شود.

الزام‌های پایدار:

- خروجی از همان Entry گراویتی‌فرمز مشتق شود و source of truth دوم نسازد؛
- فارسی/RTL و فونت درست render شود؛
- وضعیت ذخیره‌شده (نه پیش‌نویس) چاپ شود؛
- مسیر عادی Officer نباید به «دانلود فایل → پیدا کردن فایل → بازکردن دستی → چاپ» وابسته باشد.

مقادیر دقیق حاشیه/مقیاس و آزمون چاپ تابع renderer منتخب و paper/printer test هستند.

### 15.4 Print Data Envelope

`DEFERRED`

مفهوم «پاکت دادهٔ چاپ» (سقف مقدار داده‌ای که باید در یک برگه جا شود) معتبر می‌ماند، اما مقادیر عددی و آزمون آن تا PASS شدن D-17 POC و تثبیت renderer نهایی معوق است و اکنون الزام release مستقل نیست.

### 15.5 Gravity PDF Free document route

`ACTIVE_NORMATIVE / POC_GATED / NOT_PROVEN`

تصمیم مالک ۲۰۲۶-۰۹-۰۶:

- candidate اول و تنها candidate دور اول برای D-17 = **`Gravity PDF Free`**؛
- template/extension پولی Gravity PDF در baseline چاپ **ممنوع** است؛
- لایهٔ چاپ SRWF مالک presentation-specific logic است: قالب dossier، field mapping، section ordering، A4/page-break rules، permission، filename و action چاپ؛
- لایهٔ SRWF نباید PDF renderer/font-shaping engine/framework عمومی تازه بسازد؛
- شکل نهایی لایهٔ SRWF (صرف custom template یا افزونهٔ thin اختصاصی) تا اثبات gap واقعی بعد از POC باز می‌ماند.

#### D-17 POC Gate

POC با **synthetic data** اجرا می‌شود و باید هم‌زمان این observableها را PASS کند:

1. اتصال حروف فارسی و RTL صحیح؛
2. ZWNJ/نیم‌فاصله در render و copy/paste حفظ شود؛
3. کد ملی ده‌رقمی با صفر ابتدایی در متن RTL بدون تغییر بماند؛
4. تاریخ جلالی `YYYY/MM/DD` بدون تغییر بماند؛
5. مبلغ و یک جدول نمونه درست render شوند؛
6. A4 و page break پایدار باشند؛
7. PDF قابل search/copy باشد و Unicode منطقی خروجی تخریب نشود؛
8. مسیر Officer با action واضح «چاپ پرونده» PDF را برای مشاهدهٔ مستقیم باز کند و **دانلود دستی فایل جزو مسیر عادی نباشد**؛ auto-print browser requirement نیست.

**PASS:** `Gravity PDF Free` renderer نهایی D-17 می‌شود و Browser Print مسیر production موازی نخواهد بود.

**FAIL:** D-17 بسته نمی‌شود؛ template/extension پولی خودکار مجاز نمی‌شود و Browser Print نیز fallback دائمی نمی‌شود. candidate-space برای موتور/renderer جایگزین باید جداگانه با Owner re-adjudicate شود.

### 15.6 مسیر بعد از Edit و Lightbox

`ACTIVE_NORMATIVE`

رفتار پس از ویرایش همان رفتار بومی Gravity Flow است. هیچ redirect سفارشی، Lightbox یا مسیر بازگشت اختصاصی ساخته نمی‌شود.

## 16. Authorization و security model

امنیت در این پروژه یک «feature تزئینی» نیست؛ بخشی از data integrity دانش‌آموز است. با این حال architecture enterprise یا IAM مستقل ساخته نمی‌شود.

### 16.1 لایه‌های check

هر GET detail و POST action باید همهٔ این‌ها را server-side بررسی کند:

1. کاربر logged-in است؛
2. capability لازم را دارد؛
3. Form ID و Entry ID متعلق به سیستم ثبت‌نام‌اند؛
4. current Gravity Flow step همان Officer Approval مورد انتظار است؛
5. کاربر assignee واقعی همان step است؛
6. action برای وضعیت جاری مجاز است؛
7. POST nonce معتبر دارد؛
8. فقط Field/Input IDهای whitelist‌شده پذیرفته می‌شوند؛
9. valueها normalize/validate می‌شوند؛
10. output late-escaped است.

Capability تنها کافی نیست؛ assignee check تنها نیز کافی نیست. direct URL با Entry ID حدسی باید همان checkها را اجرا و بدون افشای اینکه Entry وجود دارد، response مناسب بدهد.

مالکیت/creator Entry نیز grant موردنظر پروژه نیست. `V-02` باید بررسی کند کاربری که creator یک Entry شناخته می‌شود، بدون assignee بودن نتواند از Single/Edit URL یا POST مستقیم استفاده کند. `gravityview_edit_entries` به‌تنهایی guard عمومی edit فرض نمی‌شود؛ role matrix باید روی رفتار واقعی View settings، creator ownership، `edit_others`، Flow assignee و هر custom authorization filter اثبات شود.

`Enable Enhanced Security` و secret مربوط به embed باید برای Viewهای حساس فعال بماند، اما فقط یک embed-control دفاعی است. دانستن secret، embed شدن View یا مخفی بودن direct URL به هیچ کاربری مجوز مشاهده/ویرایش Entry مشخص نمی‌دهد و هیچ‌یک از checkهای 1 تا 10 را حذف نمی‌کند.

### 16.2 نقش‌ها

| نقش | مجاز | غیرمجاز |
|---|---|---|
| Public | Submit فرم جدید | مشاهده/edit Entry پس از submit |
| Registration Officer | Inbox بومی (فقط موارد assigned)، Entry Details، ویرایش فیلدهای مجاز طبق whitelist، تعیین `review_status`، Approve رسمی بومی، ویرایش label/nameهای code-backed با system-mediated canonical update، مشاهده/ویرایش فیلدهای مالی optional release جاری | Admin Actions، Entry دیگران، importer، raw technical code مستقیم، تاریخچهٔ revision |
| Accountant | native formal Approval و read-only project UI طبق فیلدهای مجاز همان step | فیلدهای مالی Registration-Officer-only در release جاری، Officer edits/Desk customization |
| Admin | normal GF/Flow/GV admin، revision history/restore، `school_code` correction، Canonical selection، counter import | bypass silent eligibility یا conflict normalization |

برای Registration Officer، Entry Notes الزام پروژه نیست و نقشی در وضعیت بررسی ندارد؛ `delete/email` و تمام GravityView Approval/Bulk Approval capabilityها عمداً اعطا یا در View فعال نمی‌شوند. اگر یک capability برای چند action ناهمگون لازم بود، action ناخواسته باید در خود View غیرفعال و direct request آن نیز deny شود.

### 16.3 file/privacy

- file type بر MIME/content و extension allowed بررسی شود؛ نام فایل sanitize شود؛
- URL upload مطابق protection استاندارد Gravity Forms مدیریت شود؛
- log و exception نباید national ID کامل، photo URL خصوصی یا report card را ثبت کند؛
- log technical با Entry ID و correlation ID کافی است؛
- retention/privacy policy مالک پیش از ورود هر دادهٔ واقعی به production یا UAT human-reviewed می‌شود. staging با دادهٔ مصنوعی می‌تواند زودتر انجام شود، ولی production-data Gate بدون تصمیم دربارهٔ مدت نگهداری، دسترسی فایل، backup retention و deletion/recovery policy عبور نمی‌کند.

### 16.4 entry locking و concurrency

هیچ concurrency/locking سفارشی ساخته نمی‌شود و lock manager/جدول revision از پیش ایجاد نمی‌گردد. probeهای locking (از جمله GravityView Entry Locking) **probe پایهٔ این نسخه نیستند**. حجم متوسط و مسئول ثبت‌نام واحد ریسک را پایین نگه می‌دارد. دفاع کافی: بازبینی current step/assignee بلافاصله پیش از write و رد نوشتن stale با پیام reload/retry، همگی از رفتار بومی Gravity Flow.

### 16.5 Role/Ownership Matrix Gate

سیستم **یک مسئول ثبت‌نام واحد** دارد؛ منطق چند-Officer، بازتخصیص و ماتریس رقابت وجود ندارد. حداقل امنیت بومی کافی است: عموم/کاربر غیرمجاز رد، Officer دسترسی عملیاتی (بدون Admin Actions که با capability `gravityflow_workflow_detail_admin_actions` gated است)، Admin دسترسی ادمین.

| بازیگر/زمینه | list | single | ویرایش | expected |
|---|---:|---:|---:|---|
| مسئول ثبت‌نام (assignee) | allow | allow | allow با whitelist بومی | `PASS` |
| کاربر دیگر/نقش غیرمجاز | deny | deny | deny | بدون leakage |
| logged-out | deny | deny | deny | login/no-disclosure |
| Admin | allow | allow | allow طبق role | خارج از دامنهٔ Officer |

هر row با URL/POST دستکاری‌شده و nonce منقضی آزموده می‌شود (تست دود حداقل دسترسی، `V-02`/`PRB-NF-V02`).

## 17. Accountant و duplicate business rule

گام Accountant بومی، رسمی و از دید این پروژه read-only می‌ماند. تغییر UI حسابدار خارج از دامنه است.

کد ملی تکراری مجاز است و همهٔ Entryها حفظ می‌شوند؛ هیچ lookup مسدودکننده‌ای پیش از ایجاد Entry اجرا نمی‌شود.

منطق کسب‌وکار کد ملی تکراری به **یکسان‌سازی شمارنده در زمان import** منتقل شده است: کلید کسب‌وکار = **کد ملی** با **تطبیق دقیق**. همهٔ Entryهای دارای یک کد ملی همان `registration_counter` را می‌گیرند و یک کد ملی که قبلاً شمارنده گرفته، درخواست‌کنندهٔ جدید محسوب نمی‌شود. انتشار در **import بعدی** رخ می‌دهد، نه در لحظهٔ submit (بخش ۱۸، D-15/D-16). ابهام (بیش از یک Entry واجد شرایط) با انتخاب خودکار حل نمی‌شود و به Admin ارجاع می‌گردد.

## 18. Downstream Counter Import

### 18.0 ابزارهای بومی مرتبط با شمارنده

`ACTIVE_INFORMATIVE`

صفحهٔ Status بومی گراویتی‌فلو امکان فیلتر بر اساس وضعیت/شناسه/فرم/تاریخ، مرتب‌سازی ستونی، تعیین تعداد ردیف در صفحه از طریق Screen Options و **خروجی CSV از همان فیلتر جاری** را می‌دهد. این خروجی، مسیر بومی استخراج داده برای مغایرت‌گیری با سامانهٔ بیرونی است و نیازی به گزارش‌گیری سفارشی ندارد. مرتب‌سازی روی ستون «فرم» پشتیبانی نمی‌شود و اقدام‌های گروهی فقط وقتی فعال‌اند که فهرست به یک فرم محدود شده باشد.

### 18.1 eligibility

`ACTIVE_NORMATIVE`

کلید کسب‌وکار **کد ملی** با **تطبیق دقیق** است. همهٔ Entryهای دارای یک کد ملی همان `registration_counter` را می‌گیرند و کد ملی‌ای که قبلاً شمارنده گرفته، درخواست‌کنندهٔ جدید محسوب نمی‌شود. Entry تکراری بعدی می‌تواند در چرخهٔ import/sync بعدی همان شمارنده را دریافت کند.

importer فقط فیلد شمارنده را می‌نویسد و **حق پیشروی گردش‌کار را ندارد**؛ نهایی‌سازی گردش‌کار جدا، بومی و در صورت نیاز دستی است.

### 18.2 input contract

`ACTIVE_NORMATIVE`

فایل ورودی حداقل این دو ستون را دارد:

- `national_id`؛
- `registration_counter`.

نام ستون‌ها/شیت پس از دریافت نمونهٔ واقعی در قرارداد import تثبیت می‌شود و mapping در WP All Import **صریح و نسخه‌دار** تعریف می‌گردد (بدون حدس‌زدن header و بدون mapping خودکار در production). چون خواندن فایل بر عهدهٔ WP All Import است، پروژه هیچ parser اختصاصی نمی‌نویسد و انتخاب کتابخانهٔ صفحه‌گسترده موضوعیت ندارد.

### 18.3 اجرای ایمن sync

`ACTIVE_NORMATIVE`

هیچ importer سفارشی ساخته نمی‌شود. معماری `Reader/Validator/Planner/Committer`، plan تغییرناپذیر و شناسه‌های `plan_id`/`plan_hash` **الزام این پروژه نیستند**؛ sync با قابلیت‌های بومی WP All Import انجام می‌شود (D-15/D-16).

الزام‌های ایمنی که باقی می‌مانند و از طریق پیکربندی خود WP All Import تأمین می‌شوند:

- اجرای آزمایشی/پیش‌نمایش پیش از اجرای واقعی روی داده‌های واقعی؛
- `Delete missing records = OFF`؛
- فقط **به‌روزرسانی**، با whitelist فیلد محدود به `registration_counter`؛ `Update all data = NEVER`؛
- mapping صریح و نسخه‌دار؛ mapping خودکار در production خاموش؛
- backup/snapshot پیش از اجرا، چون بازگردانی تراکنشی برای update درجا تضمین‌شده نیست؛
- گزارش نتیجه که موفق/ناموفق/رد‌شده را تفکیک کند.

### 18.4 exact-match و ambiguity policy

Counter row فقط با `national_id` normalize‌شده تطبیق داده می‌شود؛ WordPress counter تولید نمی‌کند و relation/link جدیدی بین دانش‌آموزان نمی‌سازد.

- صفر Entry منطبق → `MATCH_NOT_FOUND`؛ بدون نوشتن؛
- یک یا چند Entry با همان کد ملی → **همگی همان شمارنده را می‌گیرند**. چند Entry برای یک کد ملی **ابهام نیست، خطا نیست و به تصمیم Admin ارجاع نمی‌شود**؛
- کد ملی‌ای که قبلاً شمارنده گرفته است → **درخواست‌کنندهٔ جدید محسوب نمی‌شود**؛ Entry تکراری بعدیِ همان کد ملی در sync بعدی همان شمارندهٔ موجود را دریافت می‌کند؛
- شمارندهٔ موجود یکسان → skip (بدون تغییر)؛
- تعارض واقعی داده (یک کد ملی در فایل مبدأ با دو شمارندهٔ متفاوت) → `COUNTER_CONFLICT`؛ بدون نوشتن؛ اصلاح در مبدأ.

`canonical_entry_id`، `Linked Duplicate`، auto-linking و انتخاب Primary بخشی از v1 نیستند. همه Entryها حفظ می‌شوند و deletion/replace ممنوع است.

### 18.5 audit

برای هر logical write، audit شامل batch/plan ID، actor/executor، UTC، file hash کوتاه، Entry ID، National ID masked، old/new counter و نتیجه است. summary قابل دانلود نگه داشته می‌شود. Notes انسانی محل machine log انبوه یا historical PII نیست؛ destination دقیق audit باید Admin-only باشد. custom audit table فقط پس از failure اثبات‌شدهٔ storageهای maintained و ADR مستقل مجاز است.

### 18.6 final Gravity Flow completion

WP All Import فقط **شمارنده را می‌نویسد و پیشروی Flow را هدایت نمی‌کند**. برای نهایی‌سازی، در صورت کفایت از **bulk action بومی Gravity Flow** (مثل approve گروهی از Inbox) استفاده می‌شود؛ هیچ completion سفارشیِ importer-محور ساخته نمی‌شود. `send_to_step()`/به‌روزرسانی مستقیم جدول Gravity Flow ممنوع است. اگر گام نهایی به دخالت دستی نیاز داشت، Admin آن را به‌صورت بومی کامل می‌کند.

### 18.7 چرا GravityImport رد شد؟

GravityImport برای این عمل bounded مناسب نیست، زیرا vendor می‌گوید update، Entry موجود را delete و با Entry جدید replace می‌کند. این رفتار می‌تواند Entry ID و workflow metadata را تغییر دهد و audit/Flow integrity را به خطر اندازد. [مستند محصول](https://www.gravitykit.com/products/gravityimport/) استفاده از آن برای Counter Import این سیستم `REJECTED` است.

### 18.8 پیکربندی WP All Import (مرجع منتخب sync)

`ACTIVE_NORMATIVE`

WP All Import + Gravity Forms Add-On **مرجع منتخب sync شمارنده** است (D-15/D-16) و این انتخاب باز نمی‌شود. قابلیت‌های مورد اتکا: import به فرم موجود، mapping فیلد، زمان‌بندی، و به‌روزرسانی انتخابیِ فیلد.

نکتهٔ مستند که باید در محیط واقعی راستی‌آزمایی شود (`V-06`): مستندات رسمی، به‌روزرسانی انتخابی را عمدتاً برای Entryهایی توضیح می‌دهند که خودِ همان import ساخته/مدیریت کرده است؛ بنابراین تطبیق با Entryهای ساخته‌شده توسط فرم عمومی بر کلید کد ملی باید در محیط هدف تأیید شود. این یک ریسک پیکربندی است، نه دلیل بازکردن انتخاب. [GF Import](https://www.wpallimport.com/documentation/how-to-import-gravity-forms-entries/)؛ [GF Selective Update](https://www.wpallimport.com/documentation/how-to-migrate-gravity-forms-entries/)؛ [Match Existing](https://www.wpallimport.com/documentation/import-types/)

سیاست production:

- `Delete missing records = OFF`؛
- `Create new` و `Update existing` recipe/import جدا؛ Counter path فقط update؛
- `Update all data = NEVER`؛ فقط whitelist فیلدهای Counter؛
- Automatic Setup/AI mapping در production خاموش؛ mapping explicit و versioned؛
- backup/snapshot پیش از import، چون بازگردانی تراکنشی برای update درجا اثبات نشده؛
- کد ملی canonical کلید تطبیق کسب‌وکار است؛ چند Entry با یک کد ملی حالت عادی و مورد انتظار است و همگی همان شمارنده را می‌گیرند؛
- هیچ اتکایی به اجرای validation/feed/notification گراویتی‌فرمز یا راه‌اندازی Flow توسط import؛ import گردش‌کار را جلو نمی‌برد؛
- Notes انسانی محل machine log انبوه نیست؛ import report و audit delta جدا می‌ماند.

اگر WP All Import در محیط هدف نتواند تطبیق بر کلید کد ملی و حفظ Entry/Flow را نشان دهد، این یک یافتهٔ `V-06` است و باید با تغییر پیکربندی یا ارجاع به مالک حل شود؛ ساخت importer سفارشی، معماری جایگزینِ تأییدشدهٔ این نسخه نیست.

---

## 19. Matrix2 boundary

### 19.1 نقش

Matrix2 consumer یک dataset از پیش eligible است. WordPress export/import boundary باید field mapping و machine Valueها را صریح تحویل دهد. Matrix2 نباید raw Gravity Forms Entry را بگیرد و از روی meta حدس بزند approvals رخ داده‌اند.

### 19.2 وضعیت gender drift

در commit `24a13e9…` conflict قبلی رفع شده است:

- `Gender.MALE = 1`؛
- `Gender.FEMALE = 0`؛
- policy `gender_codes` همان values را دارد؛
- loader drift را رد می‌کند؛
- tests representationهای ASCII/Persian/Arabic را پوشش می‌دهند.

پس current architecture به female=2 adapt نمی‌شود و conflict جاری وجود ندارد. هر import/export regression باید value `2` را obsolete/invalid بداند.

### 19.3 mapping contract

پیش از downstream launch، mapping جداگانه‌ای باید این‌ها را تعیین کند:

- GF Field/Input ID → canonical export column؛
- Choice Value → Matrix2 expected value؛
- null/zero semantics؛
- eligible filter proof؛
- exact Counter match/ambiguity outcome؛
- counter field.

این mapping مجوز redesign Matrix2 نیست.

---

## 20. دو Gate قرارداد فیلد و Binding

### 20.1 Gate A — Semantic Field Contract

پیش از scaffold فقط معنا قفل می‌شود: contract ID، machine purpose، source، canonical/derived representation، Valueها، required/default، normalization/validation، visibility/editability، workflow/export/print role، sensitivity و write paths. در این Gate وجود `field_id` نهایی الزامی نیست. پس از Owner Approval، scaffold فرم/Flow/View مجاز است؛ business semantics بدون ADR تغییر نمی‌کند.

### 20.2 Gate B — Implementation Mapping

پس از ساخت scaffold و قبل از feature code/config freeze، شناسه‌های واقعی bind می‌شوند:

```text
form_id
field_id / input_ids
Officer Approval step identifier
Accountant Approval step identifier
final external-pending step identifier
View IDs / route slugs
required capabilities
plugin/version manifest
```

Binding با label ترجمه‌پذیر یا متن UI authority نمی‌گیرد. هر تغییر ID پس از freeze باید mapping version و regression scope را به‌روزرسانی کند.

### 20.3 schema اجباری قرارداد تلفیقی

هر field مادی یک row با ستون‌های زیر دارد:

| ستون | تعریف |
|---|---|
| `contract_id` | شناسهٔ مستقل و پایدار سند، مثل `STUDENT_NATIONAL_ID` |
| `human_label_fa` | label فارسی نمایش |
| `machine_purpose` | کلید معنایی ثابت برای config/mapping |
| `gf_field_type` | نوع دقیق Gravity Forms |
| `field_id` | در Gate A خالی؛ در Gate B، ID نهایی فرم جدید |
| `input_ids` | در Gate A semantic sub-inputها؛ در Gate B شناسه‌های واقعی Name/Checkbox/multi-input |
| `required` | public/officer/downstream requirement |
| `choice_values` | Value و Label مجزا؛ authority هر Value |
| `source_of_truth` | Owner/Crosswalk/Matrix2/Form/External |
| `normalization` | digits/date/text/code rule |
| `canonical_storage` | representation ذخیره‌شدهٔ authoritative و encoding/format دقیق |
| `derived_representations` | display/export/API values که از canonical مشتق می‌شوند؛ authority نیستند |
| `server_validation` | algorithm/matrix/file rule |
| `default_semantics` | تفاوت empty/null/0 |
| `public_visibility` | visible/conditional/hidden/admin |
| `officer_visibility` | در Desk/detail |
| `officer_editability` | yes/no و step |
| `accountant_visibility` | read-only/hidden |
| `print_inclusion` | yes/no و format |
| `workflow_role` | assignment/condition/review/none |
| `export_role` | column/value/eligibility |
| `sensitivity` | PII/file/admin |
| `retention` | سیاست نگهداری یا owner decision |
| `write_paths` | public/Flow/GV/Admin/import/API و coverage validation هر مسیر |
| `change_impact` | components/tests affected |
| `semantic_status` | Draft/Owner Approved/Superseded |
| `binding_status` | Unbound/Bound/Verified/Superseded |
| `mapping_version` | نسخه binding؛ تغییر آن regression scope می‌سازد |

### 20.4 fieldهای معماری‌-مادی که حتماً در Gate باشند

- Student name inputs؛
- normalized national ID؛
- mobile canonical value و representationهای `local/e164/SMS`؛
- gender؛
- educational level، grade/group و educational/graduation status؛
- center؛
- finance status و Hekmat-only fields؛
- school code/label، Other name و report upload؛
- DOB components و canonical DOB؛
- اگر پذیرفته شد، derived Gregorian/Jalali counterpart همراه با conversion authority؛
- student photo؛
- Officer-editable fields؛
- `review_status/reasons/other_note/entered_at`؛
- `registration_counter`؛
- `review_operation_id/review_actor_user_id/review_payload_hash`؛
- هر field لازم برای eligibility/export.
- Counter match key، import whitelist و update ownership هر فیلد.
- `tuition_amount`، `discount_amount`، `discount_title` و `net_payable_amount`: واحد canonical/display=ریال؛ همه optional و non-public/Registration-Officer-only؛ `discount_amount` default=`0` مجاز؛ formula=`tuition-discount`؛ discount بزرگ‌تر از tuition = validation error/no save؛
- Cheque child-form contract با cardinality `1..N` و parent relation ownership؛ فیلدهای manual مالی/چک در release جاری optional هستند؛
- Sayad v01 fields: `qr_version/owner_type/owner_identifier/iban/bank_branch/cheque_serial/sayad_id` همگی Hidden و future-reserved؛ current-release Scanner population = deferred؛
- write-path جاری برای finance/cheque = `MANUAL_OFFICER_EDIT` از Gravity Flow native؛ `STRUCTURED_SCANNER_POPULATE` فقط future/deferred است و release جاری به آن وابسته نیست.

### 20.5 نمونهٔ row، غیرنهایی

| contract_id | machine_purpose | type | Value/Rule | source | Officer edit | print | status |
|---|---|---|---|---|---:|---:|---|
| `STUDENT_GENDER` | `gender_code` | Radio | female=`0`, male=`1` | Owner + Matrix2 | طبق semantic whitelist | بله | Semantic Approved / Unbound |
| `SCHOOL_CODE` | `school_code` | Drop Down | Crosswalk; Other=`0`; non-blocking | Crosswalk + Owner | raw code خیر؛ system-mediated از انتخاب Officer بله | بله | Owner Approved / ID Unbound |
| `SCHOOL_NAME` | `school_name` | Text/Choice label | نام مدرسه؛ قابل اصلاح | Crosswalk + Owner | بله | بله | Owner Locked / ID Draft |
| `REVIEW_STATUS` | `review_status` | Administrative choice | `none/needs_review/resolved_by_approval` | Workflow overlay | system | خیر | Proposed |
| `TUITION_AMOUNT` | `tuition_amount` | Number | ریال؛ optional؛ non-public؛ Registration-Officer-only | Owner | بله | بله | Owner Approved / ID Unbound |
| `DISCOUNT_AMOUNT` | `discount_amount` | Number | ریال؛ optional؛ default=0؛ اگر > tuition → no save | Owner | بله | بله | Owner Approved / ID Unbound |
| `DISCOUNT_TITLE` | `discount_title` | Text | optional؛ non-public؛ Registration-Officer-only | Owner | بله | بله | Owner Approved / ID Unbound |
| `NET_PAYABLE_AMOUNT` | `net_payable_amount` | Number/Calculated | ریال؛ `tuition_amount - discount_amount`; direct Officer override مجاز نیست | Derived from Owner contract | خیر | بله | Owner Approved / ID Unbound |

این نمونه approval نیست و Field ID تولید نمی‌کند.

---

## 21. انتخاب/رد افزونه‌ها و componentهای اکوسیستم

`ACTIVE_NORMATIVE` — وضعیت انتخاب جاری. «دانش محصول» با «انتخاب پروژه» یکی نیست: مواردی که اینجا انتخاب نشده‌اند همچنان به‌عنوان دانش محصول در بستهٔ سازه‌پذیری نگه‌داری می‌شوند.

| Candidate | capability واقعی | حکم جاری | دلیل |
|---|---|---|---|
| Gravity Forms | فرم عمومی، فیلدها، Entry canonical | `SELECTED — AUTHORITY` | مرجع دادهٔ canonical |
| Gravity Flow Inbox/Entry Details/Approval | صندوق واحد، جزئیات، ویرایش فیلد مجاز، Approval رسمی | `SELECTED — AUTHORITY` | مرجع workflow و رابط عملیاتی اصلی |
| GravityView | ارائهٔ فقط‌خواندنی (Table/List/Layout Builder، Single Entry) | `OPTIONAL_PRESENTATION_ONLY` | مجاز برای زیباسازی ارائه؛ هرگز مرجع workflow/queue/approval/Needs Review |
| GravityView Edit Entry | ویرایش front-end | `PRODUCT_KNOWLEDGE_ONLY — NOT SELECTED` | ویرایش عملیاتی بومی Gravity Flow است (D-04) |
| GravityView Entry Locking | قفل ویرایش front-end | `PRODUCT_KNOWLEDGE_ONLY — NOT SELECTED` | بدون concurrency سفارشی و بدون الزام قفل (D-08) |
| GravityView Entry Notes | یادداشت front-end | `PRODUCT_KNOWLEDGE_ONLY — NOT SELECTED` | وضعیت بررسی فقط در `review_status` است (D-01) |
| GravityView Bulk/DataTables/Lightbox | ارائه/عملیات گروهی front-end | `PRODUCT_KNOWLEDGE_ONLY — NOT SELECTED` | نهایی‌سازی گروهی در صورت نیاز با bulk بومی Inbox انجام می‌شود |
| انتخابگر مدرسه بومی/نگهداری‌شده | جست‌وجوی نام مدرسه | `SELECTED — SIMPLEST THAT PASSES V-03` | تنها معیار: جست‌وجوی responsive فارسی روی موبایل (D-09) |
| Chained Selects / Populate Anything / Advanced Select | وابستگی و انتخاب پیشرفته | `PRODUCT_KNOWLEDGE_ONLY — NOT SELECTED` | مقایسهٔ سه‌گانه و chaining حذف شد (D-09) |
| راه‌حل سادهٔ ایرانی کد ملی/موبایل/جلالی | اعتبارسنجی ورودی ایرانی | `SELECTED — SIMPLE MAINTAINED` | بدون kernel/adapter سفارشی (D-11) |
| GF3 Phone / GP Advanced Phone / GF IR Mobile | اعتبارسنجی تلفن | `PRODUCT_KNOWLEDGE_ONLY — NOT SELECTED` | قرارداد E.164 و comparator چندگانه حذف شد (D-11) |
| GP Limit Submissions / No Duplicates | محدودسازی ارسال | `NOT SELECTED` | مسدودسازی تکراری کاملاً حذف شد (D-10) |
| GP File Upload Pro / پردازش تصویر | بهینه‌سازی عکس | `OUT_OF_CURRENT_SCOPE` | پردازش عکس خارج از دامنهٔ جاری (D-12) |
| GravityRevisions | تاریخچه/مقایسه/بازگردانی ویرایش انسانی | `SELECTED — ADMIN ONLY` | ممیزی ویرایش انسانی مهم (D-13) |
| Gravity Perks Nested Forms | repeatable child Entries برای چندچک | `SELECTED HOST / POC_NOT_PROVEN` | Owner re-adjudication؛ هر چک child Entry مستقل؛ entitlement/runtime هنوز اثبات نشده |
| PersianGravity Structured Scanner | scanner/profile عمومی برای parse+mapping به ordinary GF fields | `SELECTED GENERIC CAPABILITY / POC_NOT_PROVEN` | raw QR persist نمی‌شود؛ Sayad v01 قرارداد هفت-output اتمیک دارد |
| WP All Import + GF Add-On | sync شمارنده بر کلید کد ملی | `SELECTED — COUNTER SYNC AUTHORITY` | فقط شمارنده؛ بدون هدایت workflow (D-15/D-16) |
| GravityImport | جایگزینی Entry هنگام update | `REJECTED` | Entry ID و workflow metadata را به خطر می‌اندازد |
| Gravity PDF Free + SRWF print layer | خروجی نهایی چاپی | `POC_CANDIDATE / NOT_PROVEN` | candidate اول D-17؛ no paid extension/template؛ final selection فقط بعد از POC PASS |
| Elementor / CPT/ACF/JetEngine mirror | ارائهٔ جایگزین یا mirror داده | `REJECTED` | source of truth دوم و پیچیدگی بی‌دلیل |
| Uncanny Automator | orchestration بیرونی | `DEFERRED — REQUIREMENT TRIGGERED` | هرگز مالک assignment/approval/current step نمی‌شود |

## 22. Performance و operations

### 22.1 public path budget

- only page-specific assets؛
- static Crosswalk/school choices، بدون runtime DB school service؛
- field conditional logic محدود و server snapshot immutable؛
- عکس در submit request نباید timeout/Memory Exhaustion ایجاد کند؛ prototype با server limits واقعی؛
- الزام benchmark مسدودسازی تکراری وجود ندارد. (تاریخی: query duplicate بر normalized field/search strategy benchmark شود؛ raw full scan در scale واقعی قابل قبول نیست، ولی custom table پیشاپیش ساخته نمی‌شود؛
- budget مسدودسازی تکراری الزام نیست. (تاریخی: p95 بخش duplicate lookup حداکثر `250 ms` در حجم مورد انتظار و `500 ms` در پنج برابر آن، بدون خطای correctness. این اعداد `PROPOSED` هستند و فقط با baseline ثبت‌شدهٔ host قابل اصلاح‌اند؛ overall submit/photo budget جدا اندازه‌گیری می‌شود.

### 22.2 Officer path

- no full-page cache؛
- Inbox native paging؛
- فقط ستون‌های ضروری؛
- template photo thumbnail مناسب، نه full-resolution؛
- importer/admin libraries در public request load نمی‌شوند.
- اگر DataTables AJAX انتخاب شد، admin-ajax/firewall/cache path و current-page-only export مستند و تست می‌شود؛ ادعای export تمام filtered result ممنوع است.
- اگر Table+Bulk انتخاب شد، background processing، selection across pages، secure download expiry و file count/size limit روی host هدف تست می‌شوند.

### 22.3 concurrency

حجم moderate است؛ queue architecture و background worker لازم نیست. پردازش تصویر خارج از دامنهٔ جاری است. (تاریخی: اگر image processing synchronous target را در prototype رد کرد، first remedy انتخاب یک maintained client-side optimization component است، نه ساخت job platform.

### 22.4 compatibility inventory پیش از build

در staging ثبت شود:

- WordPress، PHP، database و web server versions؛
- Gravity Forms/Flow و add-on versions/licenses؛
- theme/Elementor mode؛
- object/page cache/CDN/optimizer؛
- URL/endpoint exclusions و plugin cache helperهای فعال؛
- `upload_max_filesize`, `post_max_size`, `memory_limit`, image libraries؛
- browser versions و printer profile.

Version range هر minimal bridge از این inventory و official supported matrix تعیین می‌شود؛ حدس version در header ممنوع است.

### 22.5 Compatibility و Upgrade Gate

- production نباید major update برای WordPress، Gravity Forms یا Gravity Flow را پیش از staging regression دریافت کند؛ auto-update major برای این componentهای critical خاموش می‌ماند؛
- minor/patch update اگر changelog به surfaceهای مصرف‌شده مانند Entry Detail، Inbox، Approval، validation، GFAPI یا hookهای نام‌برده اشاره کند، تست‌های targeted همان surface را الزامی می‌کند؛
- هر release manifest فقط ترکیب نسخه‌هایی را `TESTED` می‌نامد که واقعاً اجرا شده‌اند؛ «latest compatible» بدون proof ممنوع است؛
- update failure ابتدا update را block/rollback و component surface را `SURFACE_BLOCKED` می‌کند؛ parent architecture فقط وقتی باز می‌شود که capability ضروری رسماً حذف شده و هیچ replacement supported وجود نداشته باشد؛
- افزونه‌های global localization/automation/cache باید با scope فعال‌شده، recipe/settings export و side-effect matrix inventory شوند؛ نصب بودن آن‌ها مجوز فعال‌سازی همهٔ featureها نیست؛
- حداقل matrix شامل نسخه‌های WP/PHP/database/GF/Flow، theme/Elementor mode، cache/optimizer، سه browser و شناسهٔ test run است.

---

## 23. Audit، logging و observability

### 23.1 native first

- Gravity Flow Timeline/Activity برای formal step actions؛
- GravityRevisions برای ویرایش انسانی از مسیر Gravity Forms/GravityView: actor، time، field و old/new value؛ target fidelity باید پاس شود؛
- GF Entry Notes اختیاری و خارج از الزام پروژه است؛ وضعیت بررسی فقط در `review_status` نگه‌داری می‌شود. (تاریخی: نوع/prefix و visibility آن‌ها از هم جدا می‌شود؛
- WordPress error logging فقط technical و بدون PII کامل؛
- revision history و restore فقط برای Admin؛ Officer هیچ box/widget/link/history endpoint قابل‌استفاده‌ای نداشته باشد.

پوشش ممیزی این پروژه فقط ویرایش انسانی است و هیچ parity برای نوشتن API/import/سیستمی الزام نیست؛ بنابراین ابهام مستندات دربارهٔ رفتار API تعیین‌کنندهٔ هیچ الزام جاری نیست. متن تاریخی: مستند Restore به‌روزشده در ۲۰۲۶ می‌گوید API changes ثبت نمی‌شوند. پس `API_WRITE_COVERAGE=NOT_PROVEN` و هیچ مسیر production بر آن تکیه نمی‌کند. هر project-owned system write باید old/new را پیش از mutation در اختیار داشته باشد و actor/system، UTC، source و correlation را در destination Admin-only ثبت کند. bridge فقط برای path اثبات‌شدهٔ uncovered فعال می‌شود؛ اگر runtime revision کامل ساخت، duplicate audit ممنوع است. Officer-visible Entry Note مقصد historical delta/PII نیست. custom audit table فقط با concrete failure و ADR مستقل مجاز است.

اصلاح اشتباه با ویرایش انسانی ثبت‌شده در GravityRevisions ردیابی می‌شود. (تاریخی: Entry Notes جای GravityRevisions نیست: Notes روایت/توضیح را ثبت می‌کند و Revisions مقدار دقیق قبل/بعد فیلد را.

### 23.2 eventهای لازم

| Event | minimum record |
|---|---|
| Needs Review entered/updated | Entry ID، actor ID، UTC، reason Values، result |
| Human field edit | revision ID، actor، UTC، Field/Input ID، old/new value؛ Admin-only |
| System/API field update | actor/system، UTC، Field/Input ID، old/new value، operation/correlation؛ coverage تا proof مورد اتکا نیست |
| Officer Approval | Gravity Flow native timeline؛ cleanup result |
| ابهام import شمارنده | timestamp، form، hashed/masked ID؛ نه raw ID در log عمومی |
| photo optimize failure | Entry/temp correlation، error code، editor type، نه photo content |
| counter dry-run/commit | batch/file hash، actor، counts، row result summary |
| WP All Import candidate run | import ID/config version، file hash، actor/scheduler، matched/missing/updated/failed counts، snapshot ID |
| Automator recipe، اگر فعال شد | recipe/version، trigger object/ID، idempotency key، whitelisted action result، retry/error؛ بدون PII payload کامل |
| final step process | API response code، previous/current step، post-condition |
| Counter ambiguity resolved | national ID masked، Admin، UTC، correction/reference؛ بدون canonical-link state خودکار |

### 23.3 health UI

Monitoring infrastructure ساخته نمی‌شود. یک freshness indicator فقط اگر native Inbox timestamp به‌سادگی قابل نمایش باشد مجاز است؛ در غیر این صورت `DEFERRED`.

---

## 24. برنامهٔ validation و eval

`ACTIVE_NORMATIVE`

برنامهٔ راستی‌آزمایی جاری دقیقاً همان مجموعهٔ `V-01..V-06` است. هیچ ردیف آزمون دیگری الزام جاری نیست.

### 24.1 مجموعهٔ راستی‌آزمایی جاری

| کد | probe | آنچه اثبات می‌شود | وضعیت |
|---|---|---|---|
| `V-01` | `PRB-NF-V01` | برش عملیاتی بومی: Inbox → Entry Details → ویرایش فیلد مجاز → ذخیره (ماندن روی همان گام/assignee) → Approve بومی → گام بعدی درست. بدون نیاز به GravityView | `UNEXECUTED` |
| `V-02` | `PRB-NF-V02` | حداقل دسترسی: عموم/خروج‌کرده بدون دسترسی عملیاتی؛ مسئول ثبت‌نام دسترسی عملیاتی؛ Admin دسترسی اداری. همچنین باید تأیید شود هیچ صفحهٔ عملیاتی از ویژگی‌های `allow_anonymous` یا `display_all` استفاده نمی‌کند، چون طبق مستندات رسمی این دو، بررسی capability را دور می‌زنند | `UNEXECUTED` |
| `V-03` | `PRB-NF-V03-SCHOOL-SEARCH` | جست‌وجوی نام فارسی مدرسه روی موبایل با dataset واقعی؛ ذخیرهٔ درست `school_code`؛ فناوری‌خنثی تا اولین PASS | `UNEXECUTED` |
| `V-04` | `PRB-NF-V04-HUMAN-REVISION` | ویرایش انسانی مهم از مسیر عملیاتی/اداری مجاز → ثبت revision، مشاهده و مقایسه و بازگردانی برای Admin | `UNEXECUTED` |
| `V-05` | `PRB-NF-V05` | Live Refresh بومی روی صفحهٔ عملیاتی و نبود cache نامناسب؛ بدون مکانیزم realtime سفارشی | `UNEXECUTED` |
| `V-06` | `PRB-NF-V06` | یکسان‌سازی شمارنده: همان کد ملی در چند Entry همان `registration_counter` را می‌گیرد؛ کد ملی دارای شمارنده درخواست‌کنندهٔ جدید نمی‌شود؛ import گردش‌کار را جلو نمی‌برد | `UNEXECUTED` |

### 24.2 مواردی که با مستندات رسمی تأیید شده‌اند

اینها دانش محصول‌اند و اثبات زمان اجرا نیستند:

- فیلدهای Administrative و مقادیر انتخاب پایدار در Gravity Forms؛
- تخصیص/Live Refresh/فیلتر/مرتب‌سازی/صفحه‌بندی و اقدام‌های سریع در Inbox گراویتی‌فلو؛
- محدودیت مستند اقدام سریع نسبت به اعتبارسنجی فیلدهای الزامی؛
- فیلدهای قابل‌ویرایش و فیلدهای نمایشی گام Approval؛
- چیدمان یک/دو ستونی و کنترل Timeline در بلاک Entry Details؛
- گیت capability برای Admin Actions؛
- تنظیمات امنیت شورت‌کد و صفحات پیش‌فرض گراویتی‌فلو.

### 24.3 آزمون‌های محیط واقعی

فقط `V-01..V-06`. هر آزمون به شواهد اجرایی (capture، snapshot وضعیت، اثر انگشت محیط) نیاز دارد و تا اجرا `UNEXECUTED` می‌ماند.

### 24.4 بازبینی انسانی لازم

- قرارداد نهایی فیلدها و snapshot Crosswalk؛
- نقش‌ها/capabilityها و رد دسترسی مستقیم؛
- whitelist فیلدهای قابل‌ویرایش مسئول ثبت‌نام و متن تأییدها؛
- کیفیت جست‌وجوی مدرسه روی موبایل؛
- مشاهده/مقایسه/بازگردانی تاریخچه فقط برای Admin؛
- گزارش‌های ابهام import شمارنده و اصلاح دادهٔ Matrix2؛
- سیاست privacy/retention پیش از دادهٔ واقعی؛
- تصمیم انتشار/rollback.

### 24.5 ردیف‌های آزمون تاریخی

`HISTORICAL` — مجموعهٔ `P-01..P-30` نسخه‌های ۱٫۵٫۰ و قبل‌تر بازنشسته شده‌اند و **الزام جاری نیستند**. سابقه و دلیل بازنشستگی در بستهٔ سازه‌پذیری نگه‌داری می‌شود (`validation/current_verification_queue.json`).

## 25. Bounded Prototype Plan (تاریخی)

`HISTORICAL` — این بخش برنامهٔ prototype نسخه‌های ۱٫۵٫۰ و قبل‌تر است و **هیچ الزام جاری تولید نمی‌کند**. برنامهٔ جاری فقط `V-01..V-06` در §24 است. متن زیر صرفاً برای ردیابی سابقه حفظ شده است.

### BP-1 — Desk queues + freshness

- یک Officer، یک Officer Approval step، review administrative fields؛
- یک GravityView workflow inbox + Advanced Filter برای Current User؛ دو tab/criteria نام‌دار؛
- ۱۰ Entry با mix New/Review؛
- dataset دوم با حجم نماینده و حداقل ۵ برابر صفحهٔ عادی؛
- سه list comparator: Table+Bulk، DataTables AJAX و Search-first؛
- measure submit→visible، sort/search/paging، reassignment denial، direct Single Entry denial و URL tampering؛ built-in Flow Inbox به‌عنوان comparator؛
- فقط در Table: Export selected و Download Attachments با current/across-pages، background job، secure link و size/count limits؛ Bulk Edit/Approval/Delete خاموش؛
- فقط در DataTables AJAX: export current page و firewall/admin-ajax behavior ثبت شود؛ coexistence با Bulk Actions فرض نشود.

**تصمیم:** اگر GravityView پاس کرد، custom list حذف و یک layout اصلی بر اساس کمترین burden و نیاز واقعی انتخاب می‌شود. اگر ZIP/selected export requirement مادی نبود، آن capability دلیل ساخت View دوم نیست. اگر freshness یا authorization fail شد، Flow Inbox fallback و فقط gap محدود presentation بررسی می‌شود.

### BP-2 — Needs Review save

**بازنشسته در ۱٫۶٫۰ (D-01):** مکانیزم POST اعتبارسنجی‌شدهٔ سفارشی حذف شد. Needs Review اکنون فقط یک فیلد Entry + دلیل است و ویرایش از مسیر بومی Gravity Flow انجام می‌شود. probeهای مرتبط بازنشسته شدند (`PRB-ACT-001`, `PRB-NOTES-001`). جایگزین: `V-01` / `PRB-NF-V01`.

### BP-3 — School selector

- dataset کل حدود ۹۵۰ choice، hierarchy واقعی level→grade/group→school و بزرگ‌ترین subset؛ full form payload نیز با شیوهٔ واقعی serialization/enqueue سنجیده می‌شود؛
- سه candidate: native fields/Enhanced UI، Chained Selects CSV، Populate Anything+Advanced Select؛
- Android low/mid-range و iPhone target؛
- Persian search، keyboard، scroll، time-to-interactive، submit، invalid combination tampering؛
- edit همان values در Gravity Flow User Input و GravityView Edit؛
- data maintenance: CSV refresh/import در برابر dynamic source، stable machine Value و orphan/duplicate detection.

**تصمیم:** Candidate C preferred prototype، Candidate A minimum-complexity comparator و Candidate B maintained hierarchy comparator است؛ برنده کم‌بارترین مسیری است که search سریع موبایل، canonical code، server integrity و Flow/GV edit را پاس کند. Candidate D فقط پس از failure مستند A/B/C؛ ترکیب افزونه‌ها بدون POC جدید ممنوع است.

### BP-4 — Photo

- نمونه‌های portrait/landscape، HEIC در صورت اجازه، JPEG بزرگ، corrupt و spoofed extension؛
- record memory/latency/output dimensions/quality؛
- no original corruption on failure.

**تصمیم:** server path پاس → keep؛ fail → comparator File Upload Pro/client compression.

### BP-5 — Counter/Flow completion

- Excel نماینده با valid/invalid/duplicate/conflict rows؛
- dry-run با immutable plan/hash، commit همان plan، precondition revalidation، stale-plan و retry در staging clone؛
- final current step از type واقعی؛ process via documented API؛
- assert eligibility، canonical، audit و post-condition.
- همان شش Entry با WP All Import GF Add-On: match با Entry ID و اگر UI اجازه داد business key؛ update فقط Counter fields؛ preservation عکس/مدرک/Notes/created_by/Flow؛ rerun و یک row نامعتبر؛
- `Create new`, `Delete missing`, `Update all` خاموش و pre-run snapshot؛ validation/feed/notification behavior ثبت، نه فرض.

**تصمیم:** engine Counter فقط اگر matching، whitelist، preservation، idempotency و audit را پاس کند انتخاب می‌شود. WP All Import fail → importer bounded؛ pass → می‌تواند engine update باشد اما dry-run/approval/snapshot/Flow completion contract همچنان جدا و اجباری است. API final-step pass → automatic completion؛ fail/unsupported → manual completion، بدون direct DB workaround.

### BP-6 — Duplicate lookup correctness/performance

**بازنشسته در ۱٫۶٫۰ (D-10):** مسدودسازی/lookup تکراری کاملاً حذف شد؛ کد ملی تکراری مجاز است. یکسان‌سازی شمارنده در import (D-15) و probe `V-06`/`PRB-NF-V06`.

### BP-7 — GravityView/Elementor presentation routes

**بازنشسته/معوق در ۱٫۶٫۰:** ارائهٔ عملیاتی اکنون بومی Gravity Flow است (Inbox/Entry Details، چیدمان یک/دو ستونی، نمایش/عدم‌نمایش Timeline). GravityView فقط ارائهٔ اختیاری فقط-خواندنی است و مرجع workflow نیست. مسیرهای سنگین Elementor/Route B حذف شدند.

### BP-8 — Revision completeness و access

**بازنشسته (D-13):** parity ممیزی API/import/سیستمی حذف شد؛ ممیزی فقط برای ویرایش‌های انسانی Officer/Admin با GravityRevisions است. `BLK-AUD-001` حل شد. probeهای قدیمی `PRB-AUDIT-001` و `PRB-AUDIT-002` بازنشسته شدند؛ probe جاری `V-04` = `PRB-NF-V04-HUMAN-REVISION`.

### BP-9 — Iranian data quality و canonical write paths

**بازنشسته در ۱٫۶٫۰ (D-11):** معماری kernel+adapter و comparatorهای E.164/جلالی چندمسیره حذف شدند. کد ملی/موبایل/جلالی با راه‌حل‌های سادهٔ ایرانیِ نگهداری‌شده مدیریت می‌شوند. probeهای `PRB-BP9-001..004` بازنشسته شدند.

### BP-10 — Browser Print در برابر Gravity PDF

**تاریخی:** در ۱٫۶٫۰ D-17 renderer را کاملاً معوق کرد. این وضعیت در ۱٫۷٫۰ با تصمیم Owner refine شد: `Gravity PDF Free` candidate اول POC است، بدون dependency پولی و بدون Browser Print موازی؛ authority جاری §0 و §15.5 است.

## 26. Implementation Sequence با Gateها

`ACTIVE_NORMATIVE`

ترتیب اجرا بر پایهٔ قابلیت بومی است. هیچ گام سفارشی Needs Review/Desk/audit/importer در این ترتیب وجود ندارد.

**Stage 0 — قرارداد و محیط**
- تثبیت قرارداد معنایی فیلدها و Crosswalk؛
- تثبیت نسخهٔ محصولات و محیط staging (`BLK-ENV-001` تا این‌جا فعال است).

**Stage 1 — فرم عمومی**
- ساخت فرم Gravity Forms با فیلدهای اداری `review_status` و دلیل بررسی؛
- انتخابگر مدرسه با ساده‌ترین راه بومی/نگهداری‌شده؛ گیت: `V-03`؛
- اعتبارسنجی کد ملی/موبایل/جلالی با راه‌حل‌های سادهٔ نگهداری‌شده؛
- فیلد آپلود عکس (بدون پردازش).

**Stage 2 — گردش‌کار بومی**
- تعریف گام Approval مسئول ثبت‌نام با whitelist فیلدهای قابل‌ویرایش و فیلدهای نمایشی؛
- گام Accountant و گام نهایی؛
- گیت: `V-01`.

**Stage 3 — دسترسی**
- نقش/capability مسئول ثبت‌نام، محدود نگه‌داشتن Admin Actions و امنیت شورت‌کد؛
- گیت: `V-02`.

**Stage 4 — رابط عملیاتی**
- صفحات Inbox و Entry Details بومی (چیدمان، فیلدهای نمایشی، Timeline)؛
- بدون Desk سفارشی و بدون locking سفارشی؛
- گیت: `V-05` (Live Refresh و نبود cache نامناسب).

**Stage 5 — ممیزی انسانی**
- فعال‌سازی GravityRevisions با دسترسی فقط Admin؛
- گیت: `V-04`.

**Stage 6 — شمارنده**
- پیکربندی WP All Import برای sync شمارنده بر کلید کد ملی، فقط روی فیلد شمارنده؛
- نهایی‌سازی گردش‌کار به‌صورت بومی/دستی؛
- گیت: `V-06`.

**Stage 7 — عملیات و انتشار**
- ماتریس سازگاری/ارتقای vendor و regression روی staging؛
- سیاست privacy/retention؛
- بازبینی‌های انسانی §24.4 و تصمیم انتشار.

**Rollback:** غیرفعال‌سازی/بازگردانی فقط component یا چسب جدید، بازگردانی نسخه‌های آزموده‌شدهٔ قبلی و پیکربندی؛ داده حذف نمی‌شود.

## 27. Risk Register

`ACTIVE_NORMATIVE` — ریسک‌های جاری معماری Native-First.

| # | ریسک | اثر | کاهش | fallback |
|---|---|---|---|---|
| `R-01` | محیط هدف هرگز اعتبارسنجی نشود و طراحی اثبات‌نشده بماند | بحرانی | `BLK-ENV-001` فعال بماند؛ `V-01..V-06` پیش از انتشار اجرا شود | بدون انتشار |
| `R-02` | whitelist فیلدهای قابل‌ویرایش گام Approval اشتباه تنظیم شود و فیلد غیرمجاز قابل ویرایش گردد | بحرانی | تعریف صریح whitelist؛ `V-01` | محدودسازی بیشتر whitelist |
| `R-03` | دسترسی عملیاتی به کاربر غیرمجاز نشت کند (شورت‌کد/URL/nonce) | بحرانی | تنظیمات امنیت شورت‌کد محدود؛ `V-02` | خاموش‌کردن سطوح front-end |
| `R-04` | جست‌وجوی نام مدرسه روی موبایل کند یا نامطمئن باشد | زیاد | `V-03` با dataset واقعی؛ توقف پس از اولین PASS | راه بومی/نگهداری‌شدهٔ سادهٔ بعدی |
| `R-05` | cache/optimizer صفحهٔ عملیاتی را کهنه نگه دارد | زیاد | استثناکردن صفحات عملیاتی از cache؛ `V-05` | غیرفعال‌کردن cache روی آن مسیرها |
| `R-06` | ممیزی ویرایش انسانی ناقص یا برای غیر Admin قابل مشاهده باشد | زیاد | پیکربندی دسترسی؛ `V-04` | محدودسازی دسترسی تاریخچه |
| `R-07` | sync شمارنده Entry نادرست را به‌روزرسانی کند یا شمارنده‌ها ناهمخوان شوند | بحرانی | تطبیق دقیق کد ملی، dry-run و گزارش ابهام؛ `V-06` | توقف import و اصلاح انسانی |
| `R-08` | import به‌صورت ناخواسته گردش‌کار را جلو ببرد | بحرانی | importer فقط فیلد شمارنده را می‌نویسد؛ `V-06` | نهایی‌سازی دستی |
| `R-09` | ارتقای vendor رفتار بومی متکی‌شده را تغییر دهد | زیاد | ماتریس نسخه، regression روی staging | بازگردانی نسخه |
| `R-10` | فشار برای افزودن پیچیدگی سفارشی (Desk/queue/locking/audit bridge) بازگردد | متوسط | §28 و قاعدهٔ Native-First؛ نیاز به ADR | رد درخواست |
| `R-11` | POC چاپ فارسی/Unicode/A4 یا UX Officer fail شود و renderer نهایی بسته نشود | زیاد | D-17 POC Gate با synthetic data؛ no paid dependency؛ no dual renderer | توقف همان candidate و Owner re-adjudication برای renderer بعدی |
| `R-12` | Nested Forms در target Gravity Flow surface child render/save/link یا finance composition را پاس نکند | زیاد | POC bounded با synthetic data؛ no custom relationship state | همان candidate fail؛ Parent-Child Forms فقط fallback بعدی |
| `R-13` | QR ساختار بانک/نسخهٔ دیگری با Sayad v01 هفت-output ناسازگار باشد | زیاد | validation محافظه‌کارانه؛ sampleهای بیشتر قبل از قفل قواعد قوی‌تر | profile version جدید/Owner review؛ نه حدس parser |
| `R-14` | Scanner در خطای parse بعضی targetها را تغییر دهد و بعضی را نه | بحرانی | pure parse/plan + atomic apply + unit tests | reject updateSet و حفظ existing targets |
| `R-15` | دادهٔ مالی persisted با formula `tuition-discount` ناسازگار شود | زیاد | Semantic Contract + server-side validation/recompute روی write path منتخب | توقف همان save و correction روی Entry |

## 28. Minimality Challenge

`ACTIVE_NORMATIVE` — هر افزوده باید gap اثبات‌شدهٔ قابلیت بومی داشته باشد.

| افزوده | چه چیزی را حل می‌کند | هزینه | حکم جاری |
|---|---|---|---|
| Gravity Forms + Gravity Flow | فرم/داده + گردش‌کار و رابط عملیاتی | پایه | `KEEP — AUTHORITY` |
| GravityRevisions | تاریخچهٔ ویرایش انسانی مهم | وابستگی پولی + فضای ذخیره | `KEEP — REQUIRED BY V-04` |
| WP All Import | sync شمارنده | پیکربندی import | `KEEP — REQUIRED BY V-06` |
| افزونهٔ سادهٔ ایرانی (کد ملی/موبایل/جلالی) | اعتبارسنجی ورودی فارسی | وابستگی سبک | `KEEP IF SIMPLEST PASSING` |
| GravityView | ارائهٔ فقط‌خواندنی زیباتر | وابستگی + سطح اضافی | `OPTIONAL — ONLY IF PRESENTATION GAP PROVEN` |
| Desk/queue/لیست سفارشی | — | زیاد | `REJECT` (Inbox بومی کافی است) |
| قفل/concurrency سفارشی | — | زیاد | `REJECT` (D-08) |
| endpoint سفارشی Needs Review | — | زیاد | `REJECT` (D-01) |
| audit bridge برای نوشتن سیستمی/API | — | زیاد | `REJECT` (D-13) |
| قاعدهٔ duplicate/مسدودسازی | — | متوسط | `REJECT` (D-10) |
| kernel/adapter اعتبارسنجی سفارشی | — | زیاد | `REJECT` (D-11) |
| پردازش/بهینه‌سازی عکس | — | متوسط | `OUT_OF_CURRENT_SCOPE` (D-12) |
| مسیر مستقیم نوشتن GFAPI پروژه | — | متوسط | `REJECT` (D-14) |
| `Gravity PDF Free` + SRWF print layer | خروجی چاپی نهایی | متوسط | `KEEP AS D-17 POC CANDIDATE`; افزونهٔ SRWF فقط بعد از gap اثبات‌شده |
| GP Nested Forms | child Entryهای repeatable برای چندچک | dependency نگهداری‌شده/entitlement | `KEEP AS SELECTED HOST PENDING POC`; خرید جدید خودکار مجاز نیست |
| PersianGravity Structured Scanner | ورود scan-assisted بدون data/workflow دوم | کد generic کوچک + تست | `KEEP`; فقط parser/controller عمومی، بدون SRWF relationship/workflow logic |
| custom cheque relationship table/state | — | زیاد + SSOT دوم | `REJECT` |
| POS/Windows utility در current release | — | dependency عملیاتی جدید | `DEFER`; فقط در release بعد با interface/probe مشخص |
| mirror داده (CPT/ACF/JetEngine) | — | زیاد | `REJECT` |
| پلتفرم monitoring | — | زیاد | `REJECT` |

## 29. WHAT_NOT_TO_BUILD

- workflow step/branch دوم برای Needs Review؛
- Boolean سفارشی به‌عنوان جایگزین Flow current step؛
- Officer Reject؛
- custom wp-admin replacement یا SPA؛
- REST front-end جدید صرفاً برای ظاهر Desk؛
- دو Inbox block هم‌زمان بدون اثبات؛
- Quick Actions approval؛
- GravityView Bulk Approve/Disapprove/Reset Approval یا Delete برای Officer؛
- Frontend Bulk Edit روی فرم دارای Conditional Logic؛
- فرض coexistence خودکار DataTables و Bulk Actions یا export همهٔ نتایج در AJAX mode؛
- optimistic success toast؛
- label-based field lookup؛
- raw SQL روی tableهای Gravity Forms/Flow؛
- custom state/audit database؛
- school runtime database، sync service یا Crosswalk reader؛
- city inference از national ID؛
- unconditional No Duplicates؛
- photo pre-compression burden، forced crop یا heavy editor؛
- PDF storage/archive subsystem؛ Gravity PDF Core فقط derived document طبق BP-10؛
- WebSocket، message queue، Cron polling یا background worker؛
- analytics dashboard، SLA/escalation/aging colors؛
- advanced Desk Search/Filter نسخهٔ اول؛
- field-versioning سفارشی موازی با GravityRevisions، مگر برای gap اثبات‌شدهٔ API-write؛
- CPT/ACF/JetEngine mirror برای Elementor؛
- static/manual Entry ID در reusable Elementor profile؛
- Elementor visibility به‌عنوان authorization؛
- Enhanced Security secret به‌عنوان per-entry authorization؛
- Entry creator ownership به‌عنوان مجوز Officer؛
- Entry Notes به‌عنوان Needs Review/workflow state یا امکان حذف Note توسط Officer؛
- GravityView Entry Approval یا Entry Tags به‌عنوان parallel workflow state؛
- auto-canonical بر اساس lowest Entry ID/first/last؛
- GravityImport برای counter update؛
- WP All Import `Update all`، `Delete missing` یا fuzzy/implicit Entry matching در Counter path؛
- فرض اینکه Import/Automator writeها GF validation، feeds، Gravity Flow یا GravityRevisions را خودکار اجرا می‌کنند؛
- Automator recipe برای Officer assignment، Needs Review، Accountant/Officer Approval، current step/status یا حذف canonical Entry؛
- Database Query/SQL action برای write در tableهای Gravity Forms/Flow؛
- recursive `Entry updated → update same trigger field` recipe بدون loop/idempotency guard؛
- global Jalali/number conversion بدون storage/API/export regression test؛
- CI نمایشی که ادعا کند انسان/مدل سند را فهمیده است؛
- index/cache/approval marker مشتق پیش از BP-6 یا به‌عنوان workflow authority؛
- Matrix2 logic برای approvals؛
- legacy form ID compatibility یا entry migration؛
- plugin-core modifications؛
- one-file 600+ line god script یا framework چندلایهٔ نمایشی.

---

## 30. Non-blocking visual defaults

- Desk RTL، high-contrast، desktop-first؛
- reuse فونت فارسی موجود و سالم theme؛ اگر هیچ فونت مناسب نیست، یک خانوادهٔ maintained محلی با subset لازم، نه چند weight غیرضروری؛
- دو tab بزرگ «ثبت‌نام‌های جدید» و «نیازمند بررسی»؛ count واضح؛
- action اصلی Approve برجسته، Needs Review ثانویه، Print tertiary؛
- success page با نام و national ID masked/خوانا طبق تصمیم privacy و Back button بسیار بزرگ؛
- هیچ animation یا icon dependency جدید لازم نیست؛
- paper template با border/grid semantic و spacing متناسب با A4، نه تقلید pixel-perfect شکننده.

رنگ، font family و microcopy معماری را باز نمی‌کنند.

---

## 31. Remaining Owner Bindings

تصمیم‌های پیشین بسته شده‌اند و در معماری جاری چنین‌اند: پردازش عکس خارج از دامنه؛ شمارنده external-only با کلید کد ملی و تطبیق دقیق (همهٔ Entryهای هم‌کدملی همان شمارنده)؛ نهایی‌سازی گردش‌کار بومی/دستی و جدا از import؛ شمارهٔ موبایل با راه‌حل سادهٔ نگهداری‌شده (بدون قرارداد E.164 سفارشی)؛ DOB جلالی canonical و Gregorian فقط derived.

وضعیت bindingهای کسب‌وکاری/معنایی پس از تصمیم‌های Owner در ۲۰۲۶-۰۹-۰۷:

1. **Officer edit whitelist — CLOSED:** Officer label/nameهای انسانیِ code-backed و فیلدهای مجاز ثبت‌نام را از Gravity Flow native edit surface ویرایش می‌کند؛ system code/value canonical متناظر را می‌نویسد. raw code، workflow/system/audit fields مستقیماً editable نیستند.
2. **Finance semantics — CLOSED:** واحد canonical/display=ریال؛ همهٔ فیلدهای مالی release جاری optional و Registration-Officer-only/non-public؛ `discount_amount` default=`0` مجاز؛ `net_payable = tuition - discount` derived؛ `discount > tuition` = validation error و no save.
3. **Cheque/Scanner current-release binding — CLOSED:** فیلدهای manual مالی/چک optional هستند. هفت output صیاد در فرم Hidden و future-reserved می‌مانند؛ Scanner population برای release جاری deferred است و فقط با Owner reopen در فاز بعدی فعال می‌شود.
4. **Privacy/retention:** مدت و حذف/دسترسی photo، report card، cheque/financial PII، historical Entry، revision/audit و backup چیست؟ تا sign-off، فقط دادهٔ مصنوعی در staging مجاز است و production/UAT دارای PII block می‌ماند.

Bindingهای 1–3 `OWNER APPROVED / CLOSED` هستند و authoritative scaffold با synthetic data مجاز است. فقط privacy/retention پیش از ورود هر دادهٔ واقعی الزامی و باز می‌ماند.

---

## 32. Intentional Open Ambiguities

- exact Persian labels، colors، font و decorative spacing؛
- postal/foreign-national semantics و peripheral fields؛
- exact school count هر level تا دریافت normalized dataset؛
- exact image dimensions/quality target تا paper/screen sample test؛
- exact PHP/library version range تا environment inventory؛
- افزودن ارائهٔ اختیاری GravityView فقط اگر gap واقعی ارائه اثبات شود؛ مرجع عملیاتی همیشه بومی می‌ماند؛
- exact revision retention/export format تا privacy binding؛
- badge در Detail و sound notification؛
- downstream column names خارج از material contract؛
- print margin تا reference paper/printer test.
- انتخاب renderer نهایی هنوز باز است، اما candidate اول و Gate آن بسته شده: `Gravity PDF Free` طبق §15.5؛
- entitlement/install state واقعی GP Nested Forms و سازگاری child render/save/link در target Gravity Flow تا environment/POC `NOT_PROVEN` است؛
- ثبات Sayad v01 بین بانک‌ها/نسخه‌های QR `NOT_PROVEN` است؛
- exact PEC/PC-POS protocol و هر Windows utility/SQLite/clipboard design خارج از current release و `DEFERRED` است.
- انتخاب دقیق افزونهٔ سادهٔ ایرانی کد ملی/موبایل/جلالی تا اجرای واقعی باز است؛ معماری آن قفل است.

این موارد artifact-invariant هستند و parent architecture را باز نمی‌کنند.

---

## 33. Definition of Done

`ACTIVE_NORMATIVE` — این فهرست از معماری جاری Native-First بازساخته شده است. الزام‌های منسوخ (اثبات مسدودسازی تکراری، ویرایش عملیاتی GravityView، قفل GravityView، الزام Entry Notes، parity ممیزی API/سیستمی، ماتریس قدیمی دادهٔ ایرانی، اثبات پردازش عکس، مقایسهٔ انتخابگر و اثبات نوشتن مستقیم GFAPI) حذف شده‌اند.

Release فقط وقتی قابل پذیرش است که:

**قرارداد داده**
- قرارداد معنایی فیلدها `Owner Approved` و نگاشت پیاده‌سازی `Bound/Verified` باشد؛
- فرم جدید باشد و migration قدیمی نداشته باشد؛
- machine valueها دقیق باشند و وابستگی‌های Crosswalk در UI و سرور اعتبارسنجی شوند؛
- کد ملی به ASCII نرمال و اعتبارسنجی شود؛ تاریخ تولد جلالی معتبر باشد؛ شمارهٔ همراه با راه‌حل سادهٔ نگهداری‌شده اعتبارسنجی شود؛
- ارسال با کد ملی تکراری مجاز بماند و هیچ Entry حذف/مسدود نشود.
- قرارداد مالی Owner-approved باشد: ریال canonical/display، فیلدهای مالی optional و non-public/Registration-Officer-only، formula `net_payable=tuition-discount`، و `discount>tuition` با no-save validation رد شود؛
- contract چندچک cardinality=`1..N` و child-form mapping نهایی bind شود؛ هیچ relationship/database موازی ساخته نشود.

**گردش‌کار (بومی)**
- `V-01` پاس شود: ویرایش فیلد مجاز روی گام Approval بدون پیشروی، سپس Approve بومی با گام بعدی درست؛
- Needs Review فقط با فیلد `review_status` و دلیل آن نمایش/ذخیره شود؛
- هیچ status/step/branch/endpoint سفارشی وجود نداشته باشد.
- Officer فیلدهای مالی Owner-approved را فقط از Gravity Flow native edit surface و whitelist مربوط ویرایش کند؛ Windows/POS UI جایگزین baseline Officer editing نباشد.

**دسترسی**
- `V-02` پاس شود: عموم رد، مسئول ثبت‌نام عملیاتی، Admin اداری؛
- دستکاری URL/POST و nonce منقضی بدون افشای داده رد شود؛
- هیچ صفحهٔ عملیاتی از `allow_anonymous` یا `display_all` استفاده نکند و تنظیمات امنیت شورت‌کد محدود بماند؛
- Admin Actions برای مسئول ثبت‌نام فعال نباشد و تنظیمات امنیت شورت‌کد محدود بماند.

**فرم عمومی**
- `V-03` پاس شود: جست‌وجوی نام فارسی مدرسه روی موبایل و ذخیرهٔ درست `school_code`؛
- فیلد عکس دریافت و نگه‌داری شود (پردازش خارج از دامنه).
- Cheque manual entry در صورت استفاده از فیلدهای optional child form کار کند؛ Structured Scanner current-release requirement نیست و هفت فیلد Sayad Hidden/future-reserved باقی بمانند؛
- اگر current-release composition از GP Nested Forms استفاده می‌کند، bounded host POC child render/manual-edit/submit/link/reload و finance/print composition را PASS کند؛ entitlement/install state ثبت شده باشد؛ Scanner init/populate جزو PASS جاری نیست؛
- Sayad v01 source contract برای capability آینده می‌تواند حفظ/test شود، اما PASS آن release gate جاری SRWF نیست تا زمانی که Owner scan path را reopen کند.

**ممیزی**
- `V-04` پاس شود: ویرایش انسانی مهم ثبت شود و مشاهده/مقایسه/بازگردانی فقط برای Admin کار کند.

**تازگی و cache**
- `V-05` پاس شود: Live Refresh بومی کار کند و صفحات عملیاتی cache نامناسب نداشته باشند.

**شمارنده**
- `V-06` پاس شود: چند Entry با یک کد ملی همگی همان `registration_counter` را بگیرند؛ کد ملی دارای شمارنده درخواست‌کنندهٔ جدید نشود و Entry تکراری بعدی در sync بعدی همان شمارنده را دریافت کند؛ import گردش‌کار را جلو نبرد و نهایی‌سازی جدا/بومی/دستی بماند؛
- تعارض واقعی مبدأ (یک کد ملی با دو شمارندهٔ متفاوت در فایل) بدون نوشتن گزارش و در مبدأ اصلاح شود.

**عملیات**
- ماتریس سازگاری و Gate ارتقای vendor ثبت و یک تمرین regression روی staging اجرا شود؛
- runbook کش/بازگشت تست شود؛
- سیاست privacy/retention/دسترسی پیش از دادهٔ واقعی امضا شود؛
- بازبینی‌های انسانی §24.4 امضا شده باشند؛
- artifact انتشار، changelog و گزارش شواهد نسخه‌دار باشند.
- POS/PC-POS و online Sayad inquiry در release جاری dependency نباشند و هیچ Windows payment ledger/queue/state موازی به baseline وارد نشده باشد.

## 34. پروتکل handoff و نقد توسط مدل زبانی بعدی

### 34.1 مجموعهٔ اسناد پروژه

این سند مادر قرارداد معماری است، نه جایگزین همهٔ artifactهای اجرایی. repository پیشنهادی باید این topology کمینه را داشته باشد:

| Artifact | authority/کارکرد |
|---|---|
| `README.md` | entrypoint کوتاه، prerequisites، install و لینک به سند مادر |
| `docs/GATE_DASHBOARD.md` | projection یک‌صفحه‌ای از Gate/status/linkها؛ بدون authority مستقل یا تکرار contract |
| `docs/SRWF-MASTER.md` | همین baseline و نسخه‌های بعد؛ authority معماری |
| `docs/FIELD_CONTRACT.md` | schema/ID/Valueهای owner-approved؛ authority implementation mapping |
| `docs/adr/ADR-xxx.md` | فقط تصمیم‌های مادی و alternatives/evidence/rollback |
| `docs/TEST_MATRIX.md` | test IDs، environment، result و evidence link |
| `docs/RUNBOOK-OFFICER.md` | مسیر روزمره Officer به زبان ساده |
| `docs/RUNBOOK-IMPORT.md` | dry-run/commit/recovery importer برای Admin |
| `CHANGELOG.md` | release-level changes و migration notes |
| `composer.json` + quality configs | dev tooling؛ نه authority business |

تکرار یک contract در چند فایل ممنوع است؛ اسناد فرعی به owner document لینک می‌دهند. هر release باید plugin version، Master/Field Contract version، GF/Flow tested versions و known limitations را در release manifest ثبت کند.

فهرست زیر `NON_ENFORCING_GUIDANCE` است؛ برای review منضبط طراحی شده و ادعا نمی‌کند خواندن یا فهم مدل را ماشینی اثبات کرده است. مدل بعدی باید پیش از پیشنهاد تغییر:

1. نسخه، status و evidence cutoff این سند را بخواند؛
2. owner locks را از selected/proposed/not-proven جدا کند؛
3. سلسله‌مراتب بخش 3.1 را اعمال و از نگاشت انتخابی بخش 3.2 استفاده کند؛
4. اگر از ریپوی ترجیحات استفاده می‌کند، HEAD، projection source و freshness را بررسی کند و projection stale را authority نگیرد؛
5. برای ادعای current product capability منبع رسمی تازه بررسی کند؛
6. Matrix2/PersianGravity را در commit جدیدتر re-inspect کند؛
7. هر پیشنهاد را به requirement/failure مشخص وصل کند؛
8. Hard Gates را قبل از convenience اعمال کند؛
9. اگر تغییر مادی است، ADR با alternatives، evidence، migration و rollback بدهد؛
10. prose را runtime enforcement ننامد؛
11. فقدان proof را `NOT_PROVEN` بنامد، نه `CONTRADICTED`؛
12. اگر bounded test از بحث بیشتر informativeتر است، test را تعریف و comparison را متوقف کند.

`EL-002` در این baseline مجوز مسیر میان‌بُر نیست: `STRUCTURAL_SIMILARITY_CHECK` برای ادعای «governance به critical path تحویل تبدیل شده» فعلاً `UNRESOLVED` است. اگر بعداً evidence آن را `MATCH` کرد، فقط کوچک‌ترین bridge ایزوله و `NON_CANONICAL` می‌تواند با ADR و تأیید مالک بررسی شود؛ هیچ mandatory control، Field Contract یا production proof بی‌صدا حذف نمی‌شود.

### 34.2 مرز enforcement واقعی

پس از ایجاد repository، فقط موارد قابل‌مشاهده زیر candidate automation/CI هستند:

- lint/static analysis و test suite؛
- تطابق config Field/Step ID با Field Contract machine-readable؛
- release manifest شامل نسخهٔ Master/Field Contract و ترکیب تست‌شدهٔ WP/PHP/GF/Flow؛
- عدم تغییر vendor core و عدم وجود raw SQL روی tableهای GF/Flow؛
- حضور test evidence و result status برای Gateهای لازم؛
- source/evidence manifest با URL/commit/date ثبت‌شده.

قضاوت business، currentness منبع، فهم متن، مناسب‌بودن trade-off و sign-off مالک همچنان human/model review است. CI نباید status کاذب `ENFORCED` برای این امور تولید کند.

### قالب پیشنهادی Critique

```text
Claim/Decision ID:
Current statement:
Evidence state:
New primary evidence (URL/commit/date):
Failure or cost in current design:
Smallest proposed change:
Hard-gate impact:
Data/workflow migration impact:
Verification plan:
Rollback plan:
Owner decision required: yes/no
```

پیشنهادی که فقط «فناوری بیشتری دارد» یا benefit قابل سنجش ندارد رد می‌شود.

---

## 35. Decision Ledger

**بازنگری ۱٫۶٫۰:** ADRهای مبتنی بر مکانیزم‌های حذف‌شده — از جمله `ADR-003C` (Bounded POST برای Needs Review)، `ADR-026` (GravityView Entry Locking)، و ADRهای kernel/E.164/comparator ایرانی و چاپ اجباری — با بازنشانی Native-First (§0، D-01..D-17) **superseded** شده‌اند. رکوردهای تاریخی برای ردیابی حفظ شده‌اند اما حکم جاری، §0 است.

| ID | تصمیم | وضعیت | reopen trigger |
|---|---|---|---|
| ADR-001 | Parent = WP+GF+Flow | `OWNER_LOCKED` | contradiction فنی مستقیم جاری |
| ADR-002 | Architecture = Plugin-first Bounded Hybrid | `SELECTED` | Hard Gate failure حل‌ناشدنی درون parent architecture |
| ADR-003A | Needs Review = metadata overlay same Officer step؛ no transition/branch | `OWNER_LOCKED` | owner business change فقط؛ technical failure این invariant را خودکار باز نمی‌کند |
| ADR-003B | یک action ادراکی = valid edits + review metadata + authoritative response | `OWNER_LOCKED` | اگر BP-2 همهٔ مسیرهای supported را رد کرد: `SURFACE_BLOCKED` و owner trade-off |
| ADR-003C | BP-2 = Bounded Custom Validated POST؛ no custom Flow status/step | `METHOD_SELECTED/NOT_PROVEN IN TARGET` | فقط contradiction public API؛ test failure defect است نه reopen |
| ADR-004 | Administrative Fields + Entry Note، no custom table | `SELECTED` | concrete query/audit insufficiency |
| ADR-005 | Native Flow Inbox/Approval first؛ Browser Notification convenience | `SELECTED` | BP-1 failure یا vendor capability change |
| ADR-006 | Desk دو tab/queue؛ GravityView workflow inbox + Advanced Filter candidate | `SELECTED/NOT_PROVEN` | BP-1 failure یا owner demands simultaneous tables |
| ADR-007 | Baseline presentation = GravityView Route 0؛ Elementor Route A/B conditional | `OWNER_LOCKED/SELECTED` | BP-7 measurable benefit؛ Route B dynamic context proof |
| ADR-008 | GravityView owns Single/Edit Entry render/context؛ no CPT/ACF mirror | `SELECTED` | supported route contradiction |
| ADR-009 | Browser Print مسیر کمینه؛ Gravity PDF Core derived document مشروط به Persian/RTL/A4 POC | `HISTORICAL/SUPERSEDED_BY_ADR-043` | — |
| ADR-010 | school_code=0 non-blocking؛ historical direct-code restriction | `SUPERSEDED_BY_ADR-049` | — |
| ADR-011 | photo JPG/JPEG auto-optimize؛ 15–60KB target not hard gate؛ component by BP-4 | `OWNER_LOCKED/NOT_PROVEN DETAIL` | BP-4 result |
| ADR-012 | Jalali real-date validation only؛ no age/grade-age rule | `OWNER_LOCKED` | owner business change |
| ADR-013 | Conditional duplicate checks authoritative Flow state | `OWNER_LOCKED` | none without owner change |
| ADR-013B | Duplicate optimization فقط پس از BP-6؛ مشتق candidate-narrowing است نه authority | `SELECTED/NOT_PROVEN DETAIL` | BP-6 result |
| ADR-014 | Counter خارجی است؛ import late/dry-run، exact National-ID match، ambiguity stop، no generator/linker/GravityImport | `OWNER_CLARIFIED/SELECTED` | external input contract changes |
| ADR-015 | Automatic final completion only documented/tested path | `OWNER_LOCKED` | BP-5 result |
| ADR-016 | Matrix2 current gender conflict resolved | `CONFIRMED` | newer commit drift |
| ADR-017 | Print one-page guarantee فقط داخل approved Print Data Envelope | `SELECTED` | Field Contract/paper test evidence |
| ADR-018 | Vendor major upgrades پشت staging Compatibility Gate | `SELECTED` | supported lifecycle/owner operations change |
| ADR-019 | Counter commit consumes immutable plan و mutable preconditionها را revalidate می‌کند | `SELECTED` | BP-5/input contract result |
| ADR-020 | Privacy/retention production-data Gate است؛ synthetic staging مستقل مجاز | `SELECTED/OWNER POLICY PENDING` | owner policy/legal requirement |
| ADR-021 | GravityView primary Officer Desk/Single/Edit layer؛ Flow remains sole workflow authority | `SELECTED` | BP-1/2 hard-gate failure |
| ADR-022 | GravityView Entry Approval/Entry Tags parallel state ممنوع | `SELECTED` | none without owner architecture change |
| ADR-023 | BP-8 = GravityRevisions human audit + bounded per-path system bridge؛ API auto-coverage not relied upon | `METHOD_SELECTED/NOT_PROVEN IN TARGET` | human coverage/access failure یا vendor public API change |
| ADR-024 | Complete revision history Admin-only؛ Officer denied | `OWNER_LOCKED` | owner/legal change |
| ADR-025 | Paid plugin purchase only after necessity POC | `OWNER_LOCKED` | owner procurement change |
| ADR-026 | GravityView Entry Locking baseline؛ no custom lock manager | `SELECTED/NOT_PROVEN IN TARGET` | BP-2/21 failure |
| ADR-027 | Entry Notes = annotation/breadcrumb؛ Officer view/add و no delete/email؛ no state authority | `SELECTED/NOT_PROVEN IN TARGET` | P-23 یا owner policy change |
| ADR-028 | Save→Full Single Entry؛ Lightbox فقط quick-preview مشروط | `SELECTED/NOT_PROVEN IN TARGET` | P-23 measurable UX result |
| ADR-029 | Search-first GravityView Desk baseline؛ Table+Bulk/DataTables فقط requirement-triggered؛ Bulk Edit/Approval/Delete خارج v1 | `METHOD_SELECTED/NOT_PROVEN IN TARGET` | BP-1 material failure یا new operational requirement |
| ADR-030 | Enhanced Security embed defense است، نه authorization؛ creator ownership grant پروژه نیست | `SELECTED` | vendor security model change |
| ADR-031 | GravityKit MCP و Multiple Forms فرصت‌های deferred هستند، نه runtime foundation | `DEFERRED` | future scoped requirement + new POC |
| ADR-032 | BP-3 data model code/label/Other=0 بسته؛ A=Native، B=Chained، C=Populate+Advanced (preferred prototype)، D=custom failure-only؛ A minimum comparator | `METHOD_SELECTED/COMPONENT NOT_PROVEN` | BP-3 result یا dataset/source material change |
| ADR-033 | BP-9 = pure deterministic kernel + thin write-path adapters + separate Flow-aware duplicate policy؛ component by POC | `METHOD_SELECTED/COMPONENT NOT_PROVEN` | source/runtime contradiction |
| ADR-034 | DOB Jalali `YYYY/MM/DD` canonical و non-native-Date؛ Gregorian فقط derived نیازمحور | `OWNER_LOCKED/METHOD_SELECTED` | downstream material requirement + impact review |
| ADR-035 | Mobile canonical storage = E.164؛ local/SMS representation derived | `SELECTED/COMPONENT NOT_PROVEN` | downstream/provider material incompatibility |
| ADR-036 | WP All Import Counter candidate است؛ no delete-missing/update-all و no selection پیش از match/Flow/preservation POC | `SELECTED COMPARATOR/NOT_PROVEN` | BP-5/P-27 result |
| ADR-037 | Uncanny Automator فقط external/cross-plugin layer؛ Gravity Flow sole business workflow engine | `SELECTED/DEFERRED` | real integration requirement + P-29 |
| ADR-038 | Dynamic GF/Flow/GV routes no-cache baseline؛ helper plugin فقط اگر exclusion infrastructure fail کند | `SELECTED` | P-30/environment evidence |
| ADR-039 | Entry Blocks، Advanced Save/Continue، Partial Entries، User Registration و broad automation deferred تا requirement | `DEFERRED` | explicit scoped requirement + POC |
| ADR-040 | Field Contract دو Gate دارد: Semantic قبل scaffold و Implementation Mapping بعد scaffold | `METHOD_SELECTED` | none without delivery-process contradiction |
| ADR-043 | D-17 print gate = `Gravity PDF Free` + SRWF-owned print layer؛ no paid Gravity PDF template/extension؛ no custom PDF engine؛ no parallel Browser Print production path؛ Officer normal path must avoid manual download; final renderer only after POC PASS | `OWNER_LOCKED/POC_GATED/NOT_PROVEN` | POC FAIL، material document requirement change، یا Owner change |
| ADR-044 | Current release finance in GF/Flow; POS/PC-POS و online Sayad deferred | `REFINED_BY_ADR-050` | — |
| ADR-045 | Multi-cheque cardinality=`1..N`; host منتخب = GP Nested Forms؛ هر چک child GF Entry؛ Parent-Child Forms فقط fallback بعد از bounded FAIL؛ no custom relationship state | `OWNER_LOCKED / POC_NOT_PROVEN` | entitlement unavailable on acceptable terms یا host POC FAIL |
| ADR-046 | PersianGravity Structured Scanner = generic host-agnostic non-persistent capability | `CAPABILITY_RETAINED / CURRENT_USE_SUPERSEDED_BY_ADR-048` | future scanner phase or technical contradiction |
| ADR-047 | Sayad v01 = seven ordered outputs + atomic population؛ stronger bank/version validation forbidden without broader evidence | `CONTRACT_RETAINED / FUTURE_PHASE / CROSS_BANK_NOT_PROVEN` | Owner reopens scanner or contradictory sample |
| ADR-048 | SRWF Scanner path در release جاری deferred؛ هفت Sayad output به‌صورت Hidden future-reserved باقی می‌مانند و هیچ scanner population جاری وجود ندارد | `OWNER_LOCKED` | Owner explicitly reopens scanner-based financial/cheque entry |
| ADR-049 | Officer نام/گزینهٔ انسانیِ school/group/status را ویرایش می‌کند و سیستم code/value canonical متناظر را می‌نویسد؛ raw codes مستقیماً editable نیستند | `OWNER_LOCKED` | Owner policy change یا runtime contradiction in canonical mapping |
| ADR-050 | Finance current release: Rial canonical/display؛ همهٔ financial/manual-cheque fields optional و Registration-Officer-only/non-public؛ discount default 0 مجاز؛ net=tuition-discount؛ discount>tuition => validation error/no save | `OWNER_LOCKED / SFC_CLOSED` | Owner finance policy change |
| ADR-041 | Derived Operational Status فقط UI projection و غیرذخیره‌شده است | `SELECTED` | operator UX requirement change |
| ADR-042 | Photo optimization failure: original سالم + Admin flag؛ unsafe/corrupt reject | `SELECTED` | storage/security requirement change |

---

## 36. منابع اصلی

### Gravity Forms

- [Gravity Forms Changelog](https://docs.gravityforms.com/gravityforms-change-log/)
- [Common Field Settings](https://docs.gravityforms.com/common-field-settings/)
- [Field Object](https://docs.gravityforms.com/field-object/)
- [Entry Object](https://docs.gravityforms.com/entry-object/)
- [Updating Entries with GFAPI](https://docs.gravityforms.com/updating-entries-with-the-gfapi/)
- [Managing Notes with GFAPI](https://docs.gravityforms.com/managing-notes-with-the-gfapi/)
- [Searching and Getting Entries with GFAPI](https://docs.gravityforms.com/searching-and-getting-entries-with-the-gfapi/)
- [Drop Down Field](https://docs.gravityforms.com/drop-down-field/)
- [Date Field](https://docs.gravityforms.com/date/)
- [GF_Field_Date storage contract](https://docs.gravityforms.com/gf_field_date/)
- [Phone Field](https://docs.gravityforms.com/phone/)
- [Chained Selects — When and Why](https://docs.gravityforms.com/when-and-why-to-use-chained-selects/)
- [Creating Chained Selects](https://docs.gravityforms.com/creating-chained-selects/)
- [Checks Before Upgrading to Gravity Forms 3.0](https://docs.gravityforms.com/checks-before-upgrading-to-gravity-forms-3-0/)
- [Gravity Forms Save & Continue](https://docs.gravityforms.com/save-continue-gravity-forms/)
- [Partial Entries](https://www.gravityforms.com/feature/partial-entries/)
- [Repeater Fields Beta](https://docs.gravityforms.com/repeater-fields/)
- [Conversational Forms](https://www.gravityforms.com/feature/conversational-forms/)
- [Signature](https://www.gravityforms.com/feature/signature/)
- [Webhooks](https://www.gravityforms.com/feature/webhooks/)

### Gravity Flow

- [Changelog](https://docs.gravityflow.io/changelog/)
- [Inbox Page](https://docs.gravityflow.io/the-inbox-page/)
- [Shortcodes](https://docs.gravityflow.io/shortcodes/)
- [Blocks](https://docs.gravityflow.io/blocks/)
- [Entry Details Page](https://docs.gravityflow.io/the-entry-details-page/)
- [Approval Step Type](https://docs.gravityflow.io/approval-step-type/)
- [`gravityflow_above_approval_buttons`](https://docs.gravityflow.io/gravityflow_above_approval_buttons/)
- [`gravityflow_approval_assignee_status_types`](https://docs.gravityflow.io/gravityflow_approval_assignee_status_types/)
- [`gravityflow_step_status_evaluation_approval`](https://docs.gravityflow.io/gravityflow_step_status_evaluation_approval/)
- [`gravityflow_validation_approval`](https://docs.gravityflow.io/gravityflow_validation_approval/)
- [Permissions](https://docs.gravityflow.io/permissions/)
- [Activity Log](https://docs.gravityflow.io/activity-log/)
- [Workflow Orchestration API](https://docs.gravityflow.io/the-workflow-orchestration-api/)
- [Process Current Step — REST API V2](https://docs.gravityflow.io/process-the-current-step-with-rest-api-v2/)
- [Incoming Webhook Step](https://docs.gravityflow.io/incoming-webhook-workflow-step/)
- [Outgoing Webhook Step](https://docs.gravityflow.io/outgoing-webhook-step-type/)
- [User Registration Add-On with Gravity Flow](https://docs.gravityflow.io/user-registration-add-on/)

### WordPress/PHP

- [WordPress Plugin Handbook](https://developer.wordpress.org/plugins/)
- [Checking User Capabilities](https://developer.wordpress.org/plugins/security/checking-user-capabilities/)
- [Nonces](https://developer.wordpress.org/plugins/security/nonces/)
- [PHP Coding Standards](https://developer.wordpress.org/coding-standards/wordpress-coding-standards/php/)
- [`wp_get_image_editor()`](https://developer.wordpress.org/reference/functions/wp_get_image_editor/)

### Candidate vendors

- [GP Advanced Select](https://gravitywiz.com/documentation/gravity-forms-advanced-select/)
- [GP Populate Anything](https://gravitywiz.com/documentation/gravity-forms-populate-anything/)
- [GP Advanced Conditional Logic](https://gravitywiz.com/documentation/gravity-forms-advanced-conditional-logic/)
- [GP Limit Submissions](https://gravitywiz.com/documentation/gravity-forms-limit-submissions/)
- [GP Advanced Phone Field](https://gravitywiz.com/documentation/gravity-forms-advanced-phone-field/)
- [GP File Renamer](https://gravitywiz.com/documentation/gravity-forms-file-renamer/)
- [GP Preview Submission](https://gravitywiz.com/documentation/gravity-forms-preview-submission/)
- [GP Advanced Save & Continue](https://gravitywiz.com/documentation/gravity-forms-advanced-save-and-continue/)
- [GP Unique ID](https://gravitywiz.com/documentation/gravity-forms-unique-id/)
- [GP Notification Scheduler](https://gravitywiz.com/documentation/gravity-forms-notification-scheduler/)
- [GP Read Only](https://gravitywiz.com/documentation/gravity-forms-read-only/)
- [GP Copy Cat](https://gravitywiz.com/documentation/gravity-forms-copy-cat/)
- [GP Nested Forms](https://gravitywiz.com/documentation/gravity-forms-nested-forms/)
- [GP Easy Passthrough](https://gravitywiz.com/documentation/gravity-forms-easy-passthrough/)
- [GP File Upload Pro](https://gravitywiz.com/documentation/gravity-forms-file-upload-pro/)
- [GravityView Page Builder Support](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/page-builder-support/)
- [GravityView Changelog](https://www.gravitykit.com/products/gravityview/changelog/)
- [GravityRevisions Changelog](https://www.gravitykit.com/products/gravityrevisions/changelog/)
- [GravityRevisions Restore/API logging note](https://www.gravitykit.com/docs/gravityrevisions/gravity-foms-revert-changes-to-entry/)
- [GravityRevisions front-end display](https://www.gravitykit.com/docs/gravityrevisions/display-entry-revisions/)
- [GravityRevisions diff ignored keys](https://www.gravitykit.com/docs/gravityrevisions/modify-what-fields-are-shown/)
- [GravityView Blocks: View, Entry and Entry Field](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/embedding-views-entries-and-fields-using-blocks/)
- [GravityView Layout Builder](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/the-layout-builder-when-and-how-to-use-it/)
- [GravityView Custom Content](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/using-the-custom-content-field/)
- [GravityView Advanced Elementor Widget](https://www.gravitykit.com/docs/gravityview-pro/advanced-elementor-widget/getting-started-with-advanced-elementor-widget/)
- [GravityView Entry Locking](https://www.gravitykit.com/docs/gravityview/edit-entry/entry-locking/)
- [GravityView Changelog](https://www.gravitykit.com/products/gravityview/changelog/)
- [GravityView Entry Notes](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/the-entry-notes-field/)
- [GravityView Redirect After Editing](https://www.gravitykit.com/docs/gravityview/edit-entry/view-settings-redirect-after-editing/)
- [GravityView Frontend Bulk Actions](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/frontend-bulk-actions/)
- [GravityView DataTables Processing](https://www.gravitykit.com/docs/gravityview-pro/datatables/client-side-processing/)
- [GravityView Lightbox Single/Edit Entry](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/opening-and-editing-entry-details-in-a-lightbox-modal-popup/)
- [GravityView Capabilities](https://www.gravitykit.com/docs/gravityview/roles-and-capabilities/gravityview-capabilities/)
- [GravityView Enhanced Security](https://www.gravitykit.com/docs/gravityview/getting-started-gravityview/enable-enhanced-security-the-secret-attribute-for-shortcodes/)
- [GravityKit MCP](https://www.gravitykit.com/docs/gravityview/advanced/build-views-with-ai/)
- [GravityView Multiple Forms](https://www.gravitykit.com/docs/gravityview-pro/multiple-forms/getting-started-with-multiple-forms/)
- [Gravity Flow + GravityView Integration](https://docs.gravityflow.io/gravityview-integration/)
- [GravityRevisions Marketplace Listing](https://www.gravityforms.com/add-ons/entry-revisions/)
- [GravityRevisions logging/restore behavior](https://www.gravitykit.com/docs/gravityrevisions/gravity-foms-revert-changes-to-entry/)
- [GravityImport](https://www.gravitykit.com/products/gravityimport/)
- [WP All Import — Gravity Forms Entries](https://www.wpallimport.com/documentation/how-to-import-gravity-forms-entries/)
- [WP All Import — Gravity Forms Migration/Selective Update](https://www.wpallimport.com/documentation/how-to-migrate-gravity-forms-entries/)
- [WP All Import — Import Types/Match Existing](https://www.wpallimport.com/documentation/import-types/)
- [Gravity PDF — Setup/RTL/Paper](https://docs.gravitypdf.com/users/setup-pdf)
- [Gravity PDF — Custom Fonts](https://docs.gravitypdf.com/users/custom-fonts/)
- [Gravity PDF — Supported HTML/CSS](https://docs.gravitypdf.com/developers/pdf-features/supported-html-and-css)
- [Gravity PDF — Gravity Flow Support](https://docs.gravitypdf.com/users/gravity-flow-support)
- [Hamyar Gravity](https://www.zhaket.com/web/hamyar-gravity-plugin)
- [GF IR Mobile](https://wordpress.org/plugins/gf-ir-mobile-add-on/)
- [Parsi Date](https://wordpress.org/plugins/wp-parsidate/)
- [Uncanny Automator — Gravity Forms Integration](https://automatorplugin.com/integration/gravity-forms/)
- [Uncanny Automator — Logs](https://automatorplugin.com/knowledge-base/using-automator-logs/)
- [Uncanny Automator — Pro Changelog](https://automatorplugin.com/plugin-changelog/uncanny-automator-pro/)
- [Elementor 4.0 announcement](https://elementor.com/blog/editor-40-atomic-forms-pro-interactions/)
- [Elementor Editor V4 coexistence](https://elementor.com/help/get-started-with-the-elementor-editor-v4/)
- [Elementor Shortcode Widget](https://elementor.com/help/shortcode-widget/)

### Repositories

- [Matrix2 commit `24a13e9…`](https://github.com/rezahh107/Matrix2/commit/24a13e928808715953b3c1260b6ac7271c7dfe31)
- [PersianGravity commit `83f2cbf…`](https://github.com/rezahh107/PersianGravity/commit/83f2cbfb5425984ac6545a6075497606efd81508)
- [Personal Preference Decision Model commit `0c6a069…`](https://github.com/rezahh107/Personal-Preference-Decision-Model/commit/0c6a069113a545fdaca89465d80044443cd61853)
- [Personal Preference Decision Model — `AGENT_ENTRYPOINT.md` @ `0c6a069…`](https://github.com/rezahh107/Personal-Preference-Decision-Model/blob/0c6a069113a545fdaca89465d80044443cd61853/AGENT_ENTRYPOINT.md)
- [Personal Preference Decision Model — `repository.manifest.yaml` @ `0c6a069…`](https://github.com/rezahh107/Personal-Preference-Decision-Model/blob/0c6a069113a545fdaca89465d80044443cd61853/repository.manifest.yaml)

---

## 37. Changelog
### 1.9.0 — 2026-09-07
- Owner-approved Semantic Field Contract bindings 1–3 are now closed; authoritative scaffold is authorized with synthetic data only. Privacy/retention still blocks real PII.
- Current-release Structured Scanner path is deferred. The generic PersianGravity capability remains available, but all seven Sayad outputs are retained only as Hidden future-reserved fields and are not populated now.
- Officer edits human-readable code-backed school/group/status choices; the system writes the corresponding canonical code/value. Raw technical codes remain hidden from direct Officer editing.
- Finance contract closed/refined: canonical/display unit = Rial; all current financial/manual-cheque fields are optional and non-public/Registration-Officer-only; `discount_amount` may default to 0; `net_payable_amount = tuition_amount - discount_amount`; discount greater than tuition fails validation and is not saved.
- GP Nested Forms remains the selected multi-cheque host pending its own bounded runtime proof, but Scanner initialization/population is removed from current-release host POC criteria.
- No runtime validation result is promoted by this documentation sync; Environment Inventory remains PARTIAL/OWNER_ACCEPTED_FOR_PROGRESS and V-01..V-06 remain unexecuted until actually run.


### 1.8.1 — 2026-09-06

- Documentation-consistency patch only; no architecture, Owner Lock, Gate, candidate, or runtime evidence changed.
- §2.2 corrected: primary Officer operational surface is native Gravity Flow Inbox + Entry Details; GravityView remains optional read-only presentation only.
- §5 item 9 corrected: D-17 is `POC_GATED / NOT_PROVEN` with `Gravity PDF Free` + SRWF print layer as first candidate; Browser Print is not a parallel production route.
- `Exact Next Action` corrected to the current Stage-0 gate and already-authorized independent Scanner source POC; the stale `Accept/Amend v1.6.4` instruction was removed.
- Version references for the active baseline were advanced from `1.8.0` to `1.8.1`; historical changelog entries and product version facts were not rewritten.

### 1.8.0 — 2026-09-06

- Owner-approved finance/cheque decisions from the 2026-09-05/06 SRWF consultation were synchronized from `SRWF_RUNTIME_STATE` Decision History into the Master; this is documentation closure, not implementation proof.
- Current release finance contract added: Officer-entered tuition, discount, discount title, derived net payable; canonical storage remains Gravity Forms and editing remains Gravity Flow native.
- POS/PC-POS integration and online Sayad inquiry are explicitly deferred from the current release.
- Multi-cheque cardinality is `1..N`; `GP Nested Forms` is the selected host pending entitlement/runtime POC, with Parent-Child Forms only as fallback after bounded failure; custom relationship state remains prohibited.
- `PersianGravity Structured Scanner` is bound as a generic host-agnostic, non-persistent controller mapping profile outputs to ordinary GF fields; raw QR persistence and SRWF-specific relationship/workflow logic are prohibited.
- Sayad v01 POC contract is seven ordered outputs with atomic population; cross-bank/version stability remains `NOT_PROVEN`.
- Semantic Field Contract, Risk Register, Minimality Challenge, Definition of Done, Remaining Owner Bindings and Decision Ledger were updated accordingly.
- D-17 decision from 1.7.0 is unchanged: `Gravity PDF Free` remains first print POC candidate and renderer is still `NOT_PROVEN`.
- No runtime evidence was promoted; Structured Scanner/Nested Forms/finance composition remain unexecuted in the target environment.

### 1.7.0 — 2026-09-06

- Owner decision from the 2026-09-06 print/localization consultation is incorporated as a **refinement of D-17**, not a claim of implementation or POC success.
- `Gravity PDF Free` is the first and only candidate in the first D-17 POC round; commercial Gravity PDF templates/extensions are excluded from the print baseline.
- SRWF owns only print-specific presentation logic (dossier template, field mapping, A4/page breaks, permissions, filename, print action). Building a PDF engine or generic PDF framework is out of scope.
- D-17 remains `POC_GATED / NOT_PROVEN`. PASS requires Persian/RTL rendering, ZWNJ preservation, leading-zero National ID, Jalali date, table/amount rendering, stable A4/page breaks, searchable/copyable logical Unicode, and Officer print UX without manual file-download as the normal path.
- Browser Print is not retained as a parallel production renderer. If the Gravity PDF Free POC fails, D-17 remains open and the next renderer requires Owner re-adjudication.
- A dedicated `SRWF Print` plugin is **not selected yet**; a thin plugin is allowed only if a real requirement remains beyond what a custom Gravity PDF Free template/integration can satisfy.
- No runtime evidence is promoted: POC status is still `UNEXECUTED/NOT_PROVEN`.

### 1.6.4 — 2026-08-24

- انتشار سخت‌سازی نهایی؛ بدون تغییر معماری و بدون تصمیم پروژه‌ای جدید.
- دانش بومی گراویتی‌فلو گسترش یافت: صفحهٔ Status (فیلتر/مرتب‌سازی/تعداد ردیف/خروجی CSV)، تنظیمات Workflow Start و Complete (شرط سطح گردش‌کار، پیام‌های در انتظار/تکمیل، فیلدهای نمایشی ارسال‌کننده)، فهرست کامل نوع گام‌های هسته، و انواع فیلدهای Workflow.
- §18.0 افزوده شد: خروجی CSV بومی صفحهٔ Status به‌عنوان مسیر بومی مغایرت‌گیری شمارنده.
- §15.1.1 افزوده شد: نمایش وضعیت برای ارسال‌کننده به‌صورت بومی پیکربندی می‌شود.
- تأیید مجدد مرز بومی: هیچ گام سفارشی و هیچ اتکای عملیاتی به GravityView لازم نیست.
- وضعیت اجرا تغییر نکرد: `execution_record_count = 0`، `V-01..V-06` همگی `UNEXECUTED`، `BLK-ENV-001` فعال، Builder همچنان `NOT_BUILDER_READY`.

### 1.6.3 — 2026-08-24

- انتشار سخت‌سازی نهایی پیش از یکپارچه‌سازی SRWF Advisor؛ بدون تغییر معماری و بدون تصمیم پروژه‌ای جدید.
- مرز بومی گراویتی‌فلو با شواهد رسمی تکمیل شد: تنظیمات بلاک/شورت‌کد برای نمای فهرست و نمای جزئیات، اقدام‌های گروهی صفحهٔ وضعیت (چاپ، شروع مجدد گردش‌کار، ارسال به گام) و مرجع کامل ویژگی‌های شورت‌کد.
- یافتهٔ امنیتی: ویژگی‌های `allow_anonymous` و `display_all` طبق مستندات رسمی بررسی capability را دور می‌زنند؛ `V-02` و Definition of Done اکنون صریحاً خاموش‌بودن آن‌ها را الزام می‌کنند.
- نتیجهٔ مرز بومی: نیازهای عملیاتی و ارائه‌ای مسئول ثبت‌نام با قابلیت بومی برآورده می‌شوند؛ هیچ Desk سفارشی و هیچ اتکای عملیاتی به GravityView توجیه ندارد.
- هم‌راستا با بستهٔ سازه‌پذیری v0.6.6 (اعتبارسنجی کامل JSON Schema، جداسازی سطح بازیابی جاری از ردّ تاریخی).
- وضعیت اجرا تغییر نکرد: `execution_record_count = 0`، `V-01..V-06` همگی `UNEXECUTED`، `BLK-ENV-001` فعال، Builder همچنان `NOT_BUILDER_READY`.

### 1.6.2 — 2026-08-24

- بستن هویت سند: front matter که هنوز `1.5.0` و `PLUGIN_FIRST_BOUNDED_HYBRID` بود به `1.6.2` و `NATIVE_FIRST_D01_D17_CLOSED` اصلاح شد؛ تاریخ به‌روزرسانی و برش شواهد هم‌راستا شد.
- §18 (شمارنده) بازنویسی شد: حذف الزام importer سفارشی (Reader/Validator/Planner/Committer، plan تغییرناپذیر، `plan_id`/`plan_hash`) و حذف قاعدهٔ منسوخ «چند Entry برای یک کد ملی = ابهام → تصمیم Admin». معناشناسی جاری صریح شد: همهٔ Entryهای هم‌کدملی همان شمارنده را می‌گیرند و کد ملی دارای شمارنده درخواست‌کنندهٔ جدید نیست.
- §18.8 از «comparator» به «پیکربندی مرجع منتخب» تبدیل شد؛ WP All Import به‌عنوان مرجع sync تثبیت شد.
- Definition of Done برای شمارنده به معناشناسی تکراری‌ها دقیق شد.
- هم‌راستا با بستهٔ سازه‌پذیری v0.6.5 (بازتصویر کامل گراف دانش: ECRها، رکوردهای سازه‌پذیری، شاخص‌ها و سطوح ترکیبی).
- وضعیت اجرا تغییر نکرد: `execution_record_count = 0`، `V-01..V-06` همگی `UNEXECUTED`، `BLK-ENV-001` فعال، Builder همچنان `NOT_BUILDER_READY`.


### 1.6.1 — 2026-08-24

- انتشار اصلاحی/دانشی: **بدون تغییر معماری** و بدون تصمیم پروژه‌ای جدید فراتر از D-01..D-17.
- FIX-01: بخش‌های فعالی که هنوز الزام‌های نسخهٔ ۱٫۵٫۰ را نگه داشته بودند **بازنویسی مستقیم** شدند (به‌جای یادداشت supersession): داشبورد کنترل، §1، §5، §6، §7، §10، §11، §12، §15، §16، §18، §21، §22، §23، §24، §26، §27، §28، §31، §32، §33 و Exact Next Action.
- قرارداد طبقه‌بندی بخش‌ها افزوده شد؛ §25 صریحاً `HISTORICAL` علامت خورد و ردیف‌های آزمون `P-01..P-30` به بخش تاریخی §24.5 منتقل شدند.
- Definition of Done از معماری جاری بازساخته شد (حذف الزام‌های منسوخ duplicate/GravityView edit/locking/Entry Notes/parity ممیزی/عکس/comparator/GFAPI).
- FIX-03: شناسهٔ probe برای V-03 و V-04 به دلیل تغییر مادی معنا عوض شد: `PRB-NF-V03-SCHOOL-SEARCH` و `PRB-NF-V04-HUMAN-REVISION`.
- هم‌راستا با بستهٔ سازه‌پذیری v0.6.4 (موج دوم غنی‌سازی پیکربندی بومی و دفتر پوشش شفاف).
- وضعیت اجرا تغییر نکرد: `execution_record_count = 0`، `V-01..V-06` همگی `UNEXECUTED`، `BLK-ENV-001` فعال، Builder همچنان `NOT_BUILDER_READY`.

### 1.6.0 — 2026-08-23

- موج ساده‌سازی مصوب مالک `NATIVE_FIRST`؛ افزودن بخش حاکم §0 و ماتریس تغییر D-01..D-17.
- Needs Review به فیلد Entry + دلیل ساده شد (D-01)؛ صندوق عملیاتی واحد = Gravity Flow Inbox بومی (D-02)؛ مسئول ثبت‌نام واحد (D-03).
- ویرایش Officer و Approval به مسیر بومی Gravity Flow منتقل شد (D-04/D-05)؛ حذف notification/freshness/concurrency سفارشی (D-06/D-07/D-08).
- انتخابگر مدرسه/کد ملی/جلالی/موبایل به راه‌حل‌های بومی/نگهداری‌شدهٔ ساده کاهش یافت (D-09/D-11)؛ پردازش عکس خارج از دامنه (D-12).
- حذف کامل مسدودسازی تکراری (D-10)؛ ممیزی فقط انسانی GravityRevisions و حل BLK-AUD-001 (D-13)؛ حذف الزام GFAPI update (D-14).
- WP All Import مرجع sync شمارنده بر کلید کد ملی و بدون هدایت Flow (D-15/D-16)؛ renderer چاپ معوق (D-17).
- BP-2/6/7/8/9/10 بازنشسته/معوق؛ مجموعهٔ راستی‌آزمایی جدید V-01..V-06.
- هم‌راستا با بستهٔ سازه‌پذیری v0.6.3 (۲۶ فکت پیکربندی مستند جدید از مستندات رسمی؛ reprojection report).
### 1.5.0 — 2026-08-22

- وضعیت سند به `IMPLEMENTATION_READY_CONTRACT_BASELINE` ارتقا یافت؛ ورود مرحله‌ای به Stage 0، Semantic Contract، scaffold و critical POC مجاز شد، بدون ادعای اجرا یا production readiness؛
- Field Contract به Semantic Contract پیش از scaffold و Implementation Mapping پس از scaffold تفکیک شد تا circular dependency شناسه‌های GF/Flow/GV حذف شود؛
- BP-2 به `METHOD_SELECTED` ارتقا یافت: Bounded Custom Validated POST با policy ثابت، whitelist Input، nonce/authorization، idempotency، stale-write detection، یک material update، reread/postcondition و PRG؛ custom Flow status/step/branch رد شد؛
- BP-3 data model قفل شد: `school_code` Value، `school_name` Label و `0` Other؛ نام‌گذاری Candidateها یکدست شد: A Native، B Chained، C Populate+Advanced (preferred mobile-search prototype) و D custom failure-only؛ A minimum comparator است؛
- Search-first GravityView Desk، Save→Full Single Entry و Route 0 baseline شدند؛ Bulk/DataTables/Lightbox/Elementor فقط requirement-triggered ماندند؛ Derived Operational Status غیرذخیره‌شده برای UI اضافه شد؛
- Counter boundary با توضیح مالک اصلاح شد: counter فقط در Matrix/سامانه ثبت خارجی تولید می‌شود؛ WordPress فقط با National ID canonical import می‌کند. canonical-link/Linked Duplicate/Primary subsystem حذف و exact-one-eligible/ambiguity-stop جایگزین شد؛
- BP-8 architecture بسته شد: GravityRevisions برای human writes و bridge محدود per-path برای system/API gap؛ تعارض رسمی changelog `1.3.0` با Restore docs ثبت و اتکا به API auto-revision بدون proof ممنوع شد؛ Restore allowlist و Officer denial سخت شد؛
- BP-9 architecture بسته شد: pure deterministic kernel، thin adapters و Flow-aware duplicate policy جدا؛ National ID ASCII/checksum/leading-zero/current-entry exclusion، Mobile canonical E.164 و name source/search normalization separation ثبت شد؛
- DOB Jalali canonical صریحاً از native GF Date جدا شد؛ Gregorian فقط derived نیازمحور باقی ماند؛
- photo failure policy بسته شد: original سالم و داخل hard limits حفظ + Admin flag؛ corrupt/spoofed/unsafe reject؛
- critical path کوتاه شد: BP-1/2/3/9 و minimal BP-8 زودهنگام؛ BP-4/6/7/10 و BP-5 درست پیش از Stage مصرف‌کننده؛
- GravityView `3.3.2` با changelog رسمی ۲۰ اوت ۲۰۲۶ تأیید و fix مرتبط با Edit Entry/Hidden Field/Conditional Logic/dynamic choices وارد evidence baseline شد؛ compatibility کامل selector همچنان BP-3 است و نسخهٔ target فقط از Stage 0 manifest authority می‌گیرد؛
- Open Owner Decisions از هفت مورد به دو binding واقعی کاهش یافت: Officer edit whitelist و privacy/retention پیش از داده واقعی.

### 1.4.0 — 2026-08-22

- parent architecture و authorityهای GF/Flow/GV حفظ شدند؛ هیچ CPT/ACF mirror یا workflow engine دوم وارد baseline نشد؛
- owner lock چاپ اصلاح شد: Browser Print مسیر کمینه ماند و Gravity PDF Core به‌عنوان derived document مشروط به POC فارسی/RTL/A4 پذیرفته شد؛ screen و PDF دو renderer از همان Entry تعریف شدند؛
- BP-10 و P-28 برای فونت فارسی، bidi/RTL، digits، photo، long text، background، viewers و printer واقعی اضافه شدند؛ extensionهای PDF همچنان deferred ماندند؛
- BP-3 از native-vs-Advanced Select به comparator سه‌مسیرهٔ native، Chained Selects و Populate Anything+Advanced Select ارتقا یافت؛ Flow/GV edit و data maintenance وارد معیار شدند؛
- BP-9 و P-24/P-25/P-26 برای National ID، mobile و Jalali در پنج write path اضافه شدند؛ Hamyar، GF3/GP/GF-IR و Parsi Date بدون overclaim طبقه‌بندی شدند؛
- DOB Jalali canonical owner lock حفظ شد؛ Gregorian فقط derived candidate و E.164 فقط mobile recommendation تا تأیید Field Contract ثبت شد؛
- WP All Import به BP-5/P-27 به‌عنوان Counter candidate اضافه شد؛ محدودیت same-import selective update، unknown matching، Flow preservation، no rollback و guardrailهای no-delete/update-whitelist/snapshot ثبت شدند؛ GravityImport همچنان رد شد؛
- Uncanny Automator فقط به‌عنوان deferred cross-plugin/external layer ثبت و مالکیت هر business workflow state، direct SQL، broad GF writes و recursive recipe ممنوع شد؛ Gravity-native webhook مقدم ماند؛
- policy cache به همهٔ public/Flow/GV dynamic routes گسترش یافت؛ Fresh Forms/Cache Buster فقط fallback عملیاتی شدند؛
- Capability Inventory با Advanced Conditional Logic، Limit Submissions، File Renamer/Media Library، Entry Blocks و ابزارهای styling/cache تکمیل شد، بدون افزایش baseline dependency؛
- Field Contract با `canonical_storage`، `derived_representations` و `write_paths` گسترش یافت؛ Riskهای R-26 تا R-32، ADR-032 تا ADR-039 و Definition of Done هم‌راستا شدند.

### 1.3.0 — 2026-08-21

- GravityView baseline از `3.3.1` به `3.3.2` ارتقا یافت و regression مربوط به Edit Entry/Hidden Field/Conditional Logic به Compatibility Gate اضافه شد؛
- قرارداد سه‌لایهٔ `Gravity Flow state`، `review_status` و `Entry Notes` ثبت شد؛ Notes فقط annotation/breadcrumb است و Officer فقط view/add دارد؛
- مسیر پیش‌فرض پس از Edit برابر Save→Full Single Entry و Lightbox فقط quick-preview مشروط شد؛
- Officer list به comparator صریح Table+Bulk، DataTables AJAX و Search-first تبدیل و فرض جمع‌پذیری DataTables/Bulk Actions حذف شد؛
- Bulk Edit برای فرم دارای Conditional Logic و GravityView Bulk Approval/Delete برای Officer از v1 خارج شد؛ Export/ZIP فقط مشروط به BP-1 باقی ماند؛
- محدودیت DataTables AJAX برای export current page و الزامات admin-ajax/firewall/cache ثبت شد؛
- Role/Ownership Matrix با creator غیرassignee، direct GET/POST و Entry Notes permissions افزوده شد؛ `gravityview_edit_entries` به‌عنوان edit guard عمومی فرض نمی‌شود؛
- Enhanced Security به‌عنوان embed defense از per-entry authorization جدا شد؛
- P-22/P-23، Riskهای R-21 تا R-25، ADR-027 تا ADR-031، Definition of Done، Minimality Challenge و منابع رسمی هم‌راستا شدند؛
- GravityKit MCP و Multiple Forms به‌عنوان فرصت‌های deferred و خارج از runtime foundation ثبت شدند؛ parent architecture و SSOTها بدون تغییر ماندند.

### 1.2.0 — 2026-08-21

- معماری از companion-first به `PLUGIN_FIRST_BOUNDED_HYBRID` اصلاح شد؛ GravityView کاندید اصلی Officer Desk/Single/Edit Entry و custom bridge فقط برای gap اثبات‌شده شد؛
- Gravity Flow به‌عنوان تنها workflow/approval authority تثبیت و GravityView Entry Approval/Entry Tags به‌عنوان state موازی ممنوع شد؛
- سه مسیر presentation تعریف شد: Route 0 GravityView-only baseline، Route A full View در Elementor و Route B Entry Fieldهای مستقل با dynamic context اثبات‌نشده؛
- CPT/ACF/JetEngine mirror برای Elementor و تکیه بر Elementor visibility به‌عنوان authorization ممنوع شد؛
- direct URL tampering، non-assignee denial، edit-stays-pending، two-entry context، A4 و locking به POC اضافه شدند؛
- قابلیت رسمی GravityView Entry Locking جای فرض قدیمی «front-end locking اثبات‌نشده» را گرفت؛ behavior هدف همچنان نیازمند staging test است؛
- requirement کامل revision history با GravityRevisions candidate، Admin-only visibility و audit gap برای GFAPI writes اضافه شد؛
- school contract قفل شد: Officer نام مدرسه را ویرایش می‌کند، کد Admin-only است و `0` workflow/final registration را block نمی‌کند؛
- DOB به valid Jalali date-only محدود شد و age/grade-age rules حذف شدند؛
- photo contract به auto-optimization ورودی عادی گوشی و target غیرمسدودکنندهٔ ۱۵–۶۰KB اصلاح شد؛
- auto-canonical lowest Entry ID حذف و Admin explicit selection با audit و `ADMIN_SELECTION_REQUIRED` جایگزین شد؛
- خرید افزونهٔ پولی به POC-before-purchase Gate مقید شد؛
- BP-7 و BP-8، Risk Register، Definition of Done، Minimality Challenge، Decision Ledger و منابع رسمی با تصمیم‌های جدید هم‌راستا شدند.

### 1.1.1 — 2026-08-21

- معماری، owner lockها، componentها، Gateهای runtime و implementation sequence بدون تغییر حفظ شدند؛
- سلسله‌مراتب authority/applicability برای استفاده از ریپوی ترجیحات صریح شد؛
- نگاشت کمینهٔ recordهای canonical مؤثر به تصمیم‌ها و guardهای این پروژه افزوده شد؛
- HEAD جاری `0c6a0691…` دوباره بررسی و drift بین آن و projection source یعنی `6a3e4671…` ثبت شد؛
- projectionها `NON_CANONICAL` و در این evidence cutoff برابر `STALE_AFTER_ACCEPTED_SEMANTIC_CHANGE` طبقه‌بندی شدند؛ canonical current records مبنای تحلیل باقی ماندند؛
- applicability درس `EL-002` برابر `UNRESOLVED` ثبت شد؛ بنابراین هیچ gate یا Field Contractی حذف یا دور زده نشد؛
- پروتکل handoff برای re-check کردن projection freshness و جلوگیری از authority کاذب اصلاح شد.

### 1.1.0 — 2026-08-21

- معماری `BOUNDED_HYBRID` و همهٔ owner lockهای اصلی بدون تغییر حفظ شدند؛
- داشبورد اجرایی Gateها و status جدید `SURFACE_BLOCKED` اضافه شد؛
- ADR-003 به business invariant، interaction requirement و technical mechanism تفکیک شد؛
- extension pointهای رسمی Gravity Flow برای custom Approval action/status/evaluation/validation ثبت شدند، بدون ادعای save ordering یا atomicity؛
- BP-2 با partial write، دو tab/Officer، stale step/assignee، simultaneous actions و retry گسترش یافت؛
- BP-6 و performance budget پیشنهادی برای duplicate lookup اضافه شد؛ derived marker همچنان authority نیست؛
- Browser Notification به‌صراحت convenience و Inbox مرجع عملیاتی تعریف شد؛
- Print Data Envelope و fixtureهای حداکثری برای تضمین یک A4 اضافه شد؛
- privacy/retention به production-data Gate تبدیل شد؛
- importer به Reader/Validator/Planner/Committer responsibilities، immutable plan/hash، revalidation و `STALE_PLAN` مجهز شد؛ تعداد class/file قفل نشد؛
- Compatibility Matrix و major Upgrade Gate اضافه شد؛
- Handoff prose صریحاً `NON_ENFORCING_GUIDANCE` شد و مرز CI/static enforcement تعریف شد؛
- Risk Register، validation matrix، implementation sequence، Definition of Done و Minimality Challenge با اصلاحات بالا هم‌راستا شدند.

### 1.0.0 — 2026-08-20

- نخستین baseline مادر pre-implementation؛
- تثبیت Bounded Hybrid و authority boundaries؛
- ثبت Field Contract Gate، workflow/state، Desk، Needs Review، Approval، print و importer؛
- تأیید رفع Matrix2 female drift در commit `24a13e9…`؛
- ثبت component-level bounded prototypes و risk/validation plan؛
- جداسازی owner locks، confirmed evidence، selected design و not-proven details.

---

## Exact Next Action

**Current Gate = `AUTHORITATIVE_SCAFFOLD_NEXT`. Semantic Field Contract `OWNER APPROVED / CLOSED` است. اکنون authoritative Gravity Forms + Gravity Flow scaffold را فقط با synthetic data بسازید؛ سپس Form/Field/Input/Step IDهای واقعی را در Implementation Mapping bind کنید. Environment Inventory همچنان `PARTIAL/OWNER_ACCEPTED_FOR_PROGRESS` است، نه PASS. Scanner current-release deferred است و Scanner POC شرط این مرحله نیست. تا privacy/retention sign-off هیچ PII واقعی وارد staging/UAT/production نشود و هیچ dependency پولی پیش از POC برنده خریداری نشود.**
